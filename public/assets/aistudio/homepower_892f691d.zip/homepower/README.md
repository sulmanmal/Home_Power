# Home Power Solutions — Multi-Tenant Solar Store (PHP + MySQL)

Built from the *Home Power Solutions v3.0 Multi-Tenant SaaS* specification. One codebase runs many
independent solar stores (tenants), each on its own subdomain or custom domain, managed from a
Platform Control panel.

## Install (XAMPP / WAMP / cPanel)
1. Copy the `homepower` folder into `htdocs` (or `public_html`).
2. Import the database: phpMyAdmin → Import → `schema.sql` (creates DB `homepower` with demo data).
3. Edit `config.php`: DB credentials, `APP_PATH` (`/homepower` in htdocs, `''` at a domain root), and `PLATFORM_DOMAIN`.
4. Requires PHP 8.1+, MySQL 8 / MariaDB 10.5+, extensions `pdo_mysql` and `fileinfo`, Apache `mod_rewrite`.

| URL | Who | Login |
|---|---|---|
| `/homepower/` | Storefront (Tenant #1 Home Power) | — |
| `/homepower/admin/` | Store admin | `admin` / `admin123` |
| `/homepower/platform/` | Platform owner (you) | `platform` / `admin123` |

**Change both passwords immediately** (Admin → Staff; for the platform account, update `platform_admins` with a new `password_hash`).

## Testing several stores locally
Create a store in **Platform → + New tenant** (e.g. subdomain `acmesolar`). Then open
`/homepower/index.php?tenant=acmesolar` — the browser session switches to that store; its admin is at
`/homepower/admin/` (username `admin`, the password you set). `?tenant=homepower` switches back.

## Going live with multiple domains
- **Subdomains:** add a wildcard DNS record `*.yourplatform.com → server IP` and a wildcard virtual host / cPanel wildcard subdomain pointing at this folder. Every new tenant works at `slug.yourplatform.com` immediately.
- **Custom domains:** the customer points `www.theirstore.pk` (A record) to your server IP; add it in Platform → tenant → Domains → *Check DNS*. Add the domain as an alias/addon domain on the server pointing at the same folder.
- **SSL:** `certbot --apache -d theirstore.pk -d www.theirstore.pk` per custom domain; a wildcard cert (DNS challenge) for `*.yourplatform.com`. On cPanel, AutoSSL does this automatically.
- Set `DEFAULT_TENANT_ID` to `0` in production so unknown domains return 404 instead of showing Tenant #1.

## What's included
**Storefront:** dynamic homepage (blocks reorderable from admin), shop with filters/sort/search (incl. "UPS ↔ inverter" synonym), product pages with JSON-LD Product schema, comparison tool, cart, coupons, weight/zone shipping, checkout with JazzCash/Easypaisa/Bank/Raast/COD, payment-receipt upload with duplicate-receipt detection, order tracking timeline, late receipt upload, printable invoice, solar sizing calculator (city sun-hours, hybrid/off-grid/on-grid, DoD, ROI, payback, one-click "add recommended bundle"), warranty lookup by serial, CMS pages, per-domain sitemap.xml and robots.txt, WhatsApp button.

**Store admin:** dashboard (revenue, receipts to verify, low stock, 14-day sales, top sellers, CSV export), order management with receipt viewer and verify/reject + auditor notes, courier & tracking, cancellation auto-restock, serial-number warranty registration, products (variants specs, installer price, images, SEO, stock in/out/adjust with movement history), categories, coupons, shipping zones, CMS pages, drag-and-drop homepage layout, branding/colours/logo/payment details, staff with roles (owner/admin/inventory/auditor/support) and audit log.

**Platform control (SaaS owner):** tenant list with MRR, GMV and transaction-fee totals; one-click provisioning (store, owner login, defaults, optional catalog cloned from another store); plan change; suspend/activate/archive; custom-domain add/verify/primary; per-tenant feature overrides; owner password reset; audited "log in as store owner"; editable plans (price, fee %, limits, features). Plan limits (products, staff) and features (calculator, coupons, warranty) are enforced in the store.

**Security:** PDO prepared statements everywhere, every tenant query filtered by `tenant_id` (fail-closed tenant resolution), CSRF tokens on all forms, password hashing, login throttling, session regeneration, output escaping, MIME-sniffed uploads, payment receipts stored outside public access (`private/`, served only to that store's admins), PHP execution blocked in `uploads/`, CSV-injection guard, security headers.

## Not yet included (later phases of the spec)
Live JazzCash/Easypaisa API callbacks, OCR of receipts, courier APIs, SMS/WhatsApp notifications, Urdu/RTL, automated subscription billing invoices, Redis/search engine, PWA, 2FA. The tables and structure are ready for these to be added module by module.

## v2 — SEO, slider, menu builder, homepage sections (jQuery)
**Upgrading an existing database:** run `upgrade_v2.sql` once in phpMyAdmin. Fresh installs just import `schema.sql`.

New admin pages:
- **Slider** — full-width homepage slider (default 500 px high). Add/edit/hide slides with image or background colour, title, subtitle, button, text position and colours (live preview); drag to reorder; set height, autoplay seconds and fade/slide effect.
- **Menu builder** — add items linked to pages, categories, products or any URL; drag-and-drop nesting up to 3 levels (main → drop-down → fly-out); choose a design (Classic, Underline, Centered, Boxed) and header background, text and hover colours; edit or hide the announcement bar.
- **Homepage sections** — drag to reorder and switch on/off: Slider, Categories, Featured, Sale, New arrivals, Upcoming (countdown), Product listing (category tabs, sort, Load more), Why choose us, Calculator banner, Reviews. Each has its own heading, sub-heading and product count.
- **SEO** — default title/description/keywords with live Google preview, share image, Google Analytics 4, Search Console/Bing verification, extra head code, "hide store from search engines"; per-page meta for Home/Shop/Calculator etc.; inline SEO editor for every product; 301/302 redirect manager; SEO audit with a health score.
- **Products** — new fields: sale price, New arrival, Upcoming + launch date, meta keywords.

Storefront (jQuery 3.7): animated slider with swipe/keyboard/progress bar, 3-level responsive menu, AJAX add-to-cart with toast, quick-view popup, scrollable product rows, AJAX product listing, countdowns, scroll reveal, back-to-top. Every page outputs canonical, Open Graph, Twitter and robots tags.
