<?php
/** Tenant admin bootstrap: auth guard + layout helpers. */
define('ADMIN_AREA', true);
require __DIR__ . '/../inc/bootstrap.php';

function admin() { return $_SESSION['admin'][TID] ?? null; }
function require_admin($roles = null) {
    $a = admin();
    if (!$a) redirect('admin/login.php');
    if ($roles && !in_array($a['role'], array_merge(['owner', 'admin'], (array)$roles), true)) {
        http_response_code(403); exit('You do not have permission for this section.');
    }
    global $TENANT;
    if ($TENANT['status'] === 'suspended') exit('This store is suspended. Contact the platform owner.');
    return $a;
}
function audit($action, $table = null, $id = null) {
    q("INSERT INTO audit_logs (tenant_id, admin_id, action, target_table, target_id, ip_address) VALUES (?,?,?,?,?,?)",
      [TID, admin()['id'], $action, $table, $id, $_SERVER['REMOTE_ADDR'] ?? '']);
}
function admin_head($title) {
    global $TENANT, $PLAN; $a = admin();
    $nav = ['index.php' => 'Dashboard', 'orders.php' => 'Orders', 'products.php' => 'Products', 'categories.php' => 'Categories',
            'coupons.php' => 'Coupons', 'shipping.php' => 'Shipping', 'homepage.php' => 'Homepage sections', 'slider.php' => 'Slider', 'menu.php' => 'Menu builder',
            'pages.php' => 'Pages', 'seo.php' => 'SEO', 'settings.php' => 'Settings', 'staff.php' => 'Staff'];
    $cur = basename($_SERVER['SCRIPT_NAME']);
    echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . e($title) . ' — Admin</title>
    <link rel="stylesheet" href="' . url('assets/style.css') . '"><link rel="stylesheet" href="' . url('assets/admin.css') . '">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js"></script><style>:root{--brand:' . e(setting('primary_color', '#0f766e')) . ';--accent:' . e(setting('accent_color', '#f59e0b')) . '}</style></head>
    <body class="admin"><aside><div class="alogo">' . e($TENANT['company_name']) . '<small>' . e($PLAN['name']) . ' plan</small></div><nav>';
    foreach ($nav as $f => $l) echo '<a class="' . ($cur === $f ? 'on' : '') . '" href="' . url('admin/' . $f) . '">' . $l . '</a>';
    echo '<a href="' . url('index.php') . '" target="_blank">View store ↗</a><a href="' . url('admin/logout.php') . '">Log out (' . e($a['username']) . ')</a></nav></aside><section class="amain"><h1>' . e($title) . '</h1>' . flash();
}
function admin_foot() { echo '</section></body></html>'; }
function plan_limit_reached($metric) {
    global $PLAN;
    if ($metric === 'products') return row("SELECT COUNT(*) n FROM products WHERE tenant_id=?", [TID])['n'] >= $PLAN['max_products'];
    if ($metric === 'staff') return row("SELECT COUNT(*) n FROM admin_users WHERE tenant_id=?", [TID])['n'] >= $PLAN['max_staff'];
    return false;
}
