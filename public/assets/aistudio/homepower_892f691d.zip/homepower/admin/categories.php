<?php
require __DIR__ . '/_init.php';
require_admin(['inventory']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['act'] ?? '') === 'add' && trim($_POST['name'])) {
        $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($_POST['name'])), '-');
        try { q("INSERT INTO categories (tenant_id, name, slug) VALUES (?,?,?)", [TID, trim($_POST['name']), $slug]); flash('Category added.'); }
        catch (PDOException $e) { flash('Category already exists.', 'err'); }
    }
    if (($_POST['act'] ?? '') === 'del') { q("DELETE FROM categories WHERE id=? AND tenant_id=?", [(int)$_POST['id'], TID]); flash('Category deleted.'); }
    redirect('admin/categories.php');
}
$list = rows("SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id) n FROM categories c WHERE tenant_id=? ORDER BY name", [TID]);
admin_head('Categories'); ?>
<form method="post" class="card row"><?= csrf_field() ?><input type="hidden" name="act" value="add"><input name="name" placeholder="New category name" required><button class="btn">Add</button></form>
<div class="card"><table class="tbl"><tr><th>Name</th><th>Slug</th><th>Products</th><th></th></tr>
<?php foreach ($list as $c): ?><tr><td><?= e($c['name']) ?></td><td><?= e($c['slug']) ?></td><td><?= $c['n'] ?></td>
<td><form method="post" onsubmit="return confirm('Delete category? Products will become uncategorised.')"><?= csrf_field() ?><input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?= $c['id'] ?>"><button class="link">Delete</button></form></td></tr><?php endforeach; ?>
</table></div>
<?php admin_foot();
