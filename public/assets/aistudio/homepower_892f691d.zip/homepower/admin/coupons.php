<?php
require __DIR__ . '/_init.php';
require_admin();
if (!feature('coupons')) { admin_head('Coupons'); echo '<div class="card upsell"><h3>🔒 Coupons are available on the Growth plan and above.</h3><p>Contact the platform owner to upgrade.</p></div>'; admin_foot(); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'add') {
        try {
            q("INSERT INTO coupons (tenant_id, code, discount_type, discount_value, min_order_amount, max_uses, expires_at) VALUES (?,?,?,?,?,?,?)",
              [TID, strtoupper(trim($_POST['code'])), $_POST['discount_type'] === 'fixed' ? 'fixed' : 'percentage', (float)$_POST['discount_value'],
               (float)$_POST['min_order_amount'], (int)$_POST['max_uses'], $_POST['expires_at'] ?: null]);
            flash('Coupon created.');
        } catch (PDOException $e) { flash('Coupon code already exists.', 'err'); }
    }
    if ($act === 'toggle') q("UPDATE coupons SET is_active=1-is_active WHERE id=? AND tenant_id=?", [(int)$_POST['id'], TID]);
    redirect('admin/coupons.php');
}
$list = rows("SELECT * FROM coupons WHERE tenant_id=? ORDER BY id DESC", [TID]);
admin_head('Coupons'); ?>
<form method="post" class="card grid3"><?= csrf_field() ?><input type="hidden" name="act" value="add">
  <label>Code<input name="code" required></label>
  <label>Type<select name="discount_type"><option value="percentage">Percentage %</option><option value="fixed">Fixed Rs</option></select></label>
  <label>Value<input type="number" step="0.01" name="discount_value" required></label>
  <label>Minimum order (Rs)<input type="number" name="min_order_amount" value="0"></label>
  <label>Max uses (0 = unlimited)<input type="number" name="max_uses" value="0"></label>
  <label>Expires<input type="datetime-local" name="expires_at"></label>
  <button class="btn">Create coupon</button></form>
<div class="card"><table class="tbl"><tr><th>Code</th><th>Discount</th><th>Min order</th><th>Used</th><th>Expires</th><th>Status</th></tr>
<?php foreach ($list as $c): ?><tr><td><b><?= e($c['code']) ?></b></td><td><?= $c['discount_type'] === 'percentage' ? (float)$c['discount_value'] . '%' : money($c['discount_value']) ?></td>
<td><?= money($c['min_order_amount']) ?></td><td><?= $c['used_count'] ?><?= $c['max_uses'] ? ' / ' . $c['max_uses'] : '' ?></td><td><?= e($c['expires_at'] ?? '—') ?></td>
<td><form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="toggle"><input type="hidden" name="id" value="<?= $c['id'] ?>"><button class="link"><?= $c['is_active'] ? 'Active — disable' : 'Disabled — enable' ?></button></form></td></tr><?php endforeach; ?>
</table></div>
<?php admin_foot();
