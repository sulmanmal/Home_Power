<?php
require __DIR__ . '/_init.php';
require_admin();
$what = $_GET['what'] ?? 'orders';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $what . '-' . date('Ymd') . '.csv"');
$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF"); // Excel UTF-8 BOM
$data = $what === 'products'
    ? rows("SELECT sku, name, brand, price, price_installer, stock, capacity, voltage, warranty_months, is_active FROM products WHERE tenant_id=?", [TID])
    : rows("SELECT order_number, created_at, customer_name, phone, city, subtotal, discount, shipping, total, status, courier, courier_tracking FROM orders WHERE tenant_id=? ORDER BY id DESC", [TID]);
if ($data) fputcsv($out, array_keys($data[0]));
foreach ($data as $r) fputcsv($out, array_map(fn($v) => preg_match('/^[=+\-@]/', (string)$v) ? "'" . $v : $v, $r)); // CSV-injection guard
