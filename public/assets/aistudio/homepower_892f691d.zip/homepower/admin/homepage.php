<?php
require __DIR__ . '/_init.php';
require_admin();
$types = [
  'slider' => ['Full-width slider', 'Manage slides in Slider', false],
  'categories' => ['Category circles', 'Shows every category', false],
  'featured' => ['Featured products', 'Products ticked “Featured”', true],
  'sale' => ['Sale / hot deals', 'Products with a sale price', true],
  'new' => ['New arrivals', 'Products ticked “New”', true],
  'upcoming' => ['Upcoming products', 'Products ticked “Upcoming”, with countdown', true],
  'all_products' => ['Product listing', 'Category tabs, sort and Load more', true],
  'features' => ['Why choose us', 'Benefit cards', false],
  'calculator' => ['Solar calculator banner', 'Link to the calculator', false],
  'testimonials' => ['Customer reviews', 'Testimonial cards', false],
];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (array_values($_POST['order'] ?? []) as $i => $id) {
        $b = $_POST['b'][$id] ?? [];
        q("UPDATE homepage_blocks SET sort_order=?, is_enabled=?, title=?, subtitle=?, item_limit=? WHERE id=? AND tenant_id=?",
          [$i + 1, isset($b['on']) ? 1 : 0, trim($b['title'] ?? '') ?: null, trim($b['subtitle'] ?? '') ?: null, max(1, min(48, (int)($b['limit'] ?? 8))), (int)$id, TID]);
    }
    audit('homepage_layout');
    flash('Homepage updated.'); redirect('admin/homepage.php');
}
foreach ($types as $k => $_) if (!row("SELECT id FROM homepage_blocks WHERE tenant_id=? AND block_type=?", [TID, $k]))
    q("INSERT INTO homepage_blocks (tenant_id, block_type, sort_order, is_enabled, item_limit) VALUES (?,?,99,0,8)", [TID, $k]);
$blocks = rows("SELECT * FROM homepage_blocks WHERE tenant_id=? AND block_type IN ('" . implode("','", array_keys($types)) . "') ORDER BY sort_order", [TID]);
$counts = row("SELECT SUM(is_featured=1 AND is_upcoming=0) featured, SUM(is_new=1 AND is_upcoming=0) new, SUM(sale_price>0 AND sale_price<price AND is_upcoming=0) sale,
               SUM(is_upcoming=1) upcoming, COUNT(*) all_products FROM products WHERE tenant_id=? AND is_active=1", [TID]);
admin_head('Homepage sections'); ?>
<p class="muted">Drag sections to reorder, switch them on or off, and change their headings. Changes appear on the homepage immediately after saving. <a href="<?= url('index.php') ?>" target="_blank">Open homepage ↗</a></p>
<form method="post"><?= csrf_field() ?>
<ul class="block-list" id="blocks">
<?php foreach ($blocks as $b): [$label, $hint, $hasLimit] = $types[$b['block_type']]; ?>
  <li class="card block-item <?= $b['is_enabled'] ? '' : 'off' ?>"><input type="hidden" name="order[]" value="<?= $b['id'] ?>">
    <div class="bi-head"><span class="handle">☰</span>
      <label class="switch"><input type="checkbox" name="b[<?= $b['id'] ?>][on]" <?= $b['is_enabled'] ? 'checked' : '' ?>><i></i></label>
      <b><?= e($label) ?></b><small><?= e($hint) ?><?php if (isset($counts[$b['block_type']])): ?> · <?= (int)$counts[$b['block_type']] ?> products<?php endif; ?></small>
      <?php if ($b['block_type'] === 'slider'): ?><a class="btn sm ghost-dark" href="slider.php">Edit slides</a><?php endif; ?>
      <button type="button" class="link js-expand">Settings ▾</button></div>
    <?php if ($b['block_type'] !== 'slider'): ?>
    <div class="bi-body">
      <div class="grid3"><label>Heading<input name="b[<?= $b['id'] ?>][title]" value="<?= e($b['title']) ?>" placeholder="Default heading"></label>
      <label>Sub-heading<input name="b[<?= $b['id'] ?>][subtitle]" value="<?= e($b['subtitle']) ?>"></label>
      <?php if ($hasLimit): ?><label>Products to show<input type="number" min="1" max="48" name="b[<?= $b['id'] ?>][limit]" value="<?= (int)$b['item_limit'] ?>"></label><?php endif; ?></div>
    </div>
    <?php endif; ?>
  </li>
<?php endforeach; ?>
</ul>
<button class="btn">Save homepage</button>
</form>
<div class="card soft"><b>Tip:</b> mark products as <i>Featured</i>, <i>New</i>, <i>Upcoming</i> or give them a <i>Sale price</i> in <a href="products.php">Products</a> to fill these sections.</div>
<script>
$('#blocks').sortable({ handle: '.handle', placeholder: 'card block-ph' });
$('.js-expand').on('click', function(){ $(this).closest('li').find('.bi-body').slideToggle(180); });
$('.switch input').on('change', function(){ $(this).closest('li').toggleClass('off', !this.checked); });
</script>
<?php admin_foot();
