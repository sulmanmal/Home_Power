<?php
require __DIR__ . '/_init.php';
require_admin();
$k = row("SELECT
  (SELECT COALESCE(SUM(total),0) FROM orders WHERE tenant_id=? AND status IN ('verified','dispatched','completed')) revenue,
  (SELECT COALESCE(SUM(total),0) FROM orders WHERE tenant_id=? AND status IN ('verified','dispatched','completed') AND created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')) month_rev,
  (SELECT COUNT(*) FROM orders WHERE tenant_id=?) orders,
  (SELECT COUNT(*) FROM orders WHERE tenant_id=? AND status='receipt_uploaded') to_verify,
  (SELECT COUNT(*) FROM products WHERE tenant_id=? AND stock<=min_threshold) low_stock", array_fill(0, 5, TID));
$daily = rows("SELECT DATE(created_at) d, SUM(total) s FROM orders WHERE tenant_id=? AND created_at>=CURDATE()-INTERVAL 13 DAY AND status NOT IN ('cancelled','refunded') GROUP BY d ORDER BY d", [TID]);
$top = rows("SELECT product_name, SUM(quantity) q, SUM(quantity*unit_price) s FROM order_items oi JOIN orders o ON o.id=oi.order_id
             WHERE oi.tenant_id=? AND o.status NOT IN ('cancelled','refunded') GROUP BY product_name ORDER BY s DESC LIMIT 5", [TID]);
$low = rows("SELECT id, name, stock, min_threshold FROM products WHERE tenant_id=? AND stock<=min_threshold ORDER BY stock LIMIT 8", [TID]);
$max = max(array_column($daily, 's') ?: [1]);
admin_head('Dashboard');
?>
<div class="kpis">
  <div class="card"><small>Verified revenue</small><b><?= money($k['revenue']) ?></b></div>
  <div class="card"><small>This month</small><b><?= money($k['month_rev']) ?></b></div>
  <div class="card"><small>Total orders</small><b><?= $k['orders'] ?></b></div>
  <a class="card warn" href="orders.php?status=receipt_uploaded"><small>Receipts to verify</small><b><?= $k['to_verify'] ?></b></a>
  <a class="card warn" href="products.php?low=1"><small>Low stock</small><b><?= $k['low_stock'] ?></b></a>
</div>
<div class="grid2">
  <div class="card"><h3>Sales — last 14 days</h3>
    <div class="chart"><?php foreach ($daily as $d): ?><div class="bar" style="height:<?= round($d['s'] / $max * 100) ?>%" title="<?= e($d['d']) ?>: <?= money($d['s']) ?>"></div><?php endforeach; ?></div>
    <?php if (!$daily): ?><p class="muted">No orders yet.</p><?php endif; ?></div>
  <div class="card"><h3>Top sellers</h3><table class="tbl"><?php foreach ($top as $t): ?><tr><td><?= e($t['product_name']) ?></td><td><?= $t['q'] ?> sold</td><td><?= money($t['s']) ?></td></tr><?php endforeach; ?></table></div>
</div>
<?php if ($low): ?><div class="card"><h3>Low stock alerts</h3><table class="tbl"><?php foreach ($low as $l): ?>
  <tr><td><a href="products.php?edit=<?= $l['id'] ?>"><?= e($l['name']) ?></a></td><td class="out"><?= $l['stock'] ?> left (threshold <?= $l['min_threshold'] ?>)</td></tr><?php endforeach; ?></table></div><?php endif; ?>
<p class="muted">Export: <a href="export.php?what=orders">Orders CSV</a> · <a href="export.php?what=products">Products CSV</a></p>
<?php admin_foot();
