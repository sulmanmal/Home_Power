<?php
require __DIR__ . '/_init.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Basic brute-force throttle
    $_SESSION['login_fail'] ??= 0;
    if ($_SESSION['login_fail'] >= 5 && time() - ($_SESSION['login_last'] ?? 0) < 300) $err = 'Too many attempts. Try again in 5 minutes.';
    else {
        $u = row("SELECT * FROM admin_users WHERE tenant_id=? AND username=?", [TID, $_POST['username'] ?? '']);
        if ($u && password_verify($_POST['password'] ?? '', $u['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin'][TID] = ['id' => $u['id'], 'username' => $u['username'], 'role' => $u['role']];
            $_SESSION['login_fail'] = 0;
            q("UPDATE admin_users SET last_login_at=NOW() WHERE id=?", [$u['id']]);
            redirect('admin/index.php');
        }
        $_SESSION['login_fail']++; $_SESSION['login_last'] = time();
        $err = 'Invalid username or password.';
    }
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin login</title>
<link rel="stylesheet" href="<?= url('assets/style.css') ?>"><style>:root{--brand:<?= e(setting('primary_color', '#0f766e')) ?>}</style></head>
<body class="loginpage"><form method="post" class="card login"><?= csrf_field() ?>
<h2><?= e($TENANT['company_name']) ?></h2><p class="muted">Store admin</p>
<?php if ($err): ?><div class="alert alert-err"><?= e($err) ?></div><?php endif; ?>
<label>Username<input name="username" required autofocus></label>
<label>Password<input type="password" name="password" required></label>
<button class="btn block">Log in</button></form></body></html>
