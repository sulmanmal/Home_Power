<?php
require __DIR__ . '/_init.php';
unset($_SESSION['admin'][TID]);
redirect('admin/login.php');
