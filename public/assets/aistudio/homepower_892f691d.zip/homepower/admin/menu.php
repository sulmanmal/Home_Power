<?php
require __DIR__ . '/_init.php';
require_admin();

/** depth of an item (1 = top level) */
function item_depth($id, $all) { $d = 0; while ($id && isset($all[$id]) && $d < 10) { $d++; $id = (int)$all[$id]['parent_id']; } return $d; }
$allRows = rows("SELECT * FROM menu_items WHERE tenant_id=? ORDER BY sort_order, id", [TID]);
$all = []; foreach ($allRows as $r) $all[$r['id']] = $r;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'save') {
        $id = (int)$_POST['id']; $parent = (int)$_POST['parent_id'] ?: null;
        if ($parent && (!isset($all[$parent]) || item_depth($parent, $all) >= 3)) { flash('Menus can be at most 3 levels deep.', 'err'); redirect('admin/menu.php'); }
        if ($parent && $id && ($parent === $id || in_array($id, (function ($p) use ($all) { $c = []; while ($p) { $c[] = $p; $p = (int)($all[$p]['parent_id'] ?? 0); } return $c; })($parent)))) {
            flash('An item cannot be placed inside itself.', 'err'); redirect('admin/menu.php');
        }
        $vals = [trim($_POST['label']), trim($_POST['url']) ?: '#', $parent, isset($_POST['open_new']) ? 1 : 0, isset($_POST['is_active']) ? 1 : 0];
        if ($id) q("UPDATE menu_items SET label=?, url=?, parent_id=?, open_new=?, is_active=? WHERE id=? AND tenant_id=?", array_merge($vals, [$id, TID]));
        else {
            $next = (int)row("SELECT COALESCE(MAX(sort_order),0)+1 n FROM menu_items WHERE tenant_id=? AND parent_id<=>?", [TID, $parent])['n'];
            q("INSERT INTO menu_items (label, url, parent_id, open_new, is_active, tenant_id, sort_order) VALUES (?,?,?,?,?,?,?)", array_merge($vals, [TID, $next]));
        }
        audit('menu_save'); flash('Menu item saved.');
    }
    if ($act === 'del') {
        $id = (int)$_POST['id'];
        // move children up one level instead of deleting them
        q("UPDATE menu_items SET parent_id=? WHERE parent_id=? AND tenant_id=?", [$all[$id]['parent_id'] ?? null, $id, TID]);
        q("DELETE FROM menu_items WHERE id=? AND tenant_id=?", [$id, TID]);
        audit('menu_delete'); flash('Menu item deleted.');
    }
    if ($act === 'tree') {   // AJAX: drag-and-drop structure
        $tree = json_decode($_POST['tree'] ?? '[]', true) ?: [];
        foreach ($tree as $n) if ((int)$n['depth'] > 3) json_out(['ok' => false, 'msg' => 'Maximum 3 levels']);
        foreach ($tree as $n)
            q("UPDATE menu_items SET parent_id=?, sort_order=? WHERE id=? AND tenant_id=?", [(int)$n['parent'] ?: null, (int)$n['order'], (int)$n['id'], TID]);
        audit('menu_reorder');
        json_out(['ok' => true]);
    }
    if ($act === 'design') {
        save_setting('menu_style', in_array($_POST['menu_style'], ['classic', 'centered', 'boxed', 'underline'], true) ? $_POST['menu_style'] : 'classic');
        foreach (['menu_bg', 'menu_text', 'menu_hover'] as $k) if (preg_match('/^#[0-9a-f]{6}$/i', $_POST[$k] ?? '')) save_setting($k, $_POST[$k]);
        save_setting('announcement', trim($_POST['announcement'] ?? ''));
        audit('menu_design'); flash('Menu design saved.');
    }
    redirect('admin/menu.php');
}

// Link picker sources
$linkSources = ['Store pages' => ['index.php' => 'Home', 'shop.php' => 'Shop (all products)', 'calculator.php' => 'Solar calculator', 'compare.php' => 'Compare products', 'track.php' => 'Track order', 'warranty.php' => 'Warranty check', 'cart.php' => 'Cart']];
foreach (rows("SELECT slug, title FROM cms_pages WHERE tenant_id=?", [TID]) as $p) $linkSources['CMS pages']['page.php?slug=' . $p['slug']] = $p['title'];
foreach (rows("SELECT slug, name FROM categories WHERE tenant_id=?", [TID]) as $c) $linkSources['Categories']['shop.php?cat=' . $c['slug']] = $c['name'];
foreach (rows("SELECT slug, name FROM products WHERE tenant_id=? AND is_active=1 ORDER BY name LIMIT 300", [TID]) as $p) $linkSources['Products']['product.php?slug=' . $p['slug']] = $p['name'];

$byParent = []; foreach ($allRows as $r) $byParent[(int)$r['parent_id']][] = $r;
function tree_html($pid, $byParent, $depth = 1) {
    $h = '<ul class="mtree" data-depth="' . $depth . '">';
    foreach ($byParent[$pid] ?? [] as $m)
        $h .= '<li data-id="' . $m['id'] . '"><div class="mrow' . ($m['is_active'] ? '' : ' off') . '"><span class="handle">☰</span><b>' . e($m['label']) . '</b><small>' . e($m['url']) . '</small>'
            . '<span class="lvl-tag">L' . $depth . '</span><a href="?edit=' . $m['id'] . '">Edit</a>'
            . '<form method="post" onsubmit="return confirm(\'Delete this item? Its sub-items move up one level.\')">' . csrf_field() . '<input type="hidden" name="act" value="del"><input type="hidden" name="id" value="' . $m['id'] . '"><button class="link">Delete</button></form></div>'
            . tree_html((int)$m['id'], $byParent, $depth + 1) . '</li>';
    return $h . '</ul>';
}
$edit = null;
if (isset($_GET['edit'])) $edit = $_GET['edit'] === 'new' ? ['id' => 0, 'label' => '', 'url' => '', 'parent_id' => (int)($_GET['parent'] ?? 0), 'open_new' => 0, 'is_active' => 1] : ($all[(int)$_GET['edit']] ?? null);
admin_head('Menu builder'); ?>

<div class="grid2 wide">
<div>
  <?php if ($edit): ?>
  <form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= $edit['id'] ?>">
    <h3><?= $edit['id'] ? 'Edit menu item' : 'Add menu item' ?></h3>
    <div class="grid2"><label>Label<input name="label" required value="<?= e($edit['label']) ?>"></label>
    <label>Parent (for drop-downs)<select name="parent_id"><option value="0">— Top level —</option>
      <?php foreach ($allRows as $r): $d = item_depth($r['id'], $all); if ($d >= 3 || $r['id'] == $edit['id']) continue; ?>
        <option value="<?= $r['id'] ?>" <?= $edit['parent_id'] == $r['id'] ? 'selected' : '' ?>><?= str_repeat('— ', $d - 1) . e($r['label']) ?></option><?php endforeach; ?></select></label></div>
    <label>Link to<select id="linkPick"><option value="">Choose a page, category or product…</option>
      <?php foreach ($linkSources as $g => $opts): ?><optgroup label="<?= e($g) ?>"><?php foreach ($opts as $u => $l): ?><option value="<?= e($u) ?>" data-label="<?= e($l) ?>"><?= e($l) ?></option><?php endforeach; ?></optgroup><?php endforeach; ?>
      <option value="custom">Custom URL…</option></select></label>
    <label>URL<input name="url" id="urlField" value="<?= e($edit['url']) ?>" placeholder="shop.php?cat=… or https://…"></label>
    <label class="chk"><input type="checkbox" name="open_new" <?= $edit['open_new'] ? 'checked' : '' ?>> Open in new tab</label>
    <label class="chk"><input type="checkbox" name="is_active" <?= $edit['is_active'] ? 'checked' : '' ?>> Visible</label><br><br>
    <button class="btn">Save item</button> <a href="menu.php">Cancel</a>
  </form>
  <script>
  $('#linkPick').on('change', function(){
    var v = $(this).val(); if (!v) return;
    if (v === 'custom') { $('#urlField').val('https://').focus(); return; }
    $('#urlField').val(v);
    if (!$('[name=label]').val()) $('[name=label]').val($(this).find(':selected').data('label'));
  });
  </script>
  <?php endif; ?>

  <div class="card">
    <div class="row" style="justify-content:space-between"><h3 style="margin:0">Menu structure</h3><a class="btn sm" href="?edit=new">+ Add item</a></div>
    <p class="muted">Drag ☰ to reorder. Drop an item onto another item's sub-list to nest it — up to <b>3 levels</b> (main → drop-down → fly-out).</p>
    <div id="menuTree"><?= tree_html(0, $byParent) ?></div>
    <?php if (!$allRows): ?><p class="muted">No menu items yet — the store shows Home and Shop until you add some.</p><?php endif; ?>
    <span class="muted" id="treeStatus"></span>
  </div>
</div>

<form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="act" value="design">
  <h3>Menu design</h3>
  <div class="style-picks">
  <?php foreach (['classic' => 'Classic — logo left, menu right', 'underline' => 'Underline — animated underline on hover', 'centered' => 'Centered — logo centre, menu below', 'boxed' => 'Boxed — coloured menu bar'] as $k => $l): ?>
    <label class="style-pick"><input type="radio" name="menu_style" value="<?= $k ?>" <?= setting('menu_style', 'classic') === $k ? 'checked' : '' ?>>
      <span class="mini mini-<?= $k ?>"><i class="lg"></i><i class="nv"><em></em><em></em><em></em></i></span><?= e($l) ?></label>
  <?php endforeach; ?>
  </div>
  <div class="grid3">
    <label>Header background<input type="color" name="menu_bg" value="<?= e(setting('menu_bg', '#ffffff')) ?>"></label>
    <label>Menu text<input type="color" name="menu_text" value="<?= e(setting('menu_text', '#0b1220')) ?>"></label>
    <label>Hover / accent<input type="color" name="menu_hover" value="<?= e(setting('menu_hover', setting('primary_color', '#0f766e'))) ?>"></label>
  </div>
  <div class="menu-preview" id="menuPreview"><b>☀ Logo</b><span>Home</span><span class="hv">Products ▾</span><span>Calculator</span><span>Contact</span></div>
  <label>Top announcement bar (leave empty to hide)<input name="announcement" value="<?= e(setting('announcement', '')) ?>"></label>
  <button class="btn">Save design</button>
</form>
</div>

<script>
// live colour preview
function paint(){ var $p=$('#menuPreview'), s=$('[name=menu_style]:checked').val(), hv=$('[name=menu_hover]').val();
  $p.attr('class','menu-preview mp-'+s).css({background:$('[name=menu_bg]').val(),color:$('[name=menu_text]').val()}).find('.hv').css(s==='boxed'?{background:hv,color:'#fff'}:{background:'transparent',color:hv}); }
$('[name^=menu_]').on('input change', paint); paint();

// nested drag & drop, max 3 levels
function ensureLists(){ $('#menuTree li').each(function(){ if(!$(this).children('ul').length) $(this).append('<ul class="mtree"></ul>'); }); }
function depthOf($ul){ return $ul.parentsUntil('#menuTree','ul').length + 1; }
function saveTree(){
  var out=[], ok=true;
  $('#menuTree li').each(function(){
    var $li=$(this), $ul=$li.parent(), d=depthOf($ul);
    if(d>3) ok=false;
    out.push({id:$li.data('id'), parent:$ul.closest('li').data('id')||0, order:$li.index()+1, depth:d});
    $li.find('> .mrow .lvl-tag').text('L'+d);
  });
  if(!ok){ $('#treeStatus').text('Maximum 3 levels — move the item up a level.').css('color','#dc2626'); return false; }
  $.post('menu.php',{act:'tree',csrf:<?= json_encode(csrf_token()) ?>,tree:JSON.stringify(out)},function(r){
    $('#treeStatus').text(r.ok?'✓ Menu order saved':r.msg).css('color',r.ok?'#059669':'#dc2626'); },'json');
  return true;
}
ensureLists();
$('#menuTree ul').sortable({ connectWith:'#menuTree ul', handle:'.handle', placeholder:'mt-ph', tolerance:'pointer', toleranceElement:'> .mrow',
  receive:function(e,ui){ var deep=ui.item.find('ul:has(li)').length ? 1 + ui.item.find('ul ul:has(li)').length : 0;
    if(depthOf($(this)) + deep > 3){ $(ui.sender).sortable('cancel'); $('#treeStatus').text('That would make the menu deeper than 3 levels.').css('color','#dc2626'); } },
  stop:function(){ saveTree(); } });
</script>
<?php admin_foot();
