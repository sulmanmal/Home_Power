<?php
require __DIR__ . '/_init.php';
$me = require_admin(['auditor', 'support', 'inventory']);
$statuses = ['pending', 'receipt_uploaded', 'verified', 'dispatched', 'completed', 'on_hold', 'cancelled', 'refunded'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];
    $o = row("SELECT * FROM orders WHERE id=? AND tenant_id=?", [$id, TID]) or exit('Not found');
    $act = $_POST['act'] ?? '';
    if ($act === 'verify' || $act === 'reject') {
        if (!in_array($me['role'], ['owner', 'admin', 'auditor'])) exit('Only payment auditors can verify.');
        q("UPDATE payments SET status=?, auditor_notes=?, verified_by=?, verified_at=NOW() WHERE order_id=? AND tenant_id=?",
          [$act === 'verify' ? 'verified' : 'rejected', $_POST['notes'] ?? '', $me['id'], $id, TID]);
        q("UPDATE orders SET status=? WHERE id=? AND tenant_id=?", [$act === 'verify' ? 'verified' : 'on_hold', $id, TID]);
        audit("payment_$act", 'orders', $id);
        flash($act === 'verify' ? 'Payment verified.' : 'Payment rejected; order put on hold.');
    }
    if ($act === 'status' && in_array($_POST['status'], $statuses, true)) {
        // Restock if cancelled/refunded from an active state
        if (in_array($_POST['status'], ['cancelled', 'refunded']) && !in_array($o['status'], ['cancelled', 'refunded'])) {
            foreach (rows("SELECT * FROM order_items WHERE order_id=? AND tenant_id=?", [$id, TID]) as $it) {
                q("UPDATE products SET stock=stock+? WHERE id=? AND tenant_id=?", [$it['quantity'], $it['product_id'], TID]);
                q("INSERT INTO stock_movements (tenant_id, product_id, movement_type, quantity, reference_type, reference_id, created_by) VALUES (?,?,'in',?,'order_cancel',?,?)",
                  [TID, $it['product_id'], $it['quantity'], $id, $me['id']]);
            }
        }
        q("UPDATE orders SET status=?, courier=?, courier_tracking=? WHERE id=? AND tenant_id=?",
          [$_POST['status'], $_POST['courier'] ?: null, $_POST['courier_tracking'] ?: null, $id, TID]);
        audit('order_status_' . $_POST['status'], 'orders', $id);
        flash('Order updated.');
    }
    if ($act === 'serial' && feature('warranty') && trim($_POST['serial'] ?? '')) {
        $p = row("SELECT p.warranty_months FROM products p WHERE p.id=? AND p.tenant_id=?", [$_POST['product_id'], TID]);
        try {
            q("INSERT INTO warranties (tenant_id, order_id, product_id, serial_number, start_date, end_date) VALUES (?,?,?,?,CURDATE(),CURDATE()+INTERVAL ? MONTH)",
              [TID, $id, (int)$_POST['product_id'], trim($_POST['serial']), (int)($p['warranty_months'] ?? 12)]);
            flash('Serial registered for warranty.');
        } catch (PDOException $ex) { flash('That serial number is already registered.', 'err'); }
    }
    redirect('admin/orders.php?view=' . $id);
}

// ----- Single order view -----
if (!empty($_GET['view'])) {
    $o = row("SELECT * FROM orders WHERE id=? AND tenant_id=?", [$_GET['view'], TID]) or exit('Not found');
    $items = rows("SELECT * FROM order_items WHERE order_id=? AND tenant_id=?", [$o['id'], TID]);
    $pay = row("SELECT * FROM payments WHERE order_id=? AND tenant_id=? ORDER BY id DESC", [$o['id'], TID]);
    $serials = rows("SELECT * FROM warranties WHERE order_id=? AND tenant_id=?", [$o['id'], TID]);
    admin_head('Order ' . $o['order_number']); ?>
    <p><a href="orders.php">← All orders</a> · <a href="<?= url('invoice.php?id=' . $o['id']) ?>" target="_blank">Invoice</a></p>
    <div class="grid2">
      <div class="card"><h3>Customer</h3><p><?= e($o['customer_name']) ?><br><?= e($o['phone']) ?> · <?= e($o['email']) ?><br><?= e($o['address']) ?>, <?= e($o['city']) ?></p>
        <p>Tracking code: <b><?= e($o['tracking_code']) ?></b> · Placed <?= e($o['created_at']) ?></p>
        <table class="tbl"><?php foreach ($items as $it): ?><tr><td><?= e($it['product_name']) ?> × <?= $it['quantity'] ?></td><td><?= money($it['unit_price'] * $it['quantity']) ?></td></tr><?php endforeach; ?>
        <tr><td>Shipping</td><td><?= money($o['shipping']) ?></td></tr><tr><td>Discount <?= e($o['coupon_code']) ?></td><td>− <?= money($o['discount']) ?></td></tr><tr><th>Total</th><th><?= money($o['total']) ?></th></tr></table></div>
      <div class="card"><h3>Payment verification</h3>
        <p>Method: <b><?= e($pay['gateway'] ?? '') ?></b> · Status: <span class="status s-<?= e($pay['status'] ?? '') ?>"><?= e($pay['status'] ?? '') ?></span><br>
           Reference #: <b><?= e($pay['reference_number'] ?? '—') ?></b> · Amount due: <b><?= money($pay['amount'] ?? 0) ?></b></p>
        <?php if (!empty($pay['receipt_path'])): ?>
          <?php if (str_ends_with($pay['receipt_path'], '.pdf')): ?><a class="btn ghost-dark" target="_blank" href="receipt.php?id=<?= $pay['id'] ?>">Open receipt PDF</a>
          <?php else: ?><a target="_blank" href="receipt.php?id=<?= $pay['id'] ?>"><img class="receipt" src="receipt.php?id=<?= $pay['id'] ?>" alt="Receipt"></a><?php endif; ?>
        <?php else: ?><p class="muted">No receipt uploaded.</p><?php endif; ?>
        <?php if ($pay && in_array($pay['status'], ['pending', 'receipt_uploaded'])): ?>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $o['id'] ?>">
          <label>Auditor notes<textarea name="notes" rows="2" placeholder="e.g. Amount and reference match bank statement"></textarea></label>
          <div class="row"><button class="btn" name="act" value="verify">✔ Verify payment</button><button class="btn danger" name="act" value="reject">✖ Reject</button></div></form>
        <?php elseif ($pay && $pay['auditor_notes']): ?><p>Notes: <?= e($pay['auditor_notes']) ?></p><?php endif; ?>
      </div>
    </div>
    <div class="grid2">
      <form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $o['id'] ?>"><input type="hidden" name="act" value="status">
        <h3>Status &amp; dispatch</h3>
        <label>Status<select name="status"><?php foreach ($statuses as $s): ?><option <?= $o['status'] === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?></select></label>
        <div class="grid2"><label>Courier<select name="courier"><option value="">—</option><?php foreach (['TCS', 'Leopards', 'M&P', 'Trax', 'Own delivery'] as $c): ?><option <?= $o['courier'] === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?></select></label>
        <label>Courier tracking #<input name="courier_tracking" value="<?= e($o['courier_tracking']) ?>"></label></div>
        <button class="btn">Save</button></form>
      <?php if (feature('warranty')): ?>
      <form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $o['id'] ?>"><input type="hidden" name="act" value="serial">
        <h3>Serial numbers (warranty)</h3>
        <?php foreach ($serials as $s): ?><p><?= e($s['serial_number']) ?> — until <?= e($s['end_date']) ?></p><?php endforeach; ?>
        <div class="row"><select name="product_id"><?php foreach ($items as $it): ?><option value="<?= $it['product_id'] ?>"><?= e($it['product_name']) ?></option><?php endforeach; ?></select>
        <input name="serial" placeholder="Serial number"><button class="btn sm">Register</button></div></form>
      <?php endif; ?>
    </div>
    <?php admin_foot(); exit;
}

// ----- List -----
$where = 'tenant_id=?'; $p = [TID];
if (in_array($_GET['status'] ?? '', $statuses, true)) { $where .= ' AND status=?'; $p[] = $_GET['status']; }
if ($s = trim($_GET['q'] ?? '')) { $where .= ' AND (order_number LIKE ? OR customer_name LIKE ? OR phone LIKE ? OR tracking_code=?)'; array_push($p, "%$s%", "%$s%", "%$s%", $s); }
$orders = rows("SELECT * FROM orders WHERE $where ORDER BY id DESC LIMIT 200", $p);
admin_head('Orders'); ?>
<form class="row card"><input name="q" placeholder="Order #, name, phone" value="<?= e($s) ?>">
  <select name="status"><option value="">All statuses</option><?php foreach ($statuses as $st): ?><option <?= ($_GET['status'] ?? '') === $st ? 'selected' : '' ?>><?= $st ?></option><?php endforeach; ?></select><button class="btn">Filter</button></form>
<div class="card"><table class="tbl"><tr><th>Order</th><th>Customer</th><th>City</th><th>Total</th><th>Status</th><th>Date</th></tr>
<?php foreach ($orders as $o): ?><tr><td><a href="?view=<?= $o['id'] ?>"><?= e($o['order_number']) ?></a></td><td><?= e($o['customer_name']) ?><br><small><?= e($o['phone']) ?></small></td>
<td><?= e($o['city']) ?></td><td><?= money($o['total']) ?></td><td><span class="status s-<?= e($o['status']) ?>"><?= e(str_replace('_', ' ', $o['status'])) ?></span></td><td><?= date('d M', strtotime($o['created_at'])) ?></td></tr><?php endforeach; ?>
</table><?php if (!$orders): ?><p class="muted">No orders found.</p><?php endif; ?></div>
<?php admin_foot();
