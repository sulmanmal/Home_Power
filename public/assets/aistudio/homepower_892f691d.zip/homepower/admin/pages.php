<?php
require __DIR__ . '/_init.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    if (($_POST['act'] ?? '') === 'del') { q("DELETE FROM cms_pages WHERE id=? AND tenant_id=?", [$id, TID]); flash('Page deleted.'); redirect('admin/pages.php'); }
    $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($_POST['slug'] ?: $_POST['title'])), '-');
    // Strip scripts from page HTML
    $content = preg_replace('#<script\b[^>]*>.*?</script>#is', '', $_POST['content']);
    $vals = [$slug, trim($_POST['title']), $content, $_POST['meta_description'], $_POST['status'] === 'draft' ? 'draft' : 'published', isset($_POST['show_in_menu']) ? 1 : 0];
    try {
        if ($id) q("UPDATE cms_pages SET slug=?, title=?, content=?, meta_description=?, status=?, show_in_menu=? WHERE id=? AND tenant_id=?", array_merge($vals, [$id, TID]));
        else q("INSERT INTO cms_pages (slug, title, content, meta_description, status, show_in_menu, tenant_id) VALUES (?,?,?,?,?,?,?)", array_merge($vals, [TID]));
        audit('page_save', 'cms_pages', $id ?: db()->lastInsertId());
        flash('Page saved.');
    } catch (PDOException $e) { flash('A page with that URL already exists.', 'err'); }
    redirect('admin/pages.php');
}
if (isset($_GET['edit'])) {
    $p = $_GET['edit'] === 'new' ? ['id' => 0, 'slug' => '', 'title' => '', 'content' => '', 'meta_description' => '', 'status' => 'published', 'show_in_menu' => 1]
        : row("SELECT * FROM cms_pages WHERE id=? AND tenant_id=?", [$_GET['edit'], TID]);
    admin_head($p['id'] ? 'Edit page' : 'New page'); ?>
    <p><a href="pages.php">← Pages</a></p>
    <form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $p['id'] ?>">
      <div class="grid2"><label>Title<input name="title" required value="<?= e($p['title']) ?>"></label><label>URL slug<input name="slug" value="<?= e($p['slug']) ?>" placeholder="auto"></label></div>
      <label>Content (HTML allowed)<textarea name="content" rows="14"><?= e($p['content']) ?></textarea></label>
      <label>Meta description<textarea name="meta_description" rows="2"><?= e($p['meta_description']) ?></textarea></label>
      <div class="row"><label>Status<select name="status"><option value="published">Published</option><option value="draft" <?= $p['status'] === 'draft' ? 'selected' : '' ?>>Draft</option></select></label>
      <label class="chk"><input type="checkbox" name="show_in_menu" <?= $p['show_in_menu'] ? 'checked' : '' ?>> Show in footer menu</label></div>
      <button class="btn">Save page</button></form>
    <?php admin_foot(); exit;
}
$list = rows("SELECT * FROM cms_pages WHERE tenant_id=? ORDER BY title", [TID]);
admin_head('Pages'); ?>
<a class="btn" href="?edit=new">+ New page</a>
<div class="card"><table class="tbl"><tr><th>Title</th><th>URL</th><th>Status</th><th></th></tr>
<?php foreach ($list as $p): ?><tr><td><a href="?edit=<?= $p['id'] ?>"><?= e($p['title']) ?></a></td><td><a target="_blank" href="<?= url('page.php?slug=' . urlencode($p['slug'])) ?>"><?= e($p['slug']) ?></a></td><td><?= e($p['status']) ?></td>
<td><form method="post" onsubmit="return confirm('Delete page?')"><?= csrf_field() ?><input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="link">Delete</button></form></td></tr><?php endforeach; ?></table></div>
<?php admin_foot();
