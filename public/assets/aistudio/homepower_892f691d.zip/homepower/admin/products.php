<?php
require __DIR__ . '/_init.php';
$me = require_admin(['inventory']);
$cats = rows("SELECT * FROM categories WHERE tenant_id=? ORDER BY name", [TID]);
function slugify($s) { return trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($s)), '-'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        if (!$id && plan_limit_reached('products')) { flash('Product limit for your plan reached. Upgrade to add more.', 'err'); redirect('admin/products.php'); }
        $f = $_POST;
        $data = [$f['category_id'] ?: null, trim($f['name']), slugify($f['slug'] ?: $f['name']), trim($f['sku']), $f['brand'], $f['description'],
                 (float)$f['price'], $f['price_installer'] !== '' ? (float)$f['price_installer'] : null, (int)$f['min_threshold'],
                 $f['capacity'], $f['voltage'], (int)$f['warranty_months'], (float)$f['weight_kg'], isset($f['is_featured']) ? 1 : 0, isset($f['is_active']) ? 1 : 0,
                 $f['meta_title'], $f['meta_description'], $f['meta_keywords'] ?? '',
                 ($f['sale_price'] ?? '') !== '' ? (float)$f['sale_price'] : null, isset($f['is_new']) ? 1 : 0, isset($f['is_upcoming']) ? 1 : 0, ($f['launch_date'] ?? '') ?: null];
        try {
            if ($id) {
                q("UPDATE products SET category_id=?, name=?, slug=?, sku=?, brand=?, description=?, price=?, price_installer=?, min_threshold=?, capacity=?, voltage=?,
                   warranty_months=?, weight_kg=?, is_featured=?, is_active=?, meta_title=?, meta_description=?, meta_keywords=?, sale_price=?, is_new=?, is_upcoming=?, launch_date=? WHERE id=? AND tenant_id=?", array_merge($data, [$id, TID]));
            } else {
                q("INSERT INTO products (category_id, name, slug, sku, brand, description, price, price_installer, min_threshold, capacity, voltage, warranty_months, weight_kg,
                   is_featured, is_active, meta_title, meta_description, meta_keywords, sale_price, is_new, is_upcoming, launch_date, tenant_id, stock) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array_merge($data, [TID, (int)$f['stock']]));
                $id = db()->lastInsertId();
                if ((int)$f['stock']) q("INSERT INTO stock_movements (tenant_id, product_id, movement_type, quantity, note, created_by) VALUES (?,?,'in',?,'Opening stock',?)", [TID, $id, (int)$f['stock'], $me['id']]);
            }
            if ($img = save_upload('image', false, true)) q("UPDATE products SET image=? WHERE id=? AND tenant_id=?", [$img['path'], $id, TID]);
            audit('product_save', 'products', $id);
            flash('Product saved.');
        } catch (PDOException $ex) { flash('SKU or URL slug already exists in your store.', 'err'); redirect('admin/products.php?edit=' . ($id ?: 'new')); }
    }
    if ($act === 'stock') {
        $id = (int)$_POST['id']; $qty = (int)$_POST['qty']; $type = $_POST['type'] === 'in' ? 'in' : ($_POST['type'] === 'out' ? 'out' : 'adjustment');
        $delta = $type === 'out' ? -abs($qty) : ($type === 'in' ? abs($qty) : $qty);
        q("UPDATE products SET stock=GREATEST(0, stock+?) WHERE id=? AND tenant_id=?", [$delta, $id, TID]);
        q("INSERT INTO stock_movements (tenant_id, product_id, movement_type, quantity, note, created_by) VALUES (?,?,?,?,?,?)", [TID, $id, $type, $delta, $_POST['note'] ?? '', $me['id']]);
        audit('stock_' . $type, 'products', $id);
        flash('Stock updated.');
        redirect('admin/products.php?edit=' . $id);
    }
    if ($act === 'delete') {
        q("UPDATE products SET is_active=0 WHERE id=? AND tenant_id=?", [(int)$_POST['id'], TID]);   // soft delete keeps order history intact
        audit('product_archive', 'products', (int)$_POST['id']);
        flash('Product hidden from store.');
    }
    redirect('admin/products.php');
}

if (isset($_GET['edit'])) {
    $p = $_GET['edit'] === 'new' ? ['id' => 0, 'category_id' => '', 'name' => '', 'slug' => '', 'sku' => '', 'brand' => '', 'description' => '', 'price' => '', 'price_installer' => '',
        'stock' => 0, 'min_threshold' => 5, 'capacity' => '', 'voltage' => '', 'warranty_months' => 12, 'weight_kg' => 1, 'is_featured' => 0, 'is_active' => 1, 'meta_title' => '', 'meta_description' => '', 'meta_keywords' => '', 'image' => '',
        'sale_price' => '', 'is_new' => 1, 'is_upcoming' => 0, 'launch_date' => '']
        : row("SELECT * FROM products WHERE id=? AND tenant_id=?", [$_GET['edit'], TID]);
    if (!$p) exit('Not found');
    $moves = $p['id'] ? rows("SELECT * FROM stock_movements WHERE product_id=? AND tenant_id=? ORDER BY id DESC LIMIT 10", [$p['id'], TID]) : [];
    admin_head($p['id'] ? 'Edit product' : 'New product'); ?>
    <p><a href="products.php">← Products</a></p>
    <div class="grid2 wide">
    <form method="post" enctype="multipart/form-data" class="card"><?= csrf_field() ?><input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= $p['id'] ?>">
      <label>Name<input name="name" required value="<?= e($p['name']) ?>"></label>
      <div class="grid3"><label>SKU<input name="sku" required value="<?= e($p['sku']) ?>"></label><label>Brand<input name="brand" value="<?= e($p['brand']) ?>"></label>
      <label>Category<select name="category_id"><option value="">—</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>" <?= $p['category_id'] == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></label></div>
      <div class="grid3"><label>Retail price (Rs)<input type="number" step="0.01" name="price" required value="<?= e($p['price']) ?>"></label>
      <label>Installer price (Rs)<input type="number" step="0.01" name="price_installer" value="<?= e($p['price_installer']) ?>"></label>
      <label><?= $p['id'] ? 'Low-stock threshold' : 'Opening stock' ?><input type="number" name="<?= $p['id'] ? 'min_threshold' : 'stock' ?>" value="<?= e($p['id'] ? $p['min_threshold'] : 0) ?>"></label></div>
      <?php if (!$p['id']): ?><input type="hidden" name="min_threshold" value="5"><?php endif; ?>
      <div class="grid3"><label>Capacity (e.g. 6 kW, 200 Ah, 585 W)<input name="capacity" value="<?= e($p['capacity']) ?>"></label>
      <label>Voltage<input name="voltage" value="<?= e($p['voltage']) ?>" placeholder="12V / 24V / 48V"></label>
      <label>Warranty (months)<input type="number" name="warranty_months" value="<?= e($p['warranty_months']) ?>"></label></div>
      <div class="grid3"><label>Weight (kg)<input type="number" step="0.1" name="weight_kg" value="<?= e($p['weight_kg']) ?>"></label>
      <label>URL slug<input name="slug" value="<?= e($p['slug']) ?>" placeholder="auto"></label>
      <label>Image<input type="file" name="image" accept="image/*"></label></div>
      <?php if ($p['image']): ?><img src="<?= url($p['image']) ?>" style="max-height:90px"><?php endif; ?>
      <label>Description<textarea name="description" rows="5"><?= e($p['description']) ?></textarea></label>
      <div class="grid3"><label>Sale price (Rs) — leave empty for no sale<input type="number" step="0.01" name="sale_price" value="<?= e($p['sale_price']) ?>"></label>
      <label>Launch date (upcoming)<input type="date" name="launch_date" value="<?= e($p['launch_date']) ?>"></label>
      <div class="flags"><b>Homepage sections</b>
        <label class="chk"><input type="checkbox" name="is_featured" <?= $p['is_featured'] ? 'checked' : '' ?>> Featured</label>
        <label class="chk"><input type="checkbox" name="is_new" <?= $p['is_new'] ? 'checked' : '' ?>> New arrival</label>
        <label class="chk"><input type="checkbox" name="is_upcoming" <?= $p['is_upcoming'] ? 'checked' : '' ?>> Upcoming (not yet for sale)</label></div></div>
      <details open><summary><b>SEO</b></summary>
        <label>Meta title <span class="counter" data-max="60"></span><input name="meta_title" class="js-count" value="<?= e($p['meta_title']) ?>" placeholder="<?= e($p['name']) ?>"></label>
        <label>Meta description <span class="counter" data-max="160"></span><textarea name="meta_description" class="js-count" rows="2"><?= e($p['meta_description']) ?></textarea></label>
        <label>Meta keywords<input name="meta_keywords" value="<?= e($p['meta_keywords']) ?>"></label></details>
      <label class="chk"><input type="checkbox" name="is_active" <?= $p['is_active'] ? 'checked' : '' ?>> Visible in store</label>
      <button class="btn">Save product</button>
    </form>
    <?php if ($p['id']): ?>
    <div><form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="act" value="stock"><input type="hidden" name="id" value="<?= $p['id'] ?>">
      <h3>Stock: <?= (int)$p['stock'] ?></h3>
      <div class="row"><select name="type"><option value="in">Stock in</option><option value="out">Stock out</option><option value="adjustment">Adjust (±)</option></select>
      <input type="number" name="qty" required style="width:90px"></div><label>Note<input name="note" placeholder="e.g. PO-102 received"></label><button class="btn sm">Update stock</button></form>
      <div class="card"><h3>Stock history</h3><table class="tbl"><?php foreach ($moves as $m): ?><tr><td><?= e($m['movement_type']) ?></td><td><?= $m['quantity'] > 0 ? '+' : '' ?><?= $m['quantity'] ?></td><td><small><?= e($m['note'] ?: $m['reference_type']) ?></small></td><td><small><?= date('d M', strtotime($m['created_at'])) ?></small></td></tr><?php endforeach; ?></table></div>
    </div><?php endif; ?>
    </div>
    <script>$(document).on('input','.js-count',function(){var $c=$(this).closest('label').find('.counter'),m=$c.data('max'),n=this.value.length;$c.text(n+'/'+m).css('color',n>m?'#dc2626':'#059669')});$('.js-count').trigger('input');</script>
    <?php admin_foot(); exit;
}

$where = 'p.tenant_id=?'; $par = [TID];
if (!empty($_GET['low'])) $where .= ' AND p.stock<=p.min_threshold';
if ($s = trim($_GET['q'] ?? '')) { $where .= ' AND (p.name LIKE ? OR p.sku LIKE ?)'; array_push($par, "%$s%", "%$s%"); }
$list = rows("SELECT p.*, c.name cat FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE $where ORDER BY p.id DESC", $par);
admin_head('Products'); ?>
<div class="row"><a class="btn" href="?edit=new">+ Add product</a><form class="row"><input name="q" placeholder="Search name or SKU" value="<?= e($s) ?>"><button class="btn ghost-dark">Search</button></form></div>
<div class="card"><table class="tbl"><tr><th>Product</th><th>SKU</th><th>Category</th><th>Price</th><th>Stock</th><th></th></tr>
<?php foreach ($list as $p): ?><tr class="<?= $p['is_active'] ? '' : 'dim' ?>"><td><a href="?edit=<?= $p['id'] ?>"><?= e($p['name']) ?></a><?= $p['is_featured'] ? ' <span class="tag">Featured</span>' : '' ?><?= $p['is_new'] ? ' <span class="tag">New</span>' : '' ?><?= $p['is_upcoming'] ? ' <span class="tag">Upcoming</span>' : '' ?><?= $p['sale_price'] > 0 && $p['sale_price'] < $p['price'] ? ' <span class="tag sale">Sale</span>' : '' ?></td><td><?= e($p['sku']) ?></td><td><?= e($p['cat']) ?></td>
<td><?= money(eff_price($p)) ?><?= eff_price($p) < $p['price'] ? '<br><del>' . money($p['price']) . '</del>' : '' ?></td><td class="<?= $p['stock'] <= $p['min_threshold'] ? 'out' : '' ?>"><?= $p['stock'] ?></td>
<td><?php if ($p['is_active']): ?><form method="post" onsubmit="return confirm('Hide this product from the store?')"><?= csrf_field() ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="link">Hide</button></form><?php endif; ?></td></tr><?php endforeach; ?>
</table></div>
<?php admin_foot();
