<?php
// Streams a private payment receipt — only to logged-in admins of the same tenant.
require __DIR__ . '/_init.php';
require_admin(['auditor', 'support']);
$p = row("SELECT receipt_path FROM payments WHERE id=? AND tenant_id=?", [$_GET['id'] ?? 0, TID]);
$file = $p ? realpath(__DIR__ . '/../' . $p['receipt_path']) : false;
if (!$file || !str_starts_with($file, realpath(__DIR__ . '/../private'))) { http_response_code(404); exit; }
header('Content-Type: ' . mime_content_type($file));
header('Content-Disposition: inline');
readfile($file);
