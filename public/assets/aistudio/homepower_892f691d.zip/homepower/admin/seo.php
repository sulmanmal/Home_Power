<?php
require __DIR__ . '/_init.php';
require_admin();
$pageKeys = ['home' => 'Homepage', 'shop' => 'Shop', 'calculator' => 'Solar calculator', 'compare' => 'Compare', 'warranty' => 'Warranty check', 'track' => 'Track order'];
$tab = $_GET['tab'] ?? 'general';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'general') {
        foreach (['seo_default_title', 'seo_default_desc', 'seo_keywords', 'ga_id', 'google_verify', 'bing_verify'] as $k) save_setting($k, trim($_POST[$k] ?? ''));
        save_setting('robots_noindex', isset($_POST['robots_noindex']) ? '1' : '0');
        save_setting('head_code', preg_match('#<\s*(script|meta|link|noscript)#i', $_POST['head_code'] ?? '') || trim($_POST['head_code'] ?? '') === '' ? $_POST['head_code'] : '');
        if ($img = save_upload('og_image', false, true)) save_setting('og_image', $img['path']);
        flash('SEO settings saved.');
    }
    if ($act === 'pages') {
        foreach ($_POST['m'] ?? [] as $key => $m) {
            if (!isset($pageKeys[$key])) continue;
            q("INSERT INTO seo_meta (tenant_id, page_key, meta_title, meta_description, meta_keywords) VALUES (?,?,?,?,?)
               ON DUPLICATE KEY UPDATE meta_title=VALUES(meta_title), meta_description=VALUES(meta_description), meta_keywords=VALUES(meta_keywords)",
              [TID, $key, trim($m['title']), trim($m['desc']), trim($m['kw'])]);
            if ($img = save_upload('og_' . $key, false, true)) q("UPDATE seo_meta SET og_image=? WHERE tenant_id=? AND page_key=?", [$img['path'], TID, $key]);
        }
        flash('Page SEO saved.');
    }
    if ($act === 'product') {
        q("UPDATE products SET meta_title=?, meta_description=?, meta_keywords=?, slug=? WHERE id=? AND tenant_id=?",
          [trim($_POST['meta_title']), trim($_POST['meta_description']), trim($_POST['meta_keywords']),
           trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($_POST['slug'])), '-'), (int)$_POST['id'], TID]);
        if (is_ajax()) json_out(['ok' => true]);
        flash('Product SEO saved.');
    }
    if ($act === 'redirect_add') {
        $src = '/' . ltrim(trim($_POST['source_url']), '/');
        try { q("INSERT INTO seo_redirects (tenant_id, source_url, target_url, redirect_code) VALUES (?,?,?,?)", [TID, $src, trim($_POST['target_url']), $_POST['code'] === '302' ? 302 : 301]); flash('Redirect added.'); }
        catch (PDOException $e) { flash('A redirect for that URL already exists.', 'err'); }
    }
    if ($act === 'redirect_del') { q("DELETE FROM seo_redirects WHERE id=? AND tenant_id=?", [(int)$_POST['id'], TID]); flash('Redirect removed.'); }
    audit('seo_' . $act);
    redirect('admin/seo.php?tab=' . urlencode($_POST['tab'] ?? 'general'));
}

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$siteBase = $scheme . '://' . $_SERVER['HTTP_HOST'] . APP_PATH;
admin_head('SEO manager'); ?>
<div class="tabs">
  <?php foreach (['general' => 'General', 'pages' => 'Page meta', 'products' => 'Products SEO', 'redirects' => 'Redirects', 'audit' => 'SEO audit'] as $k => $l): ?>
    <a class="<?= $tab === $k ? 'on' : '' ?>" href="?tab=<?= $k ?>"><?= $l ?></a><?php endforeach; ?>
</div>

<?php if ($tab === 'general'): ?>
<form method="post" enctype="multipart/form-data" class="card"><?= csrf_field() ?><input type="hidden" name="act" value="general"><input type="hidden" name="tab" value="general">
  <h3>Default meta tags</h3><p class="muted">Used on any page that has no meta of its own.</p>
  <label>Default title <span class="counter" data-max="60"></span><input name="seo_default_title" class="js-count" maxlength="120" value="<?= e(setting('seo_default_title')) ?>"></label>
  <label>Default description <span class="counter" data-max="160"></span><textarea name="seo_default_desc" class="js-count" rows="2"><?= e(setting('seo_default_desc')) ?></textarea></label>
  <label>Default keywords (comma separated)<input name="seo_keywords" value="<?= e(setting('seo_keywords')) ?>"></label>
  <div class="serp" id="serp"><small><?= e($siteBase) ?></small><b></b><span></span></div>
  <label>Social share image (1200 × 630)<input type="file" name="og_image" accept="image/*"></label>
  <?php if (setting('og_image')): ?><img src="<?= url(setting('og_image')) ?>" style="max-height:80px;border-radius:8px"><?php endif; ?>
  <h3>Analytics &amp; verification</h3>
  <div class="grid3"><label>Google Analytics 4 ID<input name="ga_id" placeholder="G-XXXXXXX" value="<?= e(setting('ga_id')) ?>"></label>
    <label>Google Search Console code<input name="google_verify" placeholder="content value only" value="<?= e(setting('google_verify')) ?>"></label>
    <label>Bing verification code<input name="bing_verify" value="<?= e(setting('bing_verify')) ?>"></label></div>
  <label>Extra head code (Facebook Pixel, tag manager…)<textarea name="head_code" rows="4" placeholder="<script>…</script>"><?= e(setting('head_code')) ?></textarea></label>
  <label class="chk"><input type="checkbox" name="robots_noindex" <?= setting('robots_noindex') === '1' ? 'checked' : '' ?>> Hide the whole store from search engines (use while building)</label><br><br>
  <button class="btn">Save</button>
  <p class="muted">Sitemap: <a target="_blank" href="<?= e($siteBase) ?>/sitemap.xml"><?= e($siteBase) ?>/sitemap.xml</a> · Robots: <a target="_blank" href="<?= e($siteBase) ?>/robots.txt">robots.txt</a> — submit the sitemap in Google Search Console.</p>
</form>

<?php elseif ($tab === 'pages'):
  $meta = []; foreach (rows("SELECT * FROM seo_meta WHERE tenant_id=?", [TID]) as $m) $meta[$m['page_key']] = $m; ?>
<form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="act" value="pages"><input type="hidden" name="tab" value="pages">
<?php foreach ($pageKeys as $k => $l): $m = $meta[$k] ?? []; ?>
  <div class="card"><h3><?= e($l) ?></h3>
    <label>Meta title <span class="counter" data-max="60"></span><input class="js-count" name="m[<?= $k ?>][title]" value="<?= e($m['meta_title'] ?? '') ?>"></label>
    <label>Meta description <span class="counter" data-max="160"></span><textarea class="js-count" name="m[<?= $k ?>][desc]" rows="2"><?= e($m['meta_description'] ?? '') ?></textarea></label>
    <div class="grid2"><label>Keywords<input name="m[<?= $k ?>][kw]" value="<?= e($m['meta_keywords'] ?? '') ?>"></label>
    <label>Share image<input type="file" name="og_<?= $k ?>" accept="image/*"></label></div>
  </div>
<?php endforeach; ?>
<p class="muted">CMS pages (About, policies…) have their own meta description in <a href="pages.php">Pages</a>.</p>
<button class="btn">Save all</button></form>

<?php elseif ($tab === 'products'):
  $list = rows("SELECT id, name, slug, meta_title, meta_description, meta_keywords FROM products WHERE tenant_id=? ORDER BY name", [TID]); ?>
<div class="card"><p class="muted">Edit inline and press Save on each row. Empty title/description fall back to the product name and description.</p>
<input id="pfilter" placeholder="Filter products…" style="margin-bottom:12px">
<table class="tbl seo-tbl"><tr><th>Product</th><th>URL slug</th><th>Meta title</th><th>Meta description</th><th>Keywords</th><th></th></tr>
<?php foreach ($list as $p): ?>
<tr><td><b><?= e($p['name']) ?></b></td>
  <td><input name="slug" value="<?= e($p['slug']) ?>"></td>
  <td><input name="meta_title" class="js-count" value="<?= e($p['meta_title']) ?>"><span class="counter" data-max="60"></span></td>
  <td><textarea name="meta_description" class="js-count" rows="2"><?= e($p['meta_description']) ?></textarea><span class="counter" data-max="160"></span></td>
  <td><input name="meta_keywords" value="<?= e($p['meta_keywords']) ?>"></td>
  <td><button class="btn sm js-psave" data-id="<?= $p['id'] ?>">Save</button></td></tr>
<?php endforeach; ?></table></div>
<script>
$('.js-psave').on('click', function(){
  var $b=$(this), $tr=$b.closest('tr'), d={act:'product', id:$b.data('id'), csrf:<?= json_encode(csrf_token()) ?>};
  $tr.find('input,textarea').each(function(){ d[this.name]=this.value; });
  $b.text('…'); $.post('seo.php', d, function(){ $b.text('✓ Saved'); setTimeout(function(){ $b.text('Save'); }, 1500); }, 'json');
});
$('#pfilter').on('input', function(){ var q=this.value.toLowerCase(); $('.seo-tbl tr:gt(0)').each(function(){ $(this).toggle($(this).text().toLowerCase().indexOf(q)>-1 || $(this).find('b').text().toLowerCase().indexOf(q)>-1); }); });
</script>

<?php elseif ($tab === 'redirects'):
  $list = rows("SELECT * FROM seo_redirects WHERE tenant_id=? ORDER BY id DESC", [TID]); ?>
<form method="post" class="card row"><?= csrf_field() ?><input type="hidden" name="act" value="redirect_add"><input type="hidden" name="tab" value="redirects">
  <input name="source_url" placeholder="Old path e.g. /old-inverter-page" required><input name="target_url" placeholder="New URL e.g. /homepower/shop.php" required>
  <select name="code" style="max-width:150px"><option value="301">301 permanent</option><option value="302">302 temporary</option></select><button class="btn">Add redirect</button></form>
<div class="card"><table class="tbl"><tr><th>From</th><th>To</th><th>Type</th><th></th></tr>
<?php foreach ($list as $r): ?><tr><td><?= e($r['source_url']) ?></td><td><?= e($r['target_url']) ?></td><td><?= $r['redirect_code'] ?></td>
<td><form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="redirect_del"><input type="hidden" name="tab" value="redirects"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="link">Remove</button></form></td></tr><?php endforeach; ?>
</table><?php if (!$list): ?><p class="muted">No redirects yet. Use these when you rename a product or move a page so old links and Google rankings are kept.</p><?php endif; ?></div>

<?php else:
  $issues = [];
  foreach (rows("SELECT id, name, meta_title, meta_description, description, image FROM products WHERE tenant_id=? AND is_active=1", [TID]) as $p) {
      $l = '<a href="products.php?edit=' . $p['id'] . '">' . e($p['name']) . '</a>';
      if (!$p['image']) $issues[] = ['high', $l, 'No product image'];
      if (!$p['meta_description'] && mb_strlen($p['description'] ?? '') < 80) $issues[] = ['high', $l, 'No meta description and a very short product description'];
      elseif (!$p['meta_description']) $issues[] = ['low', $l, 'No meta description (auto-generated from description)'];
      if ($p['meta_title'] && mb_strlen($p['meta_title']) > 65) $issues[] = ['low', $l, 'Meta title longer than 65 characters'];
  }
  foreach (rows("SELECT a.name, COUNT(*) n FROM products a WHERE tenant_id=? AND is_active=1 GROUP BY a.name HAVING n>1", [TID]) as $d) $issues[] = ['med', e($d['name']), 'Duplicate product name (' . $d['n'] . ' products)'];
  if (!setting('seo_default_desc') && !seo_get('home')) $issues[] = ['high', 'Homepage', 'No homepage meta description'];
  if (!setting('google_verify')) $issues[] = ['low', 'Search Console', 'Site not verified with Google'];
  if (!setting('og_image')) $issues[] = ['low', 'Social sharing', 'No default share image'];
  if (setting('robots_noindex') === '1') $issues[] = ['high', 'Whole store', 'Hidden from search engines (General tab)'];
  $score = max(0, 100 - array_sum(array_map(fn($i) => ['high' => 8, 'med' => 4, 'low' => 1][$i[0]], $issues))); ?>
<div class="kpis"><div class="card"><small>SEO health score</small><b style="color:<?= $score >= 80 ? '#059669' : ($score >= 50 ? '#d97706' : '#dc2626') ?>"><?= $score ?>/100</b></div>
  <div class="card"><small>Issues found</small><b><?= count($issues) ?></b></div></div>
<div class="card"><table class="tbl"><tr><th>Priority</th><th>Where</th><th>Issue</th></tr>
<?php foreach ($issues as $i): ?><tr><td><span class="status s-<?= ['high' => 'cancelled', 'med' => 'pending', 'low' => 'dispatched'][$i[0]] ?>"><?= $i[0] ?></span></td><td><?= $i[1] ?></td><td><?= e($i[2]) ?></td></tr><?php endforeach; ?>
</table><?php if (!$issues): ?><p class="in">✔ No issues found.</p><?php endif; ?></div>
<?php endif; ?>

<script>
// character counters + live Google preview
function cnt(){ $('.js-count').each(function(){ var $c=$(this).siblings('.counter').add($(this).closest('label').find('.counter')).first(), max=$c.data('max'), n=this.value.length;
  $c.text(n+'/'+max).css('color', n>max ? '#dc2626' : (n>max*0.5 ? '#059669' : '#94a3b8')); });
  $('#serp b').text($('[name=seo_default_title]').val()||'Your page title'); $('#serp span').text($('[name=seo_default_desc]').val()||'Your description shows here in Google results.'); }
$(document).on('input', '.js-count', cnt); cnt();
</script>
<?php admin_foot();
