<?php
require __DIR__ . '/_init.php';
require_admin();
$fields = [
  'Branding' => ['tagline' => 'Tagline', 'primary_color' => 'Primary colour', 'accent_color' => 'Accent colour', 'announcement' => 'Top announcement bar text'],
  'Homepage stats' => ['stat_customers' => 'Happy customers (e.g. 10,000+)', 'stat_cities' => 'Cities served', 'stat_installs' => 'Solar installed', 'stat_years' => 'Years of trust'],
  'Contact' => ['phone' => 'Phone', 'whatsapp' => 'WhatsApp number (with country code)', 'email' => 'Email', 'address' => 'Address', 'ntn' => 'NTN (shown on invoices)'],
  'Payment details shown at checkout' => ['bank_details' => 'Bank account details', 'jazzcash' => 'JazzCash account', 'easypaisa' => 'Easypaisa account'],
  'Solar calculator' => ['tariff_per_unit' => 'Default electricity rate (Rs/unit)'],
];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($fields as $grp) foreach ($grp as $k => $_) if (isset($_POST[$k])) save_setting($k, trim($_POST[$k]));
    if ($img = save_upload('logo', false, true)) save_setting('logo', $img['path']);
    if ($img = save_upload('favicon', false, true)) save_setting('favicon', $img['path']);
    audit('settings_update');
    flash('Settings saved.'); redirect('admin/settings.php');
}
$domains = rows("SELECT * FROM tenant_domains WHERE tenant_id=?", [TID]);
admin_head('Store settings'); ?>
<form method="post" enctype="multipart/form-data" class="card"><?= csrf_field() ?>
<?php foreach ($fields as $g => $grp): ?><h3><?= e($g) ?></h3><div class="grid2">
  <?php foreach ($grp as $k => $l): ?><label><?= e($l) ?>
    <?php if (str_contains($k, 'color')): ?><input type="color" name="<?= $k ?>" value="<?= e(setting($k, '#0f766e')) ?>">
    <?php elseif ($k === 'bank_details' || $k === 'address'): ?><textarea name="<?= $k ?>" rows="2"><?= e(setting($k)) ?></textarea>
    <?php else: ?><input name="<?= $k ?>" value="<?= e(setting($k)) ?>"><?php endif; ?></label><?php endforeach; ?>
  </div><?php endforeach; ?>
  <div class="grid2"><label>Logo<input type="file" name="logo" accept="image/*"></label><label>Favicon<input type="file" name="favicon" accept="image/*"></label></div>
  <button class="btn">Save settings</button>
</form>
<div class="card"><h3>Your store addresses</h3>
  <p><?= e($TENANT['slug']) ?>.<?= e(PLATFORM_DOMAIN) ?> (free subdomain)</p>
  <?php foreach ($domains as $d): ?><p><?= e($d['domain']) ?> <?= $d['verified_at'] ? '<span class="in">✔ active</span>' : '<span class="out">pending DNS</span>' ?></p><?php endforeach; ?>
  <p class="muted">To use your own domain, point its DNS A record to the platform server and ask the platform owner to attach it.</p></div>
<?php admin_foot();
