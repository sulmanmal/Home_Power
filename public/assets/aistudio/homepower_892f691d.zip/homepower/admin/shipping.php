<?php
require __DIR__ . '/_init.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'add') q("INSERT INTO shipping_rates (tenant_id, zone_name, base_cost, per_kg) VALUES (?,?,?,?)", [TID, trim($_POST['zone_name']), (float)$_POST['base_cost'], (float)$_POST['per_kg']]);
    if ($act === 'save') foreach ($_POST['z'] ?? [] as $id => $z)
        q("UPDATE shipping_rates SET zone_name=?, base_cost=?, per_kg=? WHERE id=? AND tenant_id=?", [$z['zone_name'], (float)$z['base_cost'], (float)$z['per_kg'], (int)$id, TID]);
    if ($act === 'del') q("DELETE FROM shipping_rates WHERE id=? AND tenant_id=?", [(int)$_POST['id'], TID]);
    flash('Shipping updated.'); redirect('admin/shipping.php');
}
$list = rows("SELECT * FROM shipping_rates WHERE tenant_id=? ORDER BY base_cost", [TID]);
admin_head('Shipping zones'); ?>
<p class="muted">Shipping = base cost + (rate per kg × total cart weight).</p>
<form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="act" value="save"><table class="tbl"><tr><th>Zone</th><th>Base cost (Rs)</th><th>Per kg (Rs)</th></tr>
<?php foreach ($list as $z): ?><tr><td><input name="z[<?= $z['id'] ?>][zone_name]" value="<?= e($z['zone_name']) ?>"></td><td><input type="number" name="z[<?= $z['id'] ?>][base_cost]" value="<?= e($z['base_cost']) ?>"></td><td><input type="number" step="0.01" name="z[<?= $z['id'] ?>][per_kg]" value="<?= e($z['per_kg']) ?>"></td></tr><?php endforeach; ?>
</table><button class="btn">Save changes</button></form>
<form method="post" class="card row"><?= csrf_field() ?><input type="hidden" name="act" value="add"><input name="zone_name" placeholder="New zone (e.g. Karachi)" required><input type="number" name="base_cost" placeholder="Base" required><input type="number" step="0.01" name="per_kg" placeholder="Per kg" value="0"><button class="btn">Add zone</button></form>
<?php admin_foot();
