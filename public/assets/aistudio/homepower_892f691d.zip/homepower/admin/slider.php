<?php
require __DIR__ . '/_init.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'settings') {
        save_setting('slider_height', (string)max(250, min(900, (int)$_POST['slider_height'])));
        save_setting('slider_autoplay', (string)max(0, min(30, (int)$_POST['slider_autoplay'])));
        save_setting('slider_effect', $_POST['slider_effect'] === 'slide' ? 'slide' : 'fade');
        flash('Slider settings saved.');
    }
    if ($act === 'save') {
        $id = (int)$_POST['id'];
        $align = in_array($_POST['text_align'], ['left', 'center', 'right'], true) ? $_POST['text_align'] : 'left';
        $color = fn($c, $d) => preg_match('/^#[0-9a-f]{6}$/i', $c) ? $c : $d;
        $vals = [trim($_POST['title']), trim($_POST['subtitle']), trim($_POST['btn_text']), trim($_POST['btn_link']), $align,
                 $color($_POST['text_color'], '#0b1220'), $color($_POST['bg_color'], '#eef6f4'), isset($_POST['is_active']) ? 1 : 0];
        if ($id) q("UPDATE sliders SET title=?, subtitle=?, btn_text=?, btn_link=?, text_align=?, text_color=?, bg_color=?, is_active=? WHERE id=? AND tenant_id=?", array_merge($vals, [$id, TID]));
        else {
            $next = (int)row("SELECT COALESCE(MAX(sort_order),0)+1 n FROM sliders WHERE tenant_id=?", [TID])['n'];
            q("INSERT INTO sliders (title, subtitle, btn_text, btn_link, text_align, text_color, bg_color, is_active, tenant_id, sort_order)
               VALUES (?,?,?,?,?,?,?,?,?,?)", array_merge($vals, [TID, $next]));
            $id = db()->lastInsertId();
        }
        if ($img = save_upload('image', false, true)) q("UPDATE sliders SET image=? WHERE id=? AND tenant_id=?", [$img['path'], $id, TID]);
        if (isset($_POST['remove_image'])) q("UPDATE sliders SET image=NULL WHERE id=? AND tenant_id=?", [$id, TID]);
        audit('slider_save', 'sliders', $id); flash('Slide saved.');
    }
    if ($act === 'del') { q("DELETE FROM sliders WHERE id=? AND tenant_id=?", [(int)$_POST['id'], TID]); flash('Slide deleted.'); }
    if ($act === 'order') {   // AJAX from drag-and-drop
        foreach ((array)($_POST['ids'] ?? []) as $i => $id) q("UPDATE sliders SET sort_order=? WHERE id=? AND tenant_id=?", [$i + 1, (int)$id, TID]);
        json_out(['ok' => true]);
    }
    redirect('admin/slider.php' . (isset($_POST['id']) && $act === 'save' ? '' : ''));
}

$edit = null;
if (isset($_GET['edit'])) $edit = $_GET['edit'] === 'new'
    ? ['id' => 0, 'image' => '', 'title' => '', 'subtitle' => '', 'btn_text' => 'Shop now', 'btn_link' => 'shop.php', 'text_align' => 'left', 'text_color' => '#0b1220', 'bg_color' => '#eef6f4', 'is_active' => 1]
    : row("SELECT * FROM sliders WHERE id=? AND tenant_id=?", [$_GET['edit'], TID]);
$slides = rows("SELECT * FROM sliders WHERE tenant_id=? ORDER BY sort_order, id", [TID]);
admin_head('Homepage slider'); ?>
<p class="muted">Full-width slider at the top of the homepage. Recommended image size: <b>1920 × <?= e(setting('slider_height', '500')) ?> px</b> (JPG/WebP, under 500 KB). Slides without an image use the background colour with a sun graphic.</p>

<?php if ($edit): ?>
<form method="post" enctype="multipart/form-data" class="card"><?= csrf_field() ?><input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= $edit['id'] ?>">
  <h3><?= $edit['id'] ? 'Edit slide' : 'New slide' ?></h3>
  <div class="slide-preview" id="slidePreview" style="background-color:<?= e($edit['bg_color']) ?>;color:<?= e($edit['text_color']) ?>;<?= $edit['image'] ? "background-image:url('" . e(url($edit['image'])) . "')" : '' ?>">
    <div class="sp-copy sp-<?= e($edit['text_align']) ?>"><b class="sp-title"><?= e($edit['title'] ?: 'Slide title') ?></b><span class="sp-sub"><?= e($edit['subtitle']) ?></span><span class="sp-btn"><?= e($edit['btn_text']) ?></span></div>
  </div>
  <div class="grid2"><label>Title<input name="title" value="<?= e($edit['title']) ?>" data-p=".sp-title"></label><label>Subtitle<input name="subtitle" value="<?= e($edit['subtitle']) ?>" data-p=".sp-sub"></label></div>
  <div class="grid3"><label>Button text<input name="btn_text" value="<?= e($edit['btn_text']) ?>" data-p=".sp-btn"></label>
    <label>Button link<input name="btn_link" value="<?= e($edit['btn_link']) ?>" placeholder="shop.php or https://…"></label>
    <label>Text position<select name="text_align"><?php foreach (['left', 'center', 'right'] as $a): ?><option <?= $edit['text_align'] === $a ? 'selected' : '' ?>><?= $a ?></option><?php endforeach; ?></select></label></div>
  <div class="grid3"><label>Text colour<input type="color" name="text_color" value="<?= e($edit['text_color']) ?>"></label>
    <label>Background colour<input type="color" name="bg_color" value="<?= e($edit['bg_color']) ?>"></label>
    <label>Background image<input type="file" name="image" accept="image/*"></label></div>
  <?php if ($edit['image']): ?><label class="chk"><input type="checkbox" name="remove_image"> Remove current image</label><br><?php endif; ?>
  <label class="chk"><input type="checkbox" name="is_active" <?= $edit['is_active'] ? 'checked' : '' ?>> Show this slide</label><br><br>
  <button class="btn">Save slide</button> <a href="slider.php">Cancel</a>
</form>
<script>
$('[data-p]').on('input', function(){ $('#slidePreview ' + $(this).data('p')).text($(this).val()); });
$('[name=text_color]').on('input', function(){ $('#slidePreview').css('color', this.value); });
$('[name=bg_color]').on('input', function(){ $('#slidePreview').css('background-color', this.value); });
$('[name=text_align]').on('change', function(){ $('#slidePreview .sp-copy').attr('class', 'sp-copy sp-' + this.value); });
$('[name=image]').on('change', function(){ if (this.files[0]) $('#slidePreview').css('background-image', 'url(' + URL.createObjectURL(this.files[0]) + ')'); });
</script>
<?php else: ?>
<div class="row"><a class="btn" href="?edit=new">+ Add slide</a></div>
<div class="card"><p class="muted">Drag ☰ to change the order.</p>
<ul class="sort-list" id="slideList">
<?php foreach ($slides as $s): ?>
  <li data-id="<?= $s['id'] ?>"><span class="handle">☰</span>
    <span class="thumb" style="background-color:<?= e($s['bg_color']) ?>;<?= $s['image'] ? "background-image:url('" . e(url($s['image'])) . "')" : '' ?>"></span>
    <span class="grow"><b><?= e($s['title'] ?: '(no title)') ?></b><br><small><?= e($s['subtitle']) ?></small></span>
    <span class="status s-<?= $s['is_active'] ? 'active' : 'cancelled' ?>"><?= $s['is_active'] ? 'visible' : 'hidden' ?></span>
    <a class="btn sm ghost-dark" href="?edit=<?= $s['id'] ?>">Edit</a>
    <form method="post" onsubmit="return confirm('Delete this slide?')"><?= csrf_field() ?><input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?= $s['id'] ?>"><button class="link">Delete</button></form></li>
<?php endforeach; ?>
</ul><?php if (!$slides): ?><p class="muted">No slides yet.</p><?php endif; ?></div>

<form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="act" value="settings"><h3>Slider settings</h3>
  <div class="grid3"><label>Height (px)<input type="number" name="slider_height" min="250" max="900" value="<?= e(setting('slider_height', '500')) ?>"></label>
  <label>Autoplay every (seconds, 0 = off)<input type="number" name="slider_autoplay" min="0" max="30" value="<?= e(setting('slider_autoplay', '5')) ?>"></label>
  <label>Transition<select name="slider_effect"><option value="fade">Fade</option><option value="slide" <?= setting('slider_effect') === 'slide' ? 'selected' : '' ?>>Slide</option></select></label></div>
  <button class="btn">Save settings</button></form>
<script>
$('#slideList').sortable({ handle: '.handle', update: function(){
  $.post('slider.php', { act: 'order', csrf: <?= json_encode(csrf_token()) ?>, ids: $(this).sortable('toArray', { attribute: 'data-id' }) });
}});
</script>
<?php endif; ?>
<?php admin_foot();
