<?php
require __DIR__ . '/_init.php';
$me = require_admin();
$roles = ['admin' => 'Admin', 'inventory' => 'Inventory manager', 'auditor' => 'Payment auditor', 'support' => 'Customer support'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'add') {
        if (plan_limit_reached('staff')) flash('Staff limit for your plan reached.', 'err');
        elseif (strlen($_POST['password']) < 8) flash('Password must be at least 8 characters.', 'err');
        else try {
            q("INSERT INTO admin_users (tenant_id, username, email, password_hash, role) VALUES (?,?,?,?,?)",
              [TID, trim($_POST['username']), trim($_POST['email']), password_hash($_POST['password'], PASSWORD_DEFAULT), isset($roles[$_POST['role']]) ? $_POST['role'] : 'support']);
            audit('staff_add'); flash('Staff member added.');
        } catch (PDOException $e) { flash('Username already taken.', 'err'); }
    }
    if ($act === 'del' && (int)$_POST['id'] !== $me['id']) { q("DELETE FROM admin_users WHERE id=? AND tenant_id=? AND role<>'owner'", [(int)$_POST['id'], TID]); audit('staff_remove'); flash('Removed.'); }
    if ($act === 'pass' && strlen($_POST['password']) >= 8) { q("UPDATE admin_users SET password_hash=? WHERE id=? AND tenant_id=?", [password_hash($_POST['password'], PASSWORD_DEFAULT), $me['id'], TID]); flash('Your password was changed.'); }
    redirect('admin/staff.php');
}
$list = rows("SELECT * FROM admin_users WHERE tenant_id=?", [TID]);
$logs = rows("SELECT l.*, a.username FROM audit_logs l LEFT JOIN admin_users a ON a.id=l.admin_id WHERE l.tenant_id=? ORDER BY l.id DESC LIMIT 25", [TID]);
admin_head('Staff & audit log'); ?>
<div class="grid2">
<div class="card"><table class="tbl"><tr><th>User</th><th>Role</th><th>Last login</th><th></th></tr>
<?php foreach ($list as $u): ?><tr><td><?= e($u['username']) ?><br><small><?= e($u['email']) ?></small></td><td><?= e($roles[$u['role']] ?? 'Owner') ?></td><td><small><?= e($u['last_login_at'] ?? '—') ?></small></td>
<td><?php if ($u['role'] !== 'owner' && $u['id'] != $me['id']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?= $u['id'] ?>"><button class="link">Remove</button></form><?php endif; ?></td></tr><?php endforeach; ?></table></div>
<div><form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="act" value="add"><h3>Add staff</h3>
  <div class="grid2"><label>Username<input name="username" required></label><label>Email<input type="email" name="email" required></label></div>
  <div class="grid2"><label>Password<input type="password" name="password" required minlength="8"></label>
  <label>Role<select name="role"><?php foreach ($roles as $k => $l): ?><option value="<?= $k ?>"><?= $l ?></option><?php endforeach; ?></select></label></div>
  <button class="btn">Add</button></form>
<form method="post" class="card row"><?= csrf_field() ?><input type="hidden" name="act" value="pass"><input type="password" name="password" placeholder="New password for you" minlength="8" required><button class="btn ghost-dark">Change my password</button></form></div>
</div>
<div class="card"><h3>Recent admin activity</h3><table class="tbl"><?php foreach ($logs as $l): ?><tr><td><small><?= e($l['created_at']) ?></small></td><td><?= e($l['username']) ?></td><td><?= e($l['action']) ?> <?= e($l['target_table']) ?> <?= e($l['target_id']) ?></td><td><small><?= e($l['ip_address']) ?></small></td></tr><?php endforeach; ?></table></div>
<?php admin_foot();
