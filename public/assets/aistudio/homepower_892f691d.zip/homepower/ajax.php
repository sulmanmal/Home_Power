<?php
// jQuery endpoints for the storefront: product listing (filter / load more) and quick view.
require 'inc/bootstrap.php';
$action = $_GET['action'] ?? '';

if ($action === 'products') {
    $limit = max(1, min(48, (int)($_GET['limit'] ?? 12)));
    $page = max(1, (int)($_GET['page'] ?? 1));
    $where = 'tenant_id=? AND is_active=1 AND is_upcoming=0'; $p = [TID];
    if ((int)($_GET['cat'] ?? 0)) { $where .= ' AND category_id=?'; $p[] = (int)$_GET['cat']; }
    $order = ['price_asc' => 'COALESCE(NULLIF(sale_price,0),price) ASC', 'price_desc' => 'COALESCE(NULLIF(sale_price,0),price) DESC', 'name' => 'name ASC'][$_GET['sort'] ?? ''] ?? 'id DESC';
    $total = row("SELECT COUNT(*) n FROM products WHERE $where", $p)['n'];
    $items = rows("SELECT * FROM products WHERE $where ORDER BY $order LIMIT $limit OFFSET " . (($page - 1) * $limit), $p);
    json_out(['html' => implode('', array_map('product_card', $items)), 'more' => $page * $limit < $total, 'total' => (int)$total]);
}

if ($action === 'quick') {
    $p = row("SELECT * FROM products WHERE tenant_id=? AND slug=? AND is_active=1", [TID, $_GET['slug'] ?? '']);
    if (!$p) json_out(['html' => '<p>Product not found.</p>']);
    $ep = eff_price($p);
    ob_start(); ?>
    <div class="qv">
      <div class="qv-img"><?= $p['image'] ? '<img src="' . e(url($p['image'])) . '" alt="' . e($p['name']) . '">' : '<div class="ph">☀</div>' ?></div>
      <div class="qv-body">
        <small class="pbrand"><?= e($p['brand']) ?></small>
        <h2><?= e($p['name']) ?></h2>
        <div class="price big"><?= money($ep) ?><?= $ep < $p['price'] ? ' <del>' . money($p['price']) . '</del>' : '' ?></div>
        <div class="chips"><?php foreach ([$p['capacity'], $p['voltage'], $p['warranty_months'] ? $p['warranty_months'] . ' months warranty' : ''] as $c) if ($c) echo '<span class="chip">' . e($c) . '</span>'; ?></div>
        <p class="muted"><?= e(mb_substr($p['description'], 0, 220)) ?></p>
        <div class="row">
          <?php if (!$p['is_upcoming'] && $p['stock'] > 0): ?><button class="btn accent js-add" data-id="<?= $p['id'] ?>">Add to cart</button><?php endif; ?>
          <a class="btn ghost-dark" href="<?= url('product.php?slug=' . urlencode($p['slug'])) ?>">Full details</a>
        </div>
      </div>
    </div>
    <?php json_out(['html' => ob_get_clean()]);
}
http_response_code(400);
json_out(['error' => 'Unknown action']);
