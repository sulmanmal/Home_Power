/* Storefront interactions (jQuery) */
$(function () {
  var $win = $(window), $hdr = $('#siteHeader');

  /* ---------- Header: sticky shadow, search, mobile menu, 3-level submenus ---------- */
  $win.on('scroll', function () { $hdr.toggleClass('scrolled', $win.scrollTop() > 10); });
  $('.js-search-toggle').on('click', function () { $('#searchBar').toggleClass('open').find('input').trigger('focus'); });
  $('.js-burger').on('click', function () { $('#mainNav').toggleClass('open'); $(this).text($('#mainNav').hasClass('open') ? '✕' : '☰'); });
  $('#mainNav').on('click', '.sub-toggle', function (e) {
    e.preventDefault();
    var $li = $(this).closest('li');
    $li.toggleClass('open').children('ul').stop(true).slideToggle(200);
    $(this).text($li.hasClass('open') ? '−' : '+');
  });
  // Keep desktop flyouts on screen
  $('#mainNav .lvl2 > li.has-sub').on('mouseenter', function () {
    var $sub = $(this).children('ul');
    $sub.toggleClass('flip', $sub.offset() && $sub.offset().left + $sub.outerWidth() > $win.width());
  });

  /* ---------- Toast ---------- */
  var toastT;
  window.toast = function (msg, ok) {
    $('#toast').text(msg).toggleClass('err', ok === false).addClass('show');
    clearTimeout(toastT); toastT = setTimeout(function () { $('#toast').removeClass('show'); }, 2600);
  };

  /* ---------- Hero slider ---------- */
  var $s = $('#heroSlider');
  if ($s.length) {
    var $slides = $s.find('.slide'), $dots = $s.find('.sl-dots button'), n = $slides.length, cur = 0,
        delay = (parseInt($s.data('autoplay'), 10) || 0) * 1000, timer = null;
    $s.addClass('fx-' + ($s.data('effect') === 'slide' ? 'slide' : 'fade'));
    var go = function (i) {
      if (n < 2) return;
      var prev = cur; cur = (i + n) % n;
      $slides.removeClass('active prev').eq(prev).addClass('prev');
      $slides.eq(cur).addClass('active');
      if ($s.hasClass('fx-slide')) $s.find('.slides').css('transform', 'translateX(' + (-100 * cur) + '%)');
      $dots.removeClass('on').eq(cur).addClass('on');
      restart();
    };
    var restart = function () {
      clearTimeout(timer);
      var $bar = $s.find('.sl-progress span').stop(true).css('width', 0);
      if (delay && n > 1) { $bar.animate({ width: '100%' }, delay, 'linear'); timer = setTimeout(function () { go(cur + 1); }, delay); }
    };
    $s.find('.next').on('click', function () { go(cur + 1); });
    $s.find('.prev').on('click', function () { go(cur - 1); });
    $dots.each(function (i) { $(this).on('click', function () { go(i); }); });
    $s.on('mouseenter', function () { clearTimeout(timer); $s.find('.sl-progress span').stop(true); }).on('mouseleave', restart);
    // touch swipe
    var x0 = null;
    $s.on('touchstart', function (e) { x0 = e.originalEvent.touches[0].clientX; })
      .on('touchend', function (e) { if (x0 === null) return; var dx = e.originalEvent.changedTouches[0].clientX - x0; if (Math.abs(dx) > 40) go(cur + (dx < 0 ? 1 : -1)); x0 = null; });
    $(document).on('keydown', function (e) { if (e.key === 'ArrowRight') go(cur + 1); if (e.key === 'ArrowLeft') go(cur - 1); });
    restart();
  }

  /* ---------- Product carousels ---------- */
  $('.prow').each(function () {
    var $row = $(this), $t = $row.find('.prow-track');
    var upd = function () {
      $row.find('.prev').toggleClass('off', $t.scrollLeft() < 5);
      $row.find('.next').toggleClass('off', $t.scrollLeft() + $t.innerWidth() >= $t[0].scrollWidth - 5);
    };
    $row.find('.prow-nav').on('click', function () {
      $t.stop().animate({ scrollLeft: $t.scrollLeft() + ($(this).hasClass('next') ? 1 : -1) * $t.innerWidth() * 0.85 }, 450, upd);
    });
    $t.on('scroll', upd); upd();
  });

  /* ---------- AJAX add to cart ---------- */
  $(document).on('click', '.js-add', function (e) {
    e.preventDefault();
    var $b = $(this).prop('disabled', true).addClass('loading');
    $.post(HPS.base + '/cart.php', { add: $b.data('id'), qty: 1, csrf: HPS.csrf }, null, 'json')
      .done(function (r) {
        toast(r.msg, r.ok);
        if (r.ok) {
          $('.cart-dot').text(r.count).show();
          $('.cart-btn').addClass('bump'); setTimeout(function () { $('.cart-btn').removeClass('bump'); }, 400);
          $b.addClass('done');
        }
      })
      .fail(function () { toast('Could not add to cart. Please refresh and try again.', false); })
      .always(function () { setTimeout(function () { $b.prop('disabled', false).removeClass('loading done'); }, 900); });
  });

  /* ---------- Quick view modal ---------- */
  var $m = $('#qvModal');
  $(document).on('click', '.js-quick', function (e) {
    e.preventDefault();
    $m.find('.modal-body').html('<div class="spinner"></div>'); $m.addClass('open'); $('body').addClass('noscroll');
    $.getJSON(HPS.base + '/ajax.php', { action: 'quick', slug: $(this).data('slug') }, function (r) { $m.find('.modal-body').html(r.html); });
  });
  var closeModal = function () { $m.removeClass('open'); $('body').removeClass('noscroll'); };
  $m.on('click', function (e) { if (e.target === this) closeModal(); });
  $m.find('.modal-x').on('click', closeModal);
  $(document).on('keydown', function (e) { if (e.key === 'Escape') closeModal(); });

  /* ---------- Countdowns for upcoming products ---------- */
  var tick = function () {
    $('.countdown[data-date]').each(function () {
      var ms = new Date($(this).data('date') + 'T00:00:00') - new Date();
      if (ms <= 0) { $(this).html('<b>Available now</b>'); return; }
      var d = Math.floor(ms / 864e5), h = Math.floor(ms / 36e5) % 24, mi = Math.floor(ms / 6e4) % 60, s = Math.floor(ms / 1e3) % 60;
      $(this).html($(this).hasClass('big')
        ? '<span><b>' + d + '</b>days</span><span><b>' + h + '</b>hrs</span><span><b>' + mi + '</b>min</span><span><b>' + s + '</b>sec</span>'
        : '⏱ ' + d + 'd ' + h + 'h ' + mi + 'm');
    });
  };
  if ($('.countdown').length) { tick(); setInterval(tick, 1000); }

  /* ---------- Homepage product listing: filter tabs, sort, load more ---------- */
  var $all = $('#allProducts');
  if ($all.length) {
    var st = { cat: 0, sort: '', page: 1, limit: $all.data('limit') || 12 }, $grid = $all.find('.listing-grid');
    var load = function (append) {
      $all.find('.js-more').prop('disabled', true).text('Loading…');
      if (!append) $grid.addClass('fading');
      $.getJSON(HPS.base + '/ajax.php', $.extend({ action: 'products' }, st), function (r) {
        var $items = $(r.html).hide();
        if (append) $grid.append($items); else $grid.empty().append($items);
        $items.fadeIn(350); $grid.removeClass('fading');
        $all.find('.js-more').prop('disabled', false).text('Load more').toggle(!!r.more);
        $all.find('.listing-count').text('Showing ' + $grid.children().length + ' of ' + r.total + ' products');
        if (!r.total) $grid.html('<p class="muted">No products in this category yet.</p>');
      });
    };
    $all.on('click', '.filter-tabs button', function () {
      $(this).addClass('on').siblings().removeClass('on');
      st.cat = $(this).data('cat'); st.page = 1; load(false);
    });
    $all.find('.js-sort').on('change', function () { st.sort = $(this).val(); st.page = 1; load(false); });
    $all.find('.js-more').on('click', function () { st.page++; load(true); });
    load(false);
  }

  /* ---------- Reveal on scroll ---------- */
  var reveal = function () {
    var bottom = $win.scrollTop() + $win.height() * 0.92;
    $('.reveal:not(.in)').each(function () { if ($(this).offset().top < bottom) $(this).addClass('in'); });
  };
  $win.on('scroll resize', reveal); reveal();

  /* ---------- Back to top ---------- */
  var $top = $('<button class="to-top" aria-label="Back to top">↑</button>').appendTo('body').on('click', function () { $('html,body').animate({ scrollTop: 0 }, 500); });
  $win.on('scroll', function () { $top.toggleClass('show', $win.scrollTop() > 600); });
});
