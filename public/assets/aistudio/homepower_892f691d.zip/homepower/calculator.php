<?php
require 'inc/bootstrap.php';
if (!feature('calculator')) redirect('index.php');

// Parse capacities into numbers so JS can pick a bundle
$prods = rows("SELECT p.id, p.name, p.price, p.sale_price, p.capacity, p.voltage, p.stock, c.slug cat FROM products p JOIN categories c ON c.id=p.category_id
               WHERE p.tenant_id=? AND p.is_active=1 AND p.stock>0", [TID]);
$cat = ['inverters' => [], 'batteries' => [], 'panels' => []];
foreach ($prods as $p) { $p["price"] = eff_price($p);
    $n = (float)preg_replace('/[^\d.]/', '', $p['capacity'] ?? '');
    if (!$n) continue;
    if (str_contains($p['cat'], 'invert')) $cat['inverters'][] = $p + ['kw' => $n];
    elseif (str_contains($p['cat'], 'batter')) $cat['batteries'][] = $p + ['ah' => $n, 'v' => (int)$p['voltage'] ?: 12];
    elseif (str_contains($p['cat'], 'panel')) $cat['panels'][] = $p + ['w' => $n];
}
$pageTitle = 'Solar Calculator';
include 'inc/header.php';
?>
<h1>Solar system sizing calculator</h1>
<p class="muted">Add the appliances you want to run. We'll recommend inverter, battery and panel sizes and estimate your savings.</p>
<div class="calc">
  <div class="card">
    <table class="tbl" id="apps"><tr><th>Appliance</th><th>Watts</th><th>Qty</th><th>Hours/day</th><th>Backup at night?</th></tr></table>
    <div class="row"><select id="preset">
      <option value="Ceiling fan|80">Ceiling fan (80W)</option><option value="LED light|15">LED light (15W)</option>
      <option value="Inverter AC 1.5 ton|1400">Inverter AC 1.5 ton (1400W)</option><option value="Refrigerator|200">Refrigerator (200W)</option>
      <option value="Water pump 1hp|750">Water pump 1hp (750W)</option><option value="TV|100">TV (100W)</option>
      <option value="Laptop / Wi-Fi|80">Laptop / Wi-Fi (80W)</option><option value="Washing machine|500">Washing machine (500W)</option>
      <option value="Iron|1000">Iron (1000W)</option><option value="Custom|100">Custom…</option></select>
      <button class="btn sm" onclick="addRow()">+ Add</button></div>
    <div class="grid3">
      <label>City<select id="city">
        <option value="5.5">Lahore</option><option value="5.8">Karachi</option><option value="5.6">Islamabad</option>
        <option value="6.0">Multan</option><option value="6.2">Quetta</option><option value="5.4">Peshawar</option><option value="5.7">Faisalabad</option></select></label>
      <label>System type<select id="mode"><option value="hybrid">Hybrid</option><option value="offgrid">Off-grid</option><option value="ongrid">On-grid (no battery)</option></select></label>
      <label>Battery<select id="chem"><option value="0.9">Lithium (90% DoD)</option><option value="0.5">Tubular / lead-acid (50% DoD)</option></select></label>
      <label>Electricity rate (Rs/unit)<input id="tariff" type="number" value="<?= e(setting('tariff_per_unit', '60')) ?>"></label>
      <label>Battery voltage<select id="bv"><option>48</option><option>24</option><option>12</option></select></label>
    </div>
  </div>
  <div class="card result" id="res"></div>
</div>
<form method="post" action="<?= url('cart.php') ?>" id="bundleForm"><?= csrf_field() ?><input type="hidden" name="bundle" id="bundle"></form>
<script>
const CAT=<?= json_encode($cat) ?>;
const fmt=n=>'Rs '+Math.round(n).toLocaleString('en-PK');
function addRow(name,w,qty=1,h=8,night=true){
  if(!name){const [n,ww]=preset.value.split('|');name=n;w=ww;}
  const tr=apps.insertRow();
  tr.innerHTML=`<td><input value="${name}"></td><td><input type=number value="${w}" class=w></td><td><input type=number value="${qty}" class=q style="width:60px"></td>
  <td><input type=number value="${h}" class=h style="width:60px"></td><td><input type=checkbox class=n ${night?'checked':''}> <a href=# onclick="this.closest('tr').remove();calc();return false">✕</a></td>`;
  calc();
}
function calc(){
  let load=0,energy=0,night=0;
  apps.querySelectorAll('tr').forEach((r,i)=>{if(!i)return;const w=+r.querySelector('.w').value,q=+r.querySelector('.q').value,h=+r.querySelector('.h').value;
    load+=w*q;energy+=w*q*h;if(r.querySelector('.n').checked)night+=w*q*Math.min(h,8);});
  const sun=+city.value,dod=+chem.value,bv=+bv_el().value,m=mode.value,tariff=+tariff_el().value;
  const invKw=Math.ceil(load*1.25/100)/10;                         // 25% headroom
  const pvW=Math.ceil(energy/(sun*0.8)/100)*100;                   // 80% system losses
  const battWh=m==='ongrid'?0:night/dod/0.95;                      // inverter efficiency
  const battAh=Math.ceil(battWh/bv);
  const monthly=energy/1000*30, saving=monthly*tariff*(m==='offgrid'?1:0.9);
  // choose bundle
  const inv=[...CAT.inverters].sort((a,b)=>a.kw-b.kw).find(x=>x.kw>=invKw)||CAT.inverters.sort((a,b)=>b.kw-a.kw)[0];
  const pan=CAT.panels.sort((a,b)=>b.w-a.w)[0];
  const bat=CAT.batteries.filter(b=>bv%b.v===0).sort((a,b)=>b.ah*b.v-a.ah*a.v)[0];
  const bundle={};let cost=0,lines='';
  if(inv&&load){bundle[inv.id]=1;cost+=+inv.price;lines+=`<li>1 × ${inv.name}</li>`;}
  if(pan&&pvW){const n=Math.ceil(pvW/pan.w);bundle[pan.id]=n;cost+=n*pan.price;lines+=`<li>${n} × ${pan.name}</li>`;}
  if(bat&&battAh){const n=Math.max(bv/bat.v,Math.ceil(battWh/(bat.ah*bat.v)));bundle[bat.id]=n;cost+=n*bat.price;lines+=`<li>${n} × ${bat.name}</li>`;}
  const payback=saving?cost/(saving*12):0;
  document.getElementById('bundle').value=JSON.stringify(bundle);
  let bars='';for(let y=1;y<=10;y++){const v=saving*12*y-cost;bars+=`<div class=bar title="Year ${y}: ${fmt(v)}" style="height:${Math.min(100,Math.abs(v)/(cost||1)*50)}%;background:${v<0?'#ef4444':'var(--brand)'}"></div>`;}
  res.innerHTML=`<h3>Recommendation</h3>
   <div class=kpis><div><small>Peak load</small><b>${load.toLocaleString()} W</b></div><div><small>Daily energy</small><b>${(energy/1000).toFixed(1)} kWh</b></div>
   <div><small>Inverter</small><b>${invKw} kW</b></div><div><small>Solar panels</small><b>${(pvW/1000).toFixed(1)} kW</b></div>
   <div><small>Battery bank</small><b>${battAh?battAh+' Ah @ '+bv+'V':'Not needed'}</b></div><div><small>Monthly saving</small><b>${fmt(saving)}</b></div></div>
   ${lines?`<p><b>Suggested bundle (${fmt(cost)})</b></p><ul>${lines}</ul><p>Estimated payback: <b>${payback.toFixed(1)} years</b></p>
   <div class=roi>${bars}</div><small class=muted>10-year cumulative return (red = not yet paid back)</small>
   <button class="btn accent block" onclick="bundleForm.submit()">Add recommended bundle to cart</button>`:'<p class=muted>Add appliances to see a bundle.</p>'}
   <button class="btn ghost-dark block" onclick="print()">Save calculation as PDF</button>`;
}
const bv_el=()=>document.getElementById('bv'),tariff_el=()=>document.getElementById('tariff');
document.querySelectorAll('select,input').forEach(el=>el.addEventListener('input',calc));
apps.addEventListener('input',calc);
addRow('Ceiling fan',80,4,12);addRow('LED light',15,8,8);addRow('Refrigerator',200,1,24);addRow('Inverter AC 1.5 ton',1400,1,6,false);
</script>
<?php include 'inc/footer.php';
