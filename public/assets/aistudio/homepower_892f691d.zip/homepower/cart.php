<?php
require 'inc/bootstrap.php';
$cart = &cart();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['add'])) {
        $id = (int)$_POST['add'];
        $p = row("SELECT id, name, stock FROM products WHERE id=? AND tenant_id=? AND is_active=1 AND is_upcoming=0", [$id, TID]);
        if ($p && $p['stock'] > 0) {
            $cart[$id] = min($p['stock'], ($cart[$id] ?? 0) + max(1, (int)($_POST['qty'] ?? 1)));
            if (is_ajax()) json_out(['ok' => true, 'count' => cart_count(), 'msg' => $p['name'] . ' added to cart']);
            flash('Added to cart.');
        } elseif (is_ajax()) json_out(['ok' => false, 'msg' => 'This product is not available right now.']);
    }
    if (!empty($_POST['bundle'])) {   // from solar calculator
        foreach ((array)json_decode($_POST['bundle'], true) as $id => $q)
            if ((int)$q > 0 && row("SELECT id FROM products WHERE id=? AND tenant_id=? AND is_active=1", [(int)$id, TID]))
                $cart[(int)$id] = ($cart[(int)$id] ?? 0) + (int)$q;
        flash('Recommended bundle added to cart.');
    }
    if (isset($_POST['update'])) {
        foreach ($_POST['qty'] ?? [] as $id => $q) { $q = (int)$q; if ($q > 0) $cart[(int)$id] = $q; else unset($cart[(int)$id]); }
    }
    if (isset($_POST['coupon'])) {
        $code = strtoupper(trim($_POST['coupon']));
        $cp = feature('coupons') ? row("SELECT * FROM coupons WHERE tenant_id=? AND code=? AND is_active=1 AND (expires_at IS NULL OR expires_at>NOW()) AND (max_uses=0 OR used_count<max_uses)", [TID, $code]) : null;
        if ($cp) { $_SESSION['coupon'][TID] = $code; flash('Coupon applied.'); } else { unset($_SESSION['coupon'][TID]); flash('Invalid or expired coupon.', 'err'); }
    }
    redirect('cart.php');
}

$totals = cart_totals($_GET['zone'] ?? null);
$pageTitle = 'Your cart';
include 'inc/header.php';
?>
<h1>Your cart</h1>
<?php if (!$totals['items']): ?>
  <div class="card"><p>Your cart is empty.</p><a class="btn" href="<?= url('shop.php') ?>">Continue shopping</a></div>
<?php else: ?>
<form method="post" class="card"><?= csrf_field() ?>
<table class="tbl">
  <tr><th>Product</th><th>Price</th><th>Qty</th><th>Total</th></tr>
  <?php foreach ($totals['items'] as $it): ?>
  <tr><td><a href="<?= url('product.php?slug=' . urlencode($it['slug'])) ?>"><?= e($it['name']) ?></a><?= $it['qty'] > $it['stock'] ? '<br><span class="out">Only ' . (int)$it['stock'] . ' available</span>' : '' ?></td>
      <td><?= money($it['price']) ?></td>
      <td><input type="number" name="qty[<?= $it['id'] ?>]" value="<?= $it['qty'] ?>" min="0" style="width:70px"></td>
      <td><?= money($it['line']) ?></td></tr>
  <?php endforeach; ?>
</table>
<button class="btn ghost-dark" name="update" value="1">Update cart</button> <small class="muted">Set quantity to 0 to remove.</small>
</form>

<div class="grid2">
  <?php if (feature('coupons')): ?>
  <form method="post" class="card"><?= csrf_field() ?><b>Coupon code</b>
    <div class="row"><input name="coupon" value="<?= e($_SESSION['coupon'][TID] ?? '') ?>" placeholder="e.g. SOLAR5"><button class="btn">Apply</button></div>
  </form>
  <?php endif; ?>
  <div class="card summary">
    <div><span>Subtotal</span><b><?= money($totals['subtotal']) ?></b></div>
    <?php if ($totals['discount']): ?><div><span>Discount (<?= e($totals['coupon']) ?>)</span><b>− <?= money($totals['discount']) ?></b></div><?php endif; ?>
    <div class="muted"><span>Shipping</span><span>calculated at checkout</span></div>
    <a class="btn accent block" href="<?= url('checkout.php') ?>">Proceed to checkout</a>
  </div>
</div>
<?php endif; ?>
<?php include 'inc/footer.php';
