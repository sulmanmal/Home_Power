<?php
require 'inc/bootstrap.php';
$zones = rows("SELECT * FROM shipping_rates WHERE tenant_id=? ORDER BY base_cost", [TID]);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = array_map('trim', $_POST);
    $t = cart_totals($f['zone'] ?? null);
    $gateway = $f['gateway'] ?? '';
    if (!$t['items']) $errors[] = 'Your cart is empty.';
    foreach (['name' => 'Name', 'phone' => 'Phone', 'city' => 'City', 'address' => 'Address'] as $k => $l) if (empty($f[$k])) $errors[] = "$l is required.";
    if (!preg_match('/^(\+92|0)3\d{2}-?\d{7}$/', $f['phone'] ?? '')) $errors[] = 'Enter a valid Pakistani mobile number (03XX-XXXXXXX).';
    if (!row("SELECT id FROM shipping_rates WHERE id=? AND tenant_id=?", [$f['zone'] ?? 0, TID])) $errors[] = 'Select a delivery zone.';
    if (!in_array($gateway, ['jazzcash', 'easypaisa', 'bank_transfer', 'raast', 'cod'], true)) $errors[] = 'Select a payment method.';
    foreach ($t['items'] as $it) if ($it['qty'] > $it['stock']) $errors[] = "Only {$it['stock']} of {$it['name']} in stock.";

    $receipt = null;
    if (!$errors && $gateway !== 'cod' && !empty($_FILES['receipt']['name'])) {
        $receipt = save_upload('receipt');
        if (!$receipt) $errors[] = 'Receipt must be a JPG, PNG, WEBP or PDF under 5 MB.';
        elseif (row("SELECT id FROM payments WHERE tenant_id=? AND receipt_hash=?", [TID, $receipt['hash']]))
            $errors[] = 'This receipt has already been used for another order.';   // duplicate-receipt detection
    }

    if (!$errors) {
        $pdo = db(); $pdo->beginTransaction();
        try {
            $orderNo = 'HP' . date('ymd') . strtoupper(bin2hex(random_bytes(2)));
            $track = strtoupper(bin2hex(random_bytes(4)));
            $status = $receipt ? 'receipt_uploaded' : 'pending';
            q("INSERT INTO orders (tenant_id, order_number, tracking_code, customer_name, phone, email, city, address, subtotal, discount, shipping, total, coupon_code, status)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
              [TID, $orderNo, $track, $f['name'], $f['phone'], $f['email'] ?? null, $f['city'], $f['address'], $t['subtotal'], $t['discount'], $t['shipping'], $t['total'], $t['coupon'], $status]);
            $oid = $pdo->lastInsertId();
            foreach ($t['items'] as $it) {
                q("INSERT INTO order_items (tenant_id, order_id, product_id, product_name, unit_price, quantity) VALUES (?,?,?,?,?,?)",
                  [TID, $oid, $it['id'], $it['name'], $it['price'], $it['qty']]);
                $u = q("UPDATE products SET stock=stock-? WHERE id=? AND tenant_id=? AND stock>=?", [$it['qty'], $it['id'], TID, $it['qty']]);
                if (!$u->rowCount()) throw new Exception("{$it['name']} just went out of stock.");
                q("INSERT INTO stock_movements (tenant_id, product_id, movement_type, quantity, reference_type, reference_id) VALUES (?,?,'out',?,'order',?)",
                  [TID, $it['id'], $it['qty'], $oid]);
            }
            q("INSERT INTO payments (tenant_id, order_id, gateway, amount, status, reference_number, receipt_path, receipt_hash) VALUES (?,?,?,?,?,?,?,?)",
              [TID, $oid, $gateway, $t['total'], $receipt ? 'receipt_uploaded' : 'pending', $f['reference'] ?? null, $receipt['path'] ?? null, $receipt['hash'] ?? null]);
            if ($t['coupon']) q("UPDATE coupons SET used_count=used_count+1 WHERE tenant_id=? AND code=?", [TID, $t['coupon']]);
            $pdo->commit();
            $_SESSION['cart'][TID] = []; unset($_SESSION['coupon'][TID]);
            redirect('track.php?code=' . $track . '&new=1');
        } catch (Exception $ex) { $pdo->rollBack(); $errors[] = $ex->getMessage(); }
    }
}

$t = cart_totals($_POST['zone'] ?? ($zones[0]['id'] ?? null));
if (!$t['items'] && !$errors) redirect('cart.php');
$pageTitle = 'Checkout';
include 'inc/header.php';
?>
<h1>Checkout</h1>
<?php foreach ($errors as $er) echo '<div class="alert alert-err">' . e($er) . '</div>'; ?>
<form method="post" enctype="multipart/form-data" class="checkout"><?= csrf_field() ?>
  <div class="card">
    <h3>Delivery details</h3>
    <label>Full name<input name="name" required value="<?= e($_POST['name'] ?? '') ?>"></label>
    <div class="grid2"><label>Mobile<input name="phone" required placeholder="03XX-XXXXXXX" value="<?= e($_POST['phone'] ?? '') ?>"></label>
    <label>Email (optional)<input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>"></label></div>
    <div class="grid2"><label>City<input name="city" required value="<?= e($_POST['city'] ?? '') ?>"></label>
    <label>Delivery zone<select name="zone" id="zone" required>
      <?php foreach ($zones as $z): ?><option value="<?= $z['id'] ?>" data-base="<?= $z['base_cost'] ?>" data-kg="<?= $z['per_kg'] ?>" <?= ($_POST['zone'] ?? '') == $z['id'] ? 'selected' : '' ?>><?= e($z['zone_name']) ?></option><?php endforeach; ?>
    </select></label></div>
    <label>Full address<textarea name="address" required rows="2"><?= e($_POST['address'] ?? '') ?></textarea></label>

    <h3>Payment</h3>
    <div class="paygrid">
      <?php foreach (['jazzcash' => 'JazzCash', 'easypaisa' => 'Easypaisa', 'bank_transfer' => 'Bank Transfer', 'raast' => 'Raast', 'cod' => 'Cash on Delivery'] as $k => $l): ?>
        <label class="pay"><input type="radio" name="gateway" value="<?= $k ?>" <?= ($_POST['gateway'] ?? 'bank_transfer') === $k ? 'checked' : '' ?>> <?= $l ?></label>
      <?php endforeach; ?>
    </div>
    <div class="card soft" id="payinfo">
      <p><b>Send the total to:</b><br>
        JazzCash: <?= e(setting('jazzcash')) ?><br>Easypaisa: <?= e(setting('easypaisa')) ?><br><?= e(setting('bank_details')) ?></p>
      <label>Transaction / reference number<input name="reference" value="<?= e($_POST['reference'] ?? '') ?>"></label>
      <label>Upload payment receipt (image or PDF)<input type="file" name="receipt" accept="image/*,application/pdf"></label>
      <small class="muted">You can also upload it later from the Track Order page. Orders are dispatched once payment is verified.</small>
    </div>
  </div>
  <div class="card summary">
    <h3>Order summary</h3>
    <?php foreach ($t['items'] as $it): ?><div><span><?= e($it['name']) ?> × <?= $it['qty'] ?></span><b><?= money($it['line']) ?></b></div><?php endforeach; ?>
    <hr><div><span>Subtotal</span><b><?= money($t['subtotal']) ?></b></div>
    <?php if ($t['discount']): ?><div><span>Discount</span><b>− <?= money($t['discount']) ?></b></div><?php endif; ?>
    <div><span>Shipping (<?= round($t['weight']) ?> kg)</span><b id="ship"><?= money($t['shipping']) ?></b></div>
    <div class="total"><span>Total</span><b id="tot"><?= money($t['total']) ?></b></div>
    <button class="btn accent block">Place order</button>
  </div>
</form>
<script>
const z=document.getElementById('zone'),w=<?= (float)$t['weight'] ?>,base=<?= $t['subtotal'] - $t['discount'] ?>;
const f=n=>'Rs '+Math.round(n).toLocaleString('en-PK');
z.onchange=()=>{const o=z.selectedOptions[0],s=+o.dataset.base+o.dataset.kg*w;ship.textContent=f(s);tot.textContent=f(base+s)};z.onchange();
document.querySelectorAll('[name=gateway]').forEach(r=>r.onchange=()=>payinfo.style.display=r.value==='cod'&&r.checked?'none':'block');
</script>
<?php include 'inc/footer.php';
