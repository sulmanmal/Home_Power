<?php
require 'inc/bootstrap.php';
$all = rows("SELECT id, name FROM products WHERE tenant_id=? AND is_active=1 ORDER BY name", [TID]);
$ids = array_slice(array_filter(array_map('intval', (array)($_GET['p'] ?? []))), 0, 4);
$sel = [];
foreach ($ids as $id) if ($r = row("SELECT * FROM products WHERE id=? AND tenant_id=?", [$id, TID])) $sel[] = $r;
$pageTitle = 'Compare products';
include 'inc/header.php';
?>
<h1>Compare products</h1>
<form class="card row">
  <?php for ($i = 0; $i < 4; $i++): ?><select name="p[]"><option value="">— choose —</option>
    <?php foreach ($all as $a): ?><option value="<?= $a['id'] ?>" <?= ($ids[$i] ?? 0) == $a['id'] ? 'selected' : '' ?>><?= e($a['name']) ?></option><?php endforeach; ?></select>
  <?php endfor; ?><button class="btn">Compare</button>
</form>
<?php if ($sel): ?>
<div class="card" style="overflow-x:auto"><table class="tbl">
  <?php foreach (['name' => 'Product', 'brand' => 'Brand', 'price' => 'Price', 'capacity' => 'Capacity', 'voltage' => 'Voltage', 'warranty_months' => 'Warranty (months)', 'weight_kg' => 'Weight (kg)', 'stock' => 'Stock'] as $k => $l): ?>
  <tr><th><?= $l ?></th><?php foreach ($sel as $p): ?><td><?= $k === 'price' ? money($p[$k]) : e($p[$k]) ?></td><?php endforeach; ?></tr>
  <?php endforeach; ?>
</table><p class="muted">Share this comparison: copy the page link.</p></div>
<?php endif; ?>
<?php include 'inc/footer.php';
