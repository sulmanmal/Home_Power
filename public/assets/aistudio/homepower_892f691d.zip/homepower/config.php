<?php
// ===== Edit these for your server =====
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'homepower');
define('DB_USER', 'root');
define('DB_PASS', '');

// Your platform's base domain; each tenant gets <slug>.PLATFORM_DOMAIN automatically
define('PLATFORM_DOMAIN', 'yourplatform.com');

// Tenant used when the host can't be resolved (local XAMPP testing).
// Set to 0 in production so unknown domains fail closed.
define('DEFAULT_TENANT_ID', 1);

// URL path where the app lives, e.g. '' at domain root or '/homepower' in htdocs/homepower
define('APP_PATH', '/homepower');
