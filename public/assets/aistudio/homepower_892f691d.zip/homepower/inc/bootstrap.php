<?php
/**
 * Bootstrap: DB connection, security headers, session, tenant resolution, helpers.
 * Every tenant-scoped query MUST filter by TID (the resolved tenant id).
 */
require_once __DIR__ . '/../config.php';

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database connection failed. Check config.php');
}

function db() { global $pdo; return $pdo; }
function q($sql, $params = []) { $s = db()->prepare($sql); $s->execute($params); return $s; }
function row($sql, $p = []) { return q($sql, $p)->fetch(); }
function rows($sql, $p = []) { return q($sql, $p)->fetchAll(); }
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function url($path = '') { return APP_PATH . '/' . ltrim($path, '/'); }
function money($n) { return 'Rs ' . number_format((float)$n, 0); }
function redirect($path) { header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path))); exit; }
function flash($msg = null, $type = 'ok') {
    if ($msg !== null) { $_SESSION['flash'] = [$msg, $type]; return; }
    if (!empty($_SESSION['flash'])) { [$m, $t] = $_SESSION['flash']; unset($_SESSION['flash']);
        return "<div class='alert alert-$t'>" . e($m) . "</div>"; }
    return '';
}

// ---------- CSRF ----------
function csrf_token() { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_field() { return '<input type="hidden" name="csrf" value="' . csrf_token() . '">'; }
function csrf_check() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('Session expired. Go back and try again.');
    }
}
csrf_check();

// ---------- Tenant resolution (custom domain → subdomain → ?tenant= dev switch → default) ----------
function resolve_tenant() {
    $host = strtolower(preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? 'localhost'));
    $host = preg_replace('/^www\./', '', $host);

    // Dev/staging switch: ?tenant=slug (remembered in session)
    if (!empty($_GET['tenant'])) {
        $t = row("SELECT * FROM tenants WHERE slug=?", [$_GET['tenant']]);
        if ($t) $_SESSION['dev_tenant'] = $t['id'];
    }
    // 1. custom domain
    $t = row("SELECT t.* FROM tenant_domains d JOIN tenants t ON t.id=d.tenant_id WHERE d.domain IN (?,?)", [$host, 'www.' . $host]);
    // 2. subdomain of platform
    if (!$t && str_ends_with($host, '.' . PLATFORM_DOMAIN)) {
        $slug = substr($host, 0, -strlen('.' . PLATFORM_DOMAIN));
        $t = row("SELECT * FROM tenants WHERE slug=?", [$slug]);
    }
    // 3. dev session switch (overrides the localhost mapping)
    if (!empty($_SESSION['dev_tenant']) && (!$t || $host === 'localhost' || $host === '127.0.0.1')) {
        $t = row("SELECT * FROM tenants WHERE id=?", [$_SESSION['dev_tenant']]) ?: $t;
    }
    // 4. default
    if (!$t && DEFAULT_TENANT_ID) $t = row("SELECT * FROM tenants WHERE id=?", [DEFAULT_TENANT_ID]);
    return $t;
}

if (!defined('PLATFORM_AREA')) {
    $TENANT = resolve_tenant();
    if (!$TENANT) { http_response_code(404); exit('Store not found.'); }   // fail closed
    define('TID', (int)$TENANT['id']);
    $PLAN = row("SELECT * FROM plans WHERE id=?", [$TENANT['plan_id']]);
    $SETTINGS = [];
    foreach (rows("SELECT setting_key, setting_value FROM tenant_settings WHERE tenant_id=?", [TID]) as $r)
        $SETTINGS[$r['setting_key']] = $r['setting_value'];

    // SEO 301/302 redirects managed in Admin → SEO
    if (!defined('ADMIN_AREA')) {
        $rd = row("SELECT target_url, redirect_code FROM seo_redirects WHERE tenant_id=? AND source_url IN (?,?)",
                  [TID, $_SERVER['REQUEST_URI'] ?? '', substr($_SERVER['REQUEST_URI'] ?? '', strlen(APP_PATH))]);
        if ($rd) { header('Location: ' . $rd['target_url'], true, in_array((int)$rd['redirect_code'], [301, 302]) ? (int)$rd['redirect_code'] : 301); exit; }
    }
    if ($TENANT['status'] === 'suspended' && !defined('ADMIN_AREA')) {
        http_response_code(503);
        exit('<h2 style="font-family:sans-serif;text-align:center;margin-top:20vh">' . e($TENANT['company_name']) .
            ' is temporarily unavailable.</h2>');
    }
}

/** Price a customer pays: sale price when set and lower than the regular price */
function eff_price($p) { return (!empty($p['sale_price']) && $p['sale_price'] > 0 && $p['sale_price'] < $p['price']) ? (float)$p['sale_price'] : (float)$p['price']; }
function is_ajax() { return strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest'; }
function json_out($data) { header('Content-Type: application/json'); echo json_encode($data); exit; }

/** Menu tree (max 3 levels) from menu_items */
function menu_tree() {
    $all = rows("SELECT * FROM menu_items WHERE tenant_id=? AND is_active=1 ORDER BY sort_order, id", [TID]);
    $by = []; foreach ($all as $m) $by[(int)$m['parent_id']][] = $m;
    $build = function ($pid, $depth) use (&$build, $by) {
        $out = [];
        foreach ($by[$pid] ?? [] as $m) { $m['children'] = $depth < 3 ? $build((int)$m['id'], $depth + 1) : []; $out[] = $m; }
        return $out;
    };
    return $build(0, 1);
}
function menu_href($u) { return preg_match('#^(https?:|mailto:|tel:|\#)#', $u) ? $u : url($u); }

/** SEO for current page: explicit $pageTitle/$metaDesc win, then per-page seo_meta, then global defaults */
function seo_get($key) { return row("SELECT * FROM seo_meta WHERE tenant_id=? AND page_key=?", [TID, $key]) ?: []; }

function setting($k, $default = '') { global $SETTINGS; return $SETTINGS[$k] ?? $default; }
function save_setting($k, $v) {
    q("INSERT INTO tenant_settings (tenant_id, setting_key, setting_value) VALUES (?,?,?)
       ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)", [TID, $k, $v]);
}

/** Feature gating: plan features + per-tenant overrides */
function feature($key) {
    global $PLAN;
    $o = row("SELECT enabled FROM tenant_feature_overrides WHERE tenant_id=? AND feature_key=?", [TID, $key]);
    if ($o) return (bool)$o['enabled'];
    $f = json_decode($PLAN['features_json'] ?? '{}', true);
    return !empty($f[$key]);
}

// ---------- Cart (session, keyed per tenant) ----------
function &cart() { $_SESSION['cart'][TID] ??= []; return $_SESSION['cart'][TID]; }
function cart_count() { return array_sum(cart()); }

/** Recalculate cart from DB prices (never trust client prices). $zoneId = shipping_rates.id */
function cart_totals($zoneId = null) {
    $items = []; $subtotal = 0; $weight = 0;
    foreach (cart() as $id => $qty) {
        $p = row("SELECT id, name, slug, price, sale_price, stock, weight_kg FROM products WHERE id=? AND tenant_id=? AND is_active=1 AND is_upcoming=0", [$id, TID]);
        if (!$p) continue;
        $p['price'] = eff_price($p);
        $p['qty'] = $qty; $p['line'] = $p['price'] * $qty;
        $subtotal += $p['line']; $weight += $p['weight_kg'] * $qty; $items[] = $p;
    }
    $discount = 0; $code = $_SESSION['coupon'][TID] ?? null;
    if ($code && feature('coupons')) {
        $cp = row("SELECT * FROM coupons WHERE tenant_id=? AND code=? AND is_active=1 AND (expires_at IS NULL OR expires_at>NOW()) AND (max_uses=0 OR used_count<max_uses)", [TID, $code]);
        if ($cp && $subtotal >= $cp['min_order_amount'])
            $discount = $cp['discount_type'] === 'percentage' ? round($subtotal * $cp['discount_value'] / 100) : min($subtotal, $cp['discount_value']);
        else $code = null;
    } else $code = null;
    $shipping = 0;
    if ($zoneId && ($z = row("SELECT * FROM shipping_rates WHERE id=? AND tenant_id=?", [$zoneId, TID])))
        $shipping = $z['base_cost'] + $z['per_kg'] * $weight;
    return ['items' => $items, 'subtotal' => $subtotal, 'discount' => $discount, 'coupon' => $code,
            'shipping' => round($shipping), 'weight' => $weight, 'total' => $subtotal - $discount + round($shipping)];
}

function product_card($p) {
    $img = $p['image'] ? url($p['image']) : '';
    $link = url('product.php?slug=' . urlencode($p['slug']));
    $price = eff_price($p); $onSale = $price < $p['price'];
    $up = !empty($p['is_upcoming']);
    $chips = '';
    foreach ([$p['capacity'], $p['voltage'], $p['warranty_months'] >= 12 ? round($p['warranty_months'] / 12, 1) . '-yr warranty' : ''] as $c)
        if ($c) $chips .= '<span class="chip">' . e($c) . '</span>';
    if ($up) $badge = '<span class="pbadge soon">Coming soon</span>';
    elseif ($onSale) $badge = '<span class="pbadge sale">-' . round(100 - $price / $p['price'] * 100) . '%</span>';
    elseif (!empty($p['is_new'])) $badge = '<span class="pbadge new">New</span>';
    elseif ($p['is_featured']) $badge = '<span class="pbadge">Best seller</span>';
    elseif ($p['stock'] > 0 && $p['stock'] <= $p['min_threshold']) $badge = '<span class="pbadge warn">Few left</span>';
    else $badge = '';
    $stock = $up ? ($p['launch_date'] ? '<span class="countdown" data-date="' . e($p['launch_date']) . '">Launching ' . date('d M', strtotime($p['launch_date'])) . '</span>' : '<span class="muted">Launching soon</span>')
               : ($p['stock'] > 0 ? '<span class="in">In stock</span>' : '<span class="out">Out of stock</span>');
    $btn = $up ? '<a class="add-btn notify" href="' . $link . '">Notify</a>'
         : '<button class="add-btn js-add" data-id="' . (int)$p['id'] . '" title="Add to cart"' . ($p['stock'] > 0 ? '' : ' disabled') . '>+ 🛒</button>';
    return '<div class="card product" data-cat="' . (int)$p['category_id'] . '">' . $badge . '
      <a href="' . $link . '" class="pimg">' .
        ($img ? '<img loading="lazy" src="' . e($img) . '" alt="' . e($p['name']) . '">' : '<div class="ph">☀</div>') . '</a>
      <button class="quick-view js-quick" data-slug="' . e($p['slug']) . '" title="Quick view">👁</button>
      <div class="pbody"><small class="pbrand">' . e($p['brand']) . '</small>
      <h3><a href="' . $link . '">' . e($p['name']) . '</a></h3>
      <div class="chips">' . $chips . '</div>
      <div class="pfoot"><div><div class="price">' . money($price) . ($onSale ? ' <del>' . money($p['price']) . '</del>' : '') . '</div>' . $stock . '</div>
      ' . $btn . '</div></div></div>';
}

// ---------- Uploads ----------
/**
 * Validated upload. Public files (product images, logos) → uploads/tenant_X/
 * Private files (payment receipts) → private/tenant_X/ (blocked from the web; served by admin/receipt.php)
 */
function save_upload($field, $private = true, $imagesOnly = false) {
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!$imagesOnly) $allowed['application/pdf'] = 'pdf';
    if (empty($_FILES[$field]['tmp_name']) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return null;
    if ($_FILES[$field]['size'] > 5 * 1024 * 1024) return null;
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES[$field]['tmp_name']);   // MIME sniffing, not extension
    if (!isset($allowed[$mime])) return null;
    $rel = ($private ? 'private' : 'uploads') . '/tenant_' . TID;
    $dir = __DIR__ . '/../' . $rel;
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $name = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($_FILES[$field]['tmp_name'], "$dir/$name")) return null;
    return ['path' => "$rel/$name", 'hash' => hash_file('sha256', "$dir/$name")];
}
