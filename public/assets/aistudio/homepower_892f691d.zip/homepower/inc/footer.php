</main>
<section class="trust-strip">
  <div class="wrap trust-in">
    <div><span>🛡</span><b>Genuine &amp; warranted</b><small>Serial-tracked brand warranty</small></div>
    <div><span>🚚</span><b>Nationwide delivery</b><small>Insured courier to every city</small></div>
    <div><span>💳</span><b>Secure payments</b><small>JazzCash · Easypaisa · Bank · COD</small></div>
    <div><span>🧑‍🔧</span><b>Expert support</b><small>Sizing help &amp; after-sales service</small></div>
  </div>
</section>
<footer class="site-footer">
  <div class="wrap footer-grid">
    <div class="footer-about">
      <div class="brand light"><span class="brand-mark">☀</span><span class="brand-name"><?= e($TENANT['company_name']) ?></span></div>
      <p><?= e(setting('tagline')) ?></p>
      <?php if ($wa = preg_replace('/\D/', '', setting('whatsapp'))): ?><a class="btn accent sm" href="https://wa.me/<?= e($wa) ?>" target="_blank" rel="noopener">Chat on WhatsApp</a><?php endif; ?>
    </div>
    <div><h4>Products</h4>
      <?php foreach (rows("SELECT name, slug FROM categories WHERE tenant_id=? ORDER BY id LIMIT 6", [TID]) as $c): ?><a href="<?= url('shop.php?cat=' . urlencode($c['slug'])) ?>"><?= e($c['name']) ?></a><?php endforeach; ?></div>
    <div><h4>Support</h4>
      <a href="<?= url('track.php') ?>">Track your order</a>
      <?php if (feature('warranty')): ?><a href="<?= url('warranty.php') ?>">Warranty check</a><?php endif; ?>
      <?php if (feature('calculator')): ?><a href="<?= url('calculator.php') ?>">Solar calculator</a><?php endif; ?>
      <?php foreach ($pages as $p): ?><a href="<?= url('page.php?slug=' . urlencode($p['slug'])) ?>"><?= e($p['title']) ?></a><?php endforeach; ?></div>
    <div><h4>Get in touch</h4>
      <p class="contact-line">📍 <?= e(setting('address')) ?></p>
      <p class="contact-line">📞 <?= e(setting('phone')) ?></p>
      <p class="contact-line">✉ <?= e(setting('email')) ?></p></div>
  </div>
  <div class="wrap footer-bottom"><span>© <?= date('Y') ?> <?= e($TENANT['company_name']) ?>. All rights reserved.</span><span class="pay-icons"><i>JazzCash</i><i>Easypaisa</i><i>Raast</i><i>Bank</i><i>COD</i></span></div>
</footer>
<?php if (!empty($wa)): ?><a class="wa" href="https://wa.me/<?= e($wa) ?>" target="_blank" rel="noopener" aria-label="WhatsApp">💬</a><?php endif; ?>
<script src="<?= url('assets/app.js') ?>"></script>
<script type="application/ld+json"><?= json_encode(['@context' => 'https://schema.org', '@type' => 'LocalBusiness',
  'name' => $TENANT['company_name'], 'telephone' => setting('phone'), 'address' => setting('address')], JSON_UNESCAPED_SLASHES) ?></script>
</body></html>
