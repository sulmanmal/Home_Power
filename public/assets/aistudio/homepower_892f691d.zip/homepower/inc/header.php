<?php
/** Storefront header: SEO head, admin-built 3-level menu, jQuery. Pages may set $pageTitle, $metaDesc, $metaKeywords, $ogImage, $seoKey. */
$pages = rows("SELECT slug, title FROM cms_pages WHERE tenant_id=? AND status='published' AND show_in_menu=1", [TID]);
$logo = setting('logo');
$wa = preg_replace('/\D/', '', setting('whatsapp'));

// ---------- SEO resolution ----------
$script = basename($_SERVER['SCRIPT_NAME'], '.php');
$seoKey = $seoKey ?? ($script === 'index' ? 'home' : $script);
$seo = seo_get($seoKey);
$company = $TENANT['company_name'];
$titleTag = !empty($pageTitle) ? $pageTitle . ' | ' . $company
          : (($seo['meta_title'] ?? '') ?: (setting('seo_default_title') ?: $company . ' — ' . setting('tagline')));
$descTag = ($metaDesc ?? '') ?: (($seo['meta_description'] ?? '') ?: (setting('seo_default_desc') ?: setting('tagline')));
$kwTag = ($metaKeywords ?? '') ?: (($seo['meta_keywords'] ?? '') ?: setting('seo_keywords'));
$ogImg = ($ogImage ?? '') ?: (($seo['og_image'] ?? '') ?: (setting('og_image') ?: $logo));
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$origin = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
$keep = array_intersect_key($_GET, ['slug' => 1, 'cat' => 1]);
$canonical = $origin . strtok($_SERVER['REQUEST_URI'] ?? '/', '?') . ($keep ? '?' . http_build_query($keep) : '');
$noindex = setting('robots_noindex') === '1' || in_array($script, ['cart', 'checkout', 'track', 'invoice', 'compare']);

// ---------- Menu ----------
$menu = menu_tree();
if (!$menu) $menu = [['label' => 'Home', 'url' => 'index.php', 'open_new' => 0, 'children' => []], ['label' => 'Shop', 'url' => 'shop.php', 'open_new' => 0, 'children' => []]];
$menuStyle = in_array(setting('menu_style'), ['classic', 'centered', 'boxed', 'underline'], true) ? setting('menu_style') : 'classic';
function render_menu($items, $level = 1) {
    $h = '<ul class="lvl' . $level . '">';
    foreach ($items as $m) {
        $kids = !empty($m['children']);
        $h .= '<li class="' . ($kids ? 'has-sub' : '') . '"><a href="' . e(menu_href($m['url'])) . '"' . ($m['open_new'] ? ' target="_blank" rel="noopener"' : '') . '>' . e($m['label'])
            . ($kids ? '<span class="caret">' . ($level === 1 ? '▾' : '›') . '</span>' : '') . '</a>'
            . ($kids ? '<button class="sub-toggle" aria-label="Open submenu">+</button>' . render_menu($m['children'], $level + 1) : '') . '</li>';
    }
    return $h . '</ul>';
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($titleTag) ?></title>
<meta name="description" content="<?= e(mb_substr($descTag, 0, 300)) ?>">
<?php if ($kwTag): ?><meta name="keywords" content="<?= e($kwTag) ?>"><?php endif; ?>
<meta name="robots" content="<?= $noindex ? 'noindex,nofollow' : 'index,follow,max-image-preview:large' ?>">
<link rel="canonical" href="<?= e($canonical) ?>">
<meta property="og:type" content="<?= $script === 'product' ? 'product' : 'website' ?>">
<meta property="og:site_name" content="<?= e($company) ?>">
<meta property="og:title" content="<?= e($titleTag) ?>">
<meta property="og:description" content="<?= e(mb_substr($descTag, 0, 300)) ?>">
<meta property="og:url" content="<?= e($canonical) ?>">
<?php if ($ogImg): ?><meta property="og:image" content="<?= e($origin . url($ogImg)) ?>"><?php endif; ?>
<meta name="twitter:card" content="summary_large_image">
<?php if ($v = setting('google_verify')): ?><meta name="google-site-verification" content="<?= e($v) ?>"><?php endif; ?>
<?php if ($v = setting('bing_verify')): ?><meta name="msvalidate.01" content="<?= e($v) ?>"><?php endif; ?>
<meta name="theme-color" content="<?= e(setting('primary_color', '#0f766e')) ?>">
<?php if ($fav = setting('favicon')): ?><link rel="icon" href="<?= url($fav) ?>"><?php endif; ?>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/style.css') ?>">
<link rel="stylesheet" href="<?= url('assets/theme.css') ?>">
<style>:root{--brand:<?= e(setting('primary_color', '#0f766e')) ?>;--accent:<?= e(setting('accent_color', '#f59e0b')) ?>;
--menu-bg:<?= e(setting('menu_bg', '#ffffff')) ?>;--menu-text:<?= e(setting('menu_text', '#0b1220')) ?>;--menu-hover:<?= e(setting('menu_hover', setting('primary_color', '#0f766e'))) ?>}</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<?php if ($ga = setting('ga_id')): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= e($ga) ?>"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config',<?= json_encode($ga) ?>);</script>
<?php endif; ?>
<?= setting('head_code') /* admin-entered tracking code (Admin → SEO) */ ?>
<?= $extraHead ?? '' ?>
</head>
<body class="store">
<script>window.HPS={base:<?= json_encode(rtrim(url(''), '/')) ?>,csrf:<?= json_encode(csrf_token()) ?>};</script>
<?php if (setting('announcement', 'x') !== ''): ?>
<div class="announce">
  <div class="wrap announce-in">
    <span><?= e(setting('announcement', '☀ Free installation guidance on every complete solar system · Nationwide delivery')) ?></span>
    <span class="announce-links">
      <?php if (setting('phone')): ?><a href="tel:<?= e(preg_replace('/[^\d+]/', '', setting('phone'))) ?>">📞 <?= e(setting('phone')) ?></a><?php endif; ?>
      <a href="<?= url('track.php') ?>">Track order</a>
      <?php if (feature('warranty')): ?><a href="<?= url('warranty.php') ?>">Warranty check</a><?php endif; ?>
    </span>
  </div>
</div>
<?php endif; ?>
<header class="site-header menu-<?= $menuStyle ?>" id="siteHeader">
  <div class="wrap header-in">
    <a class="brand" href="<?= url('index.php') ?>">
      <?php if ($logo): ?><img src="<?= url($logo) ?>" alt="<?= e($company) ?>">
      <?php else: ?><span class="brand-mark">☀</span><span class="brand-name"><?= e($company) ?></span><?php endif; ?>
    </a>
    <?php if ($menuStyle !== 'boxed' && $menuStyle !== 'centered'): ?><nav class="main-nav" id="mainNav"><?= render_menu($menu) ?></nav><?php endif; ?>
    <div class="header-actions">
      <button class="icon-btn js-search-toggle" aria-label="Search">⌕</button>
      <a class="icon-btn cart-btn" href="<?= url('cart.php') ?>" aria-label="Cart">🛒<span class="cart-dot" <?= cart_count() ? '' : 'style="display:none"' ?>><?= cart_count() ?></span></a>
      <?php if ($wa): ?><a class="btn accent hide-sm" href="https://wa.me/<?= e($wa) ?>" target="_blank" rel="noopener">Get a Quote</a><?php endif; ?>
      <button class="icon-btn burger js-burger" aria-label="Menu">☰</button>
    </div>
  </div>
  <?php if ($menuStyle === 'boxed' || $menuStyle === 'centered'): ?>
  <div class="nav-row"><div class="wrap"><nav class="main-nav" id="mainNav"><?= render_menu($menu) ?></nav></div></div>
  <?php endif; ?>
  <form class="search-bar <?= !empty($_GET['q']) ? 'open' : '' ?>" id="searchBar" action="<?= url('shop.php') ?>">
    <div class="wrap"><input name="q" placeholder="Search inverters, lithium batteries, solar panels…" value="<?= e($_GET['q'] ?? '') ?>" autocomplete="off"><button class="btn">Search</button></div>
  </form>
</header>
<div class="toast" id="toast"></div>
<div class="modal" id="qvModal"><div class="modal-box"><button class="modal-x" aria-label="Close">✕</button><div class="modal-body"></div></div></div>
<?php if (empty($fullBleed)): ?><main class="wrap page-main"><?= flash() ?><?php else: ?><main><?php $f = flash(); if ($f) echo '<div class="wrap">' . $f . '</div>'; ?><?php endif; ?>
