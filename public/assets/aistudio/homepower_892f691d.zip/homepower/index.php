<?php
require 'inc/bootstrap.php';
$blocks = rows("SELECT * FROM homepage_blocks WHERE tenant_id=? AND is_enabled=1 ORDER BY sort_order", [TID]);
$fullBleed = true;
$catIcons = ['invert' => '⚡', 'batter' => '🔋', 'panel' => '☀', 'access' => '🔧', 'struct' => '🏗', 'cable' => '🔌'];
include 'inc/header.php';

/** Section heading using the title/subtitle set in Admin → Homepage */
function sec_head($b, $default, $link = null, $eyebrow = '') {
    echo '<div class="sec-head"><div>' . ($eyebrow ? '<span class="eyebrow dark">' . e($eyebrow) . '</span>' : '') .
         '<h2>' . e($b['title'] ?: $default) . '</h2>' . ($b['subtitle'] ? '<p class="muted sec-sub">' . e($b['subtitle']) . '</p>' : '') . '</div>' .
         ($link ? '<a href="' . url($link) . '" class="see-all">View all →</a>' : '') . '</div>';
}
/** Product carousel row (jQuery scroll arrows) */
function product_row($items) {
    echo '<div class="prow"><button class="prow-nav prev" aria-label="Previous">‹</button><div class="prow-track">';
    foreach ($items as $p) echo product_card($p);
    echo '</div><button class="prow-nav next" aria-label="Next">›</button></div>';
}

foreach ($blocks as $b):
  $lim = max(1, (int)($b['item_limit'] ?: 8));
  switch ($b['block_type']):

    case 'slider':
      $slides = rows("SELECT * FROM sliders WHERE tenant_id=? AND is_active=1 ORDER BY sort_order, id", [TID]);
      if (!$slides) break;
      $h = max(250, min(900, (int)setting('slider_height', '500'))); ?>
      <section class="hero-slider" id="heroSlider" style="--slider-h:<?= $h ?>px"
               data-autoplay="<?= (int)setting('slider_autoplay', '5') ?>" data-effect="<?= e(setting('slider_effect', 'fade')) ?>">
        <div class="slides">
        <?php foreach ($slides as $i => $s): ?>
          <div class="slide align-<?= e($s['text_align']) ?> <?= $i === 0 ? 'active' : '' ?>"
               style="background-color:<?= e($s['bg_color']) ?>;<?= $s['image'] ? "background-image:url('" . e(url($s['image'])) . "');" : '' ?>color:<?= e($s['text_color']) ?>">
            <?php if (!$s['image']): ?><div class="slide-deco"><span></span><span></span><span></span></div><?php endif; ?>
            <div class="wrap slide-in">
              <div class="slide-copy">
                <?php if ($s['title']): ?><h2 class="slide-title"><?= e($s['title']) ?></h2><?php endif; ?>
                <?php if ($s['subtitle']): ?><p class="slide-sub"><?= e($s['subtitle']) ?></p><?php endif; ?>
                <?php if ($s['btn_text']): ?><a class="btn lg" href="<?= e(menu_href($s['btn_link'] ?: 'shop.php')) ?>"><?= e($s['btn_text']) ?> →</a><?php endif; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        </div>
        <?php if (count($slides) > 1): ?>
        <button class="sl-arrow prev" aria-label="Previous slide">‹</button><button class="sl-arrow next" aria-label="Next slide">›</button>
        <div class="sl-dots"><?php foreach ($slides as $i => $_): ?><button class="<?= $i === 0 ? 'on' : '' ?>" aria-label="Slide <?= $i + 1 ?>"></button><?php endforeach; ?></div>
        <div class="sl-progress"><span></span></div>
        <?php endif; ?>
      </section>
    <?php break;

    case 'categories':
      $cats = rows("SELECT c.*, COUNT(p.id) n, MIN(p.image) img FROM categories c LEFT JOIN products p ON p.category_id=c.id AND p.is_active=1 WHERE c.tenant_id=? GROUP BY c.id", [TID]); ?>
      <section class="section wrap reveal">
        <?php sec_head($b, 'Shop by category', 'shop.php', 'Our range'); ?>
        <div class="cat-row">
        <?php foreach ($cats as $c): $icon = '☀'; foreach ($catIcons as $k => $ic) if (str_contains($c['slug'], $k)) $icon = $ic; ?>
          <a class="cat-pill" href="<?= url('shop.php?cat=' . urlencode($c['slug'])) ?>">
            <span class="cat-circle"><?= $c['img'] ? '<img src="' . e(url($c['img'])) . '" alt="">' : $icon ?></span>
            <b><?= e($c['name']) ?></b><small><?= $c['n'] ?> products</small>
          </a>
        <?php endforeach; ?>
        </div>
      </section>
    <?php break;

    case 'featured':
    case 'new':
    case 'sale':
      $q = ['featured' => 'is_featured=1', 'new' => 'is_new=1', 'sale' => 'sale_price>0 AND sale_price<price'][$b['block_type']];
      $items = rows("SELECT * FROM products WHERE tenant_id=? AND is_active=1 AND is_upcoming=0 AND $q ORDER BY id DESC LIMIT $lim", [TID]);
      if (!$items) break;
      $def = ['featured' => ['Featured products', 'Best sellers'], 'new' => ['New arrivals', 'Just landed'], 'sale' => ['Hot deals', 'On sale']][$b['block_type']]; ?>
      <section class="section <?= $b['block_type'] === 'sale' ? 'sale-bg' : ($b['block_type'] === 'featured' ? 'soft-bg' : '') ?> reveal"><div class="wrap">
        <?php sec_head($b, $def[0], 'shop.php', $def[1]); product_row($items); ?>
      </div></section>
    <?php break;

    case 'upcoming':
      $items = rows("SELECT * FROM products WHERE tenant_id=? AND is_active=1 AND is_upcoming=1 ORDER BY launch_date IS NULL, launch_date LIMIT $lim", [TID]);
      if (!$items) break; ?>
      <section class="section wrap reveal">
        <?php sec_head($b, 'Coming soon', null, 'Upcoming launches'); ?>
        <div class="upcoming-grid">
        <?php foreach ($items as $p): ?>
          <div class="up-card">
            <div class="up-img"><?= $p['image'] ? '<img src="' . e(url($p['image'])) . '" alt="' . e($p['name']) . '">' : '<span>⚡</span>' ?></div>
            <div class="up-body"><small class="pbrand"><?= e($p['brand']) ?></small><h3><?= e($p['name']) ?></h3>
              <p class="muted"><?= e(mb_substr($p['description'], 0, 110)) ?></p>
              <?php if ($p['launch_date']): ?><div class="countdown big" data-date="<?= e($p['launch_date']) ?>"></div><?php endif; ?>
              <div class="row"><span class="price"><?= money($p['price']) ?></span>
              <a class="btn sm" href="<?= url('product.php?slug=' . urlencode($p['slug'])) ?>">Notify me</a></div></div>
          </div>
        <?php endforeach; ?>
        </div>
      </section>
    <?php break;

    case 'all_products':
      $cats = rows("SELECT id, name FROM categories WHERE tenant_id=? ORDER BY id", [TID]); ?>
      <section class="section soft-bg reveal" id="allProducts" data-limit="<?= $lim ?>"><div class="wrap">
        <?php sec_head($b, 'All products', null, 'Browse'); ?>
        <div class="listing-bar">
          <div class="filter-tabs"><button class="on" data-cat="0">All</button><?php foreach ($cats as $c): ?><button data-cat="<?= $c['id'] ?>"><?= e($c['name']) ?></button><?php endforeach; ?></div>
          <select class="js-sort"><option value="">Newest</option><option value="price_asc">Price: low to high</option><option value="price_desc">Price: high to low</option><option value="name">Name A–Z</option></select>
        </div>
        <div class="grid4 listing-grid"></div>
        <div class="listing-foot"><span class="muted listing-count"></span><button class="btn ghost-dark js-more">Load more</button></div>
      </div></section>
    <?php break;

    case 'features': ?>
      <section class="section wrap reveal">
        <div class="why">
          <div class="why-copy"><span class="eyebrow dark">Why choose us</span>
            <h2><?= e($b['title'] ?: "Engineered for Pakistan's sun, load-shedding and heat") ?></h2>
            <p class="muted"><?= e($b['subtitle'] ?: 'From a single home backup to a full hybrid system, we supply tested equipment and help you size it right the first time.') ?></p>
            <?php if (feature('calculator')): ?><a class="btn" href="<?= url('calculator.php') ?>">Try the solar calculator</a><?php endif; ?></div>
          <div class="why-grid">
            <div class="why-card"><span>🛡</span><b>Authorised &amp; genuine</b><p>Every unit is serial-registered so your warranty is always traceable.</p></div>
            <div class="why-card"><span>⚡</span><b>High-efficiency tech</b><p>Hybrid inverters with dual MPPT and LiFePO4 batteries built for daily cycling.</p></div>
            <div class="why-card"><span>🌡</span><b>Built for the heat</b><p>Equipment selected for 45°C+ summers and dusty conditions.</p></div>
            <div class="why-card"><span>🤝</span><b>After-sales care</b><p>Installer network and fast warranty claims through WhatsApp.</p></div>
          </div>
        </div>
      </section>
    <?php break;

    case 'calculator': if (!feature('calculator')) break; ?>
      <section class="wrap reveal"><div class="cta-band">
        <div><span class="eyebrow">Free tool</span><h2><?= e($b['title'] ?: 'How big a solar system do you need?') ?></h2>
          <p><?= e($b['subtitle'] ?: 'Choose your fans, ACs and appliances — get the right inverter, battery bank and panel count, plus your monthly savings and payback period.') ?></p></div>
        <div class="cta-steps"><span><b>1</b>Pick appliances</span><span><b>2</b>Get sizing</span><span><b>3</b>Add bundle to cart</span>
          <a class="btn accent lg" href="<?= url('calculator.php') ?>">Calculate now →</a></div>
      </div></section>
    <?php break;

    case 'testimonials': ?>
      <section class="section wrap reveal">
        <div class="sec-head center"><div><span class="eyebrow dark">Customer stories</span><h2><?= e($b['title'] ?: 'Trusted by homes & businesses') ?></h2></div></div>
        <div class="grid3">
          <figure class="review"><div class="stars">★★★★★</div><blockquote>Installed a 6kW hybrid system — our electricity bill dropped by more than 80%.</blockquote><figcaption><span class="avatar">A</span><b>Ahmed R.</b><small>Lahore · Homeowner</small></figcaption></figure>
          <figure class="review"><div class="stars">★★★★★</div><blockquote>Payment receipt was verified the same day and the system arrived in three days.</blockquote><figcaption><span class="avatar">S</span><b>Sana K.</b><small>Faisalabad · Clinic owner</small></figcaption></figure>
          <figure class="review"><div class="stars">★★★★★</div><blockquote>My battery warranty claim was handled quickly over WhatsApp. Great support.</blockquote><figcaption><span class="avatar">U</span><b>Usman T.</b><small>Multan · Installer</small></figcaption></figure>
        </div>
      </section>
    <?php break;
  endswitch;
endforeach; ?>

<?php if ($wa): ?>
<section class="wrap reveal"><div class="quote-band">
  <div><h3>Planning a commercial or bulk order?</h3><p>Installers, dealers and businesses get special pricing. Talk to our team today.</p></div>
  <a class="btn accent lg" href="https://wa.me/<?= e($wa) ?>?text=<?= urlencode('Hi, I need a quote for a solar system') ?>" target="_blank" rel="noopener">Request a quote</a>
</div></section>
<?php endif; ?>
<?php include 'inc/footer.php';
