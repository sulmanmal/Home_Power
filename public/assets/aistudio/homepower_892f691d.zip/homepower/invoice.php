<?php
require 'inc/bootstrap.php';
// Customers open via tracking code; tenant admins via ?id=
$order = null;
if (!empty($_GET['code'])) $order = row("SELECT * FROM orders WHERE tenant_id=? AND tracking_code=?", [TID, strtoupper($_GET['code'])]);
elseif (!empty($_GET['id']) && !empty($_SESSION['admin'][TID])) $order = row("SELECT * FROM orders WHERE tenant_id=? AND id=?", [TID, $_GET['id']]);
if (!$order) { http_response_code(404); exit('Invoice not found.'); }
$items = rows("SELECT * FROM order_items WHERE order_id=? AND tenant_id=?", [$order['id'], TID]);
?><!doctype html><html><head><meta charset="utf-8"><title>Invoice <?= e($order['order_number']) ?></title>
<style>body{font-family:system-ui,sans-serif;max-width:780px;margin:30px auto;color:#222;padding:0 16px}
h1{color:<?= e(setting('primary_color', '#0f766e')) ?>;margin:0}table{width:100%;border-collapse:collapse;margin:20px 0}
td,th{border-bottom:1px solid #ddd;padding:8px;text-align:left}.r{text-align:right}.top{display:flex;justify-content:space-between;gap:20px}
@media print{button{display:none}}</style></head><body>
<div class="top"><div><h1><?= e($TENANT['company_name']) ?></h1><p><?= e(setting('address')) ?><br><?= e(setting('phone')) ?> · <?= e(setting('email')) ?>
<?= setting('ntn') ? '<br>NTN: ' . e(setting('ntn')) : '' ?></p></div>
<div class="r"><h2>INVOICE</h2><p>#<?= e($order['order_number']) ?><br><?= date('d M Y', strtotime($order['created_at'])) ?><br>Status: <?= e(str_replace('_', ' ', $order['status'])) ?></p></div></div>
<p><b>Bill to:</b> <?= e($order['customer_name']) ?>, <?= e($order['phone']) ?><br><?= e($order['address']) ?>, <?= e($order['city']) ?></p>
<table><tr><th>Item</th><th class="r">Unit price</th><th class="r">Qty</th><th class="r">Amount</th></tr>
<?php foreach ($items as $i): ?><tr><td><?= e($i['product_name']) ?></td><td class="r"><?= money($i['unit_price']) ?></td><td class="r"><?= $i['quantity'] ?></td><td class="r"><?= money($i['unit_price'] * $i['quantity']) ?></td></tr><?php endforeach; ?>
<tr><td colspan="3" class="r">Subtotal</td><td class="r"><?= money($order['subtotal']) ?></td></tr>
<?php if ($order['discount'] > 0): ?><tr><td colspan="3" class="r">Discount</td><td class="r">− <?= money($order['discount']) ?></td></tr><?php endif; ?>
<tr><td colspan="3" class="r">Shipping</td><td class="r"><?= money($order['shipping']) ?></td></tr>
<tr><th colspan="3" class="r">Total</th><th class="r"><?= money($order['total']) ?></th></tr></table>
<p>Thank you for your business.</p><button onclick="print()">Print / Save as PDF</button>
</body></html>
