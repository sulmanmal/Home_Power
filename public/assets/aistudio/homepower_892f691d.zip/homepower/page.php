<?php
require 'inc/bootstrap.php';
$pg = row("SELECT * FROM cms_pages WHERE tenant_id=? AND slug=? AND status='published'", [TID, $_GET['slug'] ?? '']);
if (!$pg) {
    // SEO redirects
    $rd = row("SELECT * FROM seo_redirects WHERE tenant_id=? AND source_url=?", [TID, $_SERVER['REQUEST_URI']]);
    if ($rd) { header('Location: ' . $rd['target_url'], true, (int)$rd['redirect_code']); exit; }
    http_response_code(404);
}
$pageTitle = $pg['title'] ?? 'Page not found';
$metaDesc = $pg['meta_description'] ?? '';
include 'inc/header.php';
?>
<article class="card page"><h1><?= e($pageTitle) ?></h1><?= $pg['content'] ?? '<p>Sorry, this page does not exist.</p>' ?></article>
<?php include 'inc/footer.php';
