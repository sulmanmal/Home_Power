<?php
/** Platform control plane (SaaS owner). Not tenant-scoped. */
define('PLATFORM_AREA', true);
require __DIR__ . '/../inc/bootstrap.php';

function padmin() { return $_SESSION['platform_admin'] ?? null; }
function require_padmin($write = false) {
    $a = padmin();
    if (!$a) redirect('platform/login.php');
    if ($write && $a['role'] === 'readonly') exit('Read-only account.');
    return $a;
}
function paudit($action, $tenantId = null) {
    q("INSERT INTO platform_audit_logs (platform_admin_id, action, target_tenant_id, ip_address) VALUES (?,?,?,?)",
      [padmin()['id'], $action, $tenantId, $_SERVER['REMOTE_ADDR'] ?? '']);
}
function p_head($title) {
    $a = padmin();
    echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . e($title) . ' — Platform</title>
    <link rel="stylesheet" href="' . url('assets/style.css') . '"><style>:root{--brand:#1e293b;--accent:#f59e0b}</style></head>
    <body class="admin"><aside><div class="alogo">☀ Solar SaaS<small>Platform control</small></div><nav>
    <a href="' . url('platform/index.php') . '">Tenants</a><a href="' . url('platform/index.php?new=1') . '">+ New tenant</a><a href="' . url('platform/plans.php') . '">Plans</a><a href="' . url('platform/logout.php') . '">Log out (' . e($a['username']) . ')</a></nav></aside>
    <section class="amain"><h1>' . e($title) . '</h1>' . flash();
}
function p_foot() { echo '</section></body></html>'; }

/** Provision a new tenant: record, domain, settings, owner admin, starter data. */
function provision_tenant($company, $slug, $planId, $ownerEmail, $ownerPass, $domain = '', $cloneFrom = 0) {
    $pdo = db(); $pdo->beginTransaction();
    try {
        $uuid = sprintf('%04x%04x-%04x-4%03x-%04x-%012x', random_int(0, 65535), random_int(0, 65535), random_int(0, 65535), random_int(0, 4095), random_int(32768, 49151), random_int(0, 0xffffffffffff));
        q("INSERT INTO tenants (uuid, company_name, slug, plan_id, status, trial_ends_at) VALUES (?,?,?,?, 'active', NOW()+INTERVAL 14 DAY)", [$uuid, $company, $slug, $planId]);
        $tid = $pdo->lastInsertId();
        if ($domain) q("INSERT INTO tenant_domains (tenant_id, domain, is_primary) VALUES (?,?,1)", [$tid, strtolower($domain)]);
        q("INSERT INTO admin_users (tenant_id, username, email, password_hash, role) VALUES (?,?,?,?, 'owner')", [$tid, 'admin', $ownerEmail, password_hash($ownerPass, PASSWORD_DEFAULT)]);
        $defaults = ['primary_color' => '#0f766e', 'accent_color' => '#f59e0b', 'tagline' => 'Solar inverters, batteries and panels', 'email' => $ownerEmail, 'tariff_per_unit' => '60'];
        foreach ($defaults as $k => $v) q("INSERT INTO tenant_settings (tenant_id, setting_key, setting_value) VALUES (?,?,?)", [$tid, $k, $v]);
        foreach (['slider', 'categories', 'featured', 'sale', 'new', 'upcoming', 'features', 'all_products', 'calculator', 'testimonials'] as $i => $b)
            q("INSERT INTO homepage_blocks (tenant_id, block_type, sort_order, item_limit) VALUES (?,?,?,?)", [$tid, $b, $i + 1, $b === 'all_products' ? 12 : 8]);
        q("INSERT INTO sliders (tenant_id, title, subtitle, btn_text, btn_link, bg_color, sort_order) VALUES (?,?,?,?,?,?,1)",
          [$tid, 'Welcome to ' . $company, 'Solar inverters, batteries and panels with warranty and nationwide delivery.', 'Shop now', 'shop.php', '#e8f5f1']);
        foreach ([['Home', 'index.php'], ['Shop', 'shop.php'], ['Solar Calculator', 'calculator.php'], ['About Us', 'page.php?slug=about'], ['Track Order', 'track.php']] as $i => [$l, $u])
            q("INSERT INTO menu_items (tenant_id, label, url, sort_order) VALUES (?,?,?,?)", [$tid, $l, $u, $i + 1]);
        foreach (['menu_style' => 'classic', 'menu_bg' => '#ffffff', 'menu_text' => '#0b1220', 'menu_hover' => '#0f766e', 'slider_height' => '500', 'slider_autoplay' => '5', 'slider_effect' => 'fade'] as $k => $v)
            q("INSERT INTO tenant_settings (tenant_id, setting_key, setting_value) VALUES (?,?,?)", [$tid, $k, $v]);
        q("INSERT INTO shipping_rates (tenant_id, zone_name, base_cost, per_kg) VALUES (?,'Local',500,0),(?,'Nationwide',2000,30)", [$tid, $tid]);
        q("INSERT INTO cms_pages (tenant_id, slug, title, content) VALUES (?,'about','About Us',?)", [$tid, '<p>Welcome to ' . e($company) . '.</p>']);
        // Starter catalog: clone categories + products from another tenant (template)
        if ($cloneFrom) {
            $map = [];
            foreach (rows("SELECT * FROM categories WHERE tenant_id=?", [$cloneFrom]) as $c) {
                q("INSERT INTO categories (tenant_id, name, slug) VALUES (?,?,?)", [$tid, $c['name'], $c['slug']]);
                $map[$c['id']] = $pdo->lastInsertId();
            }
            foreach (rows("SELECT * FROM products WHERE tenant_id=? AND is_active=1", [$cloneFrom]) as $p)
                q("INSERT INTO products (tenant_id, category_id, name, slug, sku, brand, description, price, capacity, voltage, warranty_months, weight_kg, is_featured, stock)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0)", [$tid, $map[$p['category_id']] ?? null, $p['name'], $p['slug'], $p['sku'], $p['brand'], $p['description'], $p['price'], $p['capacity'], $p['voltage'], $p['warranty_months'], $p['weight_kg'], $p['is_featured']]);
        } else {
            foreach (['Inverters' => 'inverters', 'Batteries' => 'batteries', 'Solar Panels' => 'solar-panels', 'Accessories' => 'accessories'] as $n => $s)
                q("INSERT INTO categories (tenant_id, name, slug) VALUES (?,?,?)", [$tid, $n, $s]);
        }
        $pdo->commit();
        return $tid;
    } catch (Exception $e) { $pdo->rollBack(); throw $e; }
}
