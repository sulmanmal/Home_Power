<?php
require __DIR__ . '/_init.php';
$me = require_padmin();
$plans = rows("SELECT * FROM plans WHERE is_active=1 ORDER BY price_monthly");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_padmin(true);
    $slug = trim(preg_replace('/[^a-z0-9-]+/', '-', strtolower($_POST['slug'])), '-');
    $err = null;
    if (!$slug || in_array($slug, ['www', 'admin', 'platform', 'api', 'mail'])) $err = 'Choose a different subdomain.';
    elseif (row("SELECT id FROM tenants WHERE slug=?", [$slug])) $err = 'Subdomain already taken.';
    elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) $err = 'Invalid owner email.';
    elseif (strlen($_POST['password']) < 8) $err = 'Owner password must be at least 8 characters.';
    elseif ($_POST['domain'] && row("SELECT id FROM tenant_domains WHERE domain=?", [strtolower($_POST['domain'])])) $err = 'Domain already attached to another store.';
    if ($err) { flash($err, 'err'); redirect('platform/index.php?new=1'); }
    try {
        $tid = provision_tenant(trim($_POST['company']), $slug, (int)$_POST['plan_id'], $_POST['email'], $_POST['password'], trim($_POST['domain']), (int)($_POST['clone'] ?? 0));
        paudit('tenant_created', $tid);
        flash("Store created. Admin login: username “admin” at {$slug}." . PLATFORM_DOMAIN . "/admin (or ?tenant={$slug} locally).");
        redirect('platform/tenant.php?id=' . $tid);
    } catch (Exception $e) { flash('Provisioning failed: ' . $e->getMessage(), 'err'); redirect('platform/index.php?new=1'); }
}

if (!empty($_GET['new'])) {
    $tenants = rows("SELECT id, company_name FROM tenants ORDER BY id");
    p_head('Create new tenant store'); ?>
    <form method="post" class="card"><?= csrf_field() ?>
      <div class="grid2"><label>Company name<input name="company" required></label>
      <label>Subdomain<div class="row"><input name="slug" required pattern="[a-z0-9-]+" placeholder="acmesolar">.<?= e(PLATFORM_DOMAIN) ?></div></label></div>
      <div class="grid2"><label>Custom domain (optional)<input name="domain" placeholder="www.acmesolar.pk"></label>
      <label>Plan<select name="plan_id"><?php foreach ($plans as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['name']) ?> — <?= money($p['price_monthly']) ?>/mo</option><?php endforeach; ?></select></label></div>
      <div class="grid2"><label>Owner email<input type="email" name="email" required></label><label>Owner password<input type="text" name="password" required minlength="8"></label></div>
      <label>Starter catalog<select name="clone"><option value="0">Empty (categories only)</option><?php foreach ($tenants as $t): ?><option value="<?= $t['id'] ?>">Copy products from <?= e($t['company_name']) ?></option><?php endforeach; ?></select></label>
      <button class="btn accent">Provision store</button></form>
    <?php p_foot(); exit;
}

$k = row("SELECT COUNT(*) total, SUM(t.status='active') active, SUM(t.status='suspended') suspended,
          COALESCE(SUM(CASE WHEN t.status='active' THEN p.price_monthly END),0) mrr FROM tenants t JOIN plans p ON p.id=t.plan_id");
$gmv = row("SELECT COALESCE(SUM(total),0) g FROM orders WHERE status IN ('verified','dispatched','completed') AND created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')")['g'];
$list = rows("SELECT t.*, p.name plan, p.transaction_fee_pct fee,
  (SELECT domain FROM tenant_domains d WHERE d.tenant_id=t.id AND is_primary=1 LIMIT 1) domain,
  (SELECT COUNT(*) FROM products x WHERE x.tenant_id=t.id) products,
  (SELECT COUNT(*) FROM orders o WHERE o.tenant_id=t.id) orders,
  (SELECT COALESCE(SUM(total),0) FROM orders o WHERE o.tenant_id=t.id AND o.status IN ('verified','dispatched','completed') AND o.created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')) gmv
  FROM tenants t JOIN plans p ON p.id=t.plan_id ORDER BY t.id");
$fees = array_sum(array_map(fn($t) => $t['gmv'] * $t['fee'] / 100, $list));
p_head('Tenants'); ?>
<div class="kpis">
  <div class="card"><small>Stores</small><b><?= $k['total'] ?></b></div><div class="card"><small>Active</small><b><?= (int)$k['active'] ?></b></div>
  <div class="card"><small>Suspended</small><b><?= (int)$k['suspended'] ?></b></div><div class="card"><small>MRR (subscriptions)</small><b><?= money($k['mrr']) ?></b></div>
  <div class="card"><small>GMV this month / fees</small><b><?= money($gmv) ?></b><small><?= money($fees) ?> transaction fees</small></div>
</div>
<div class="card"><table class="tbl"><tr><th>Store</th><th>Address</th><th>Plan</th><th>Products</th><th>Orders</th><th>GMV (month)</th><th>Status</th></tr>
<?php foreach ($list as $t): ?><tr><td><a href="tenant.php?id=<?= $t['id'] ?>"><b><?= e($t['company_name']) ?></b></a></td>
<td><small><?= e($t['domain'] ?: $t['slug'] . '.' . PLATFORM_DOMAIN) ?></small></td><td><?= e($t['plan']) ?></td><td><?= $t['products'] ?></td><td><?= $t['orders'] ?></td><td><?= money($t['gmv']) ?></td>
<td><span class="status s-<?= e($t['status']) ?>"><?= e($t['status']) ?></span></td></tr><?php endforeach; ?></table></div>
<?php p_foot();
