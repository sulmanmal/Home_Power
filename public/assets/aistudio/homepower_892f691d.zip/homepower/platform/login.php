<?php
require __DIR__ . '/_init.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['p_fail'] ??= 0;
    if ($_SESSION['p_fail'] >= 5 && time() - ($_SESSION['p_last'] ?? 0) < 600) $err = 'Too many attempts. Wait 10 minutes.';
    else {
        $a = row("SELECT * FROM platform_admins WHERE username=?", [$_POST['username'] ?? '']);
        if ($a && password_verify($_POST['password'] ?? '', $a['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['platform_admin'] = ['id' => $a['id'], 'username' => $a['username'], 'role' => $a['role']];
            $_SESSION['p_fail'] = 0;
            q("UPDATE platform_admins SET last_login_at=NOW() WHERE id=?", [$a['id']]);
            redirect('platform/index.php');
        }
        $_SESSION['p_fail']++; $_SESSION['p_last'] = time(); $err = 'Invalid login.';
    }
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Platform login</title>
<link rel="stylesheet" href="<?= url('assets/style.css') ?>"><style>:root{--brand:#1e293b}</style></head>
<body class="loginpage"><form method="post" class="card login"><?= csrf_field() ?><h2>☀ Platform Control</h2><p class="muted">SaaS owner login</p>
<?php if ($err): ?><div class="alert alert-err"><?= e($err) ?></div><?php endif; ?>
<label>Username<input name="username" required autofocus></label><label>Password<input type="password" name="password" required></label>
<button class="btn block">Log in</button></form></body></html>
