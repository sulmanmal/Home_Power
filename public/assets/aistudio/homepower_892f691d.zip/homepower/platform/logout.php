<?php
require __DIR__ . '/_init.php';
unset($_SESSION['platform_admin']);
redirect('platform/login.php');
