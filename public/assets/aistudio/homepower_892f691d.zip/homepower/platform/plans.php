<?php
require __DIR__ . '/_init.php';
require_padmin();
$keys = ['calculator', 'coupons', 'warranty', 'custom_domain'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_padmin(true);
    foreach ($_POST['p'] ?? [] as $id => $p) {
        $f = []; foreach ($keys as $k) $f[$k] = !empty($p['f'][$k]);
        q("UPDATE plans SET price_monthly=?, transaction_fee_pct=?, max_products=?, max_staff=?, max_domains=?, features_json=? WHERE id=?",
          [(float)$p['price'], (float)$p['fee'], (int)$p['max_products'], (int)$p['max_staff'], (int)$p['max_domains'], json_encode($f), (int)$id]);
    }
    paudit('plans_update'); flash('Plans saved.'); redirect('platform/plans.php');
}
$plans = rows("SELECT * FROM plans ORDER BY price_monthly");
p_head('Subscription plans'); ?>
<form method="post" class="card" style="overflow-x:auto"><?= csrf_field() ?><table class="tbl">
<tr><th>Plan</th><th>Rs / month</th><th>Txn fee %</th><th>Max products</th><th>Max staff</th><th>Domains</th><?php foreach ($keys as $k): ?><th><?= e(str_replace('_', ' ', $k)) ?></th><?php endforeach; ?></tr>
<?php foreach ($plans as $p): $f = json_decode($p['features_json'], true); $i = $p['id']; ?>
<tr><td><b><?= e($p['name']) ?></b></td><td><input type="number" name="p[<?= $i ?>][price]" value="<?= (float)$p['price_monthly'] ?>" style="width:100px"></td>
<td><input type="number" step="0.01" name="p[<?= $i ?>][fee]" value="<?= (float)$p['transaction_fee_pct'] ?>" style="width:70px"></td>
<td><input type="number" name="p[<?= $i ?>][max_products]" value="<?= $p['max_products'] ?>" style="width:90px"></td>
<td><input type="number" name="p[<?= $i ?>][max_staff]" value="<?= $p['max_staff'] ?>" style="width:70px"></td>
<td><input type="number" name="p[<?= $i ?>][max_domains]" value="<?= $p['max_domains'] ?>" style="width:70px"></td>
<?php foreach ($keys as $k): ?><td><input type="checkbox" name="p[<?= $i ?>][f][<?= $k ?>]" <?= !empty($f[$k]) ? 'checked' : '' ?>></td><?php endforeach; ?></tr>
<?php endforeach; ?></table><button class="btn">Save plans</button></form>
<?php p_foot();
