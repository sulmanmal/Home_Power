<?php
require __DIR__ . '/_init.php';
$me = require_padmin();
$t = row("SELECT * FROM tenants WHERE id=?", [$_GET['id'] ?? $_POST['id'] ?? 0]) or exit('Tenant not found');
$tid = (int)$t['id'];
$featureKeys = ['calculator' => 'Solar calculator', 'coupons' => 'Coupons', 'warranty' => 'Warranty & serials', 'custom_domain' => 'Custom domain'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_padmin(true);
    switch ($_POST['act'] ?? '') {
        case 'plan':
            q("UPDATE tenants SET plan_id=?, company_name=? WHERE id=?", [(int)$_POST['plan_id'], trim($_POST['company_name']), $tid]);
            paudit('tenant_plan_change', $tid); flash('Plan updated.'); break;
        case 'status':
            $st = in_array($_POST['status'], ['active', 'suspended', 'archived'], true) ? $_POST['status'] : 'active';
            q("UPDATE tenants SET status=?, suspended_reason=? WHERE id=?", [$st, $_POST['reason'] ?? null, $tid]);
            paudit('tenant_' . $st, $tid); flash("Store is now $st."); break;
        case 'domain_add':
            $d = strtolower(trim(preg_replace('#^https?://#', '', $_POST['domain']), '/ '));
            try { q("INSERT INTO tenant_domains (tenant_id, domain, is_primary) VALUES (?,?,?)", [$tid, $d, !row("SELECT id FROM tenant_domains WHERE tenant_id=?", [$tid]) ? 1 : 0]);
                  paudit('domain_add:' . $d, $tid); flash('Domain added. Point its DNS A record to this server, then mark it verified.'); }
            catch (PDOException $e) { flash('Domain already in use.', 'err'); } break;
        case 'domain_verify':
            $d = row("SELECT * FROM tenant_domains WHERE id=? AND tenant_id=?", [(int)$_POST['did'], $tid]);
            $ok = $d && gethostbyname($d['domain']) === ($_SERVER['SERVER_ADDR'] ?? '');
            if ($ok || !empty($_POST['force'])) { q("UPDATE tenant_domains SET verified_at=NOW() WHERE id=?", [$d['id']]); flash('Domain marked as verified.'); }
            else flash('DNS does not point to this server yet (' . e(gethostbyname($d['domain'] ?? '')) . '). Use "force" if you are sure.', 'err');
            break;
        case 'domain_primary':
            q("UPDATE tenant_domains SET is_primary=(id=?) WHERE tenant_id=?", [(int)$_POST['did'], $tid]); flash('Primary domain set.'); break;
        case 'domain_del':
            q("DELETE FROM tenant_domains WHERE id=? AND tenant_id=?", [(int)$_POST['did'], $tid]); paudit('domain_remove', $tid); flash('Domain removed.'); break;
        case 'features':
            q("DELETE FROM tenant_feature_overrides WHERE tenant_id=?", [$tid]);
            foreach ($featureKeys as $k => $_) if (($_POST['f'][$k] ?? '') !== '')
                q("INSERT INTO tenant_feature_overrides (tenant_id, feature_key, enabled) VALUES (?,?,?)", [$tid, $k, (int)$_POST['f'][$k]]);
            paudit('feature_overrides', $tid); flash('Feature overrides saved.'); break;
        case 'reset_pass':
            if (strlen($_POST['password']) >= 8) { q("UPDATE admin_users SET password_hash=? WHERE tenant_id=? AND role='owner'", [password_hash($_POST['password'], PASSWORD_DEFAULT), $tid]);
                paudit('owner_password_reset', $tid); flash('Owner password reset.'); } else flash('Password must be 8+ characters.', 'err');
            break;
        case 'impersonate':
            $owner = row("SELECT * FROM admin_users WHERE tenant_id=? AND role='owner' LIMIT 1", [$tid]);
            if ($owner) {
                $_SESSION['admin'][$tid] = ['id' => $owner['id'], 'username' => $owner['username'] . ' (via platform)', 'role' => 'owner'];
                q("INSERT INTO audit_logs (tenant_id, admin_id, action, ip_address) VALUES (?,?,?,?)", [$tid, $owner['id'], 'platform_impersonation_by_' . $me['username'], $_SERVER['REMOTE_ADDR'] ?? '']);
                paudit('impersonate', $tid);
                redirect('admin/index.php?tenant=' . urlencode($t['slug']));
            }
            break;
    }
    redirect('platform/tenant.php?id=' . $tid);
}

$plans = rows("SELECT * FROM plans ORDER BY price_monthly");
$domains = rows("SELECT * FROM tenant_domains WHERE tenant_id=?", [$tid]);
$over = []; foreach (rows("SELECT * FROM tenant_feature_overrides WHERE tenant_id=?", [$tid]) as $o) $over[$o['feature_key']] = $o['enabled'];
$owner = row("SELECT username, email, last_login_at FROM admin_users WHERE tenant_id=? AND role='owner' LIMIT 1", [$tid]);
$usage = row("SELECT (SELECT COUNT(*) FROM products WHERE tenant_id=?) products, (SELECT COUNT(*) FROM admin_users WHERE tenant_id=?) staff,
              (SELECT COUNT(*) FROM orders WHERE tenant_id=? AND created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')) orders_month", [$tid, $tid, $tid]);
$plan = row("SELECT * FROM plans WHERE id=?", [$t['plan_id']]);
$log = rows("SELECT l.*, a.username FROM platform_audit_logs l JOIN platform_admins a ON a.id=l.platform_admin_id WHERE target_tenant_id=? ORDER BY l.id DESC LIMIT 15", [$tid]);
p_head($t['company_name']); ?>
<p><a href="index.php">← All tenants</a> · <a target="_blank" href="<?= url('index.php?tenant=' . urlencode($t['slug'])) ?>">Open storefront ↗</a> · Subdomain: <b><?= e($t['slug']) ?>.<?= e(PLATFORM_DOMAIN) ?></b> · Since <?= date('d M Y', strtotime($t['created_at'])) ?></p>
<div class="kpis">
  <div class="card"><small>Products</small><b><?= $usage['products'] ?> / <?= $plan['max_products'] ?></b></div>
  <div class="card"><small>Staff</small><b><?= $usage['staff'] ?> / <?= $plan['max_staff'] ?></b></div>
  <div class="card"><small>Orders this month</small><b><?= $usage['orders_month'] ?></b></div>
  <div class="card"><small>Owner</small><b style="font-size:1rem"><?= e($owner['email'] ?? '—') ?></b><small>last login <?= e($owner['last_login_at'] ?? 'never') ?></small></div>
</div>
<div class="grid2">
  <form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="act" value="plan"><h3>Company &amp; plan</h3>
    <label>Company name<input name="company_name" value="<?= e($t['company_name']) ?>"></label>
    <label>Plan<select name="plan_id"><?php foreach ($plans as $p): ?><option value="<?= $p['id'] ?>" <?= $p['id'] == $t['plan_id'] ? 'selected' : '' ?>><?= e($p['name']) ?> — <?= money($p['price_monthly']) ?>/mo</option><?php endforeach; ?></select></label>
    <button class="btn">Save</button></form>
  <form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="act" value="status"><h3>Status: <span class="status s-<?= e($t['status']) ?>"><?= e($t['status']) ?></span></h3>
    <label>Change to<select name="status"><option>active</option><option>suspended</option><option>archived</option></select></label>
    <label>Reason (e.g. non-payment)<input name="reason" value="<?= e($t['suspended_reason']) ?>"></label>
    <button class="btn">Update status</button><p class="muted">Suspended stores show a maintenance page and admins are locked out. Data is kept.</p></form>
</div>
<div class="grid2">
  <div class="card"><h3>Domains</h3>
    <table class="tbl"><?php foreach ($domains as $d): ?><tr><td><?= e($d['domain']) ?><?= $d['is_primary'] ? ' <small>(primary)</small>' : '' ?></td>
      <td><?= $d['verified_at'] ? '<span class="in">verified</span>' : '<span class="out">pending</span>' ?></td>
      <td><form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="did" value="<?= $d['id'] ?>">
        <?php if (!$d['verified_at']): ?><button class="link" name="act" value="domain_verify">Check DNS</button><button class="link" name="act" value="domain_verify" onclick="this.form.insertAdjacentHTML('beforeend','<input type=hidden name=force value=1>')">Force</button><?php endif; ?>
        <?php if (!$d['is_primary']): ?><button class="link" name="act" value="domain_primary">Make primary</button><?php endif; ?>
        <button class="link" name="act" value="domain_del" onclick="return confirm('Remove domain?')">Remove</button></form></td></tr><?php endforeach; ?></table>
    <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="act" value="domain_add"><input name="domain" placeholder="www.theirstore.pk" required><button class="btn sm">Add domain</button></form>
    <p class="muted">Customer points the domain's A record to your server IP. SSL: run certbot for the new domain (see README).</p></div>
  <form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="act" value="features"><h3>Feature overrides</h3>
    <?php $pf = json_decode($plan['features_json'], true); foreach ($featureKeys as $k => $l): ?>
    <label><?= $l ?> <small class="muted">(plan: <?= !empty($pf[$k]) ? 'on' : 'off' ?>)</small><select name="f[<?= $k ?>]">
      <option value="">Follow plan</option><option value="1" <?= ($over[$k] ?? null) === 1 ? 'selected' : '' ?>>Force ON</option><option value="0" <?= ($over[$k] ?? null) === 0 ? 'selected' : '' ?>>Force OFF</option></select></label>
    <?php endforeach; ?><button class="btn">Save overrides</button></form>
</div>
<div class="grid2">
  <div class="card"><h3>Support access</h3>
    <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="act" value="reset_pass"><input name="password" placeholder="New owner password" minlength="8" required><button class="btn sm">Reset owner password</button></form>
    <form method="post" onsubmit="return confirm('Log in to this store admin? This is recorded in the store\'s audit log.')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="act" value="impersonate"><button class="btn ghost-dark">Log in as store owner (audited)</button></form></div>
  <div class="card"><h3>Platform activity on this store</h3><table class="tbl"><?php foreach ($log as $l): ?><tr><td><small><?= e($l['created_at']) ?></small></td><td><?= e($l['username']) ?></td><td><?= e($l['action']) ?></td></tr><?php endforeach; ?></table></div>
</div>
<?php p_foot();
