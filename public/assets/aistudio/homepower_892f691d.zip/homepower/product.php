<?php
require 'inc/bootstrap.php';
$p = row("SELECT p.*, c.name cat, c.slug cslug FROM products p LEFT JOIN categories c ON c.id=p.category_id
          WHERE p.tenant_id=? AND p.slug=? AND p.is_active=1", [TID, $_GET['slug'] ?? '']);
if (!$p) { http_response_code(404); $pageTitle = 'Not found'; include 'inc/header.php'; echo '<h1>Product not found</h1>'; include 'inc/footer.php'; exit; }

$pageTitle = $p['meta_title'] ?: $p['name'];
$metaKeywords = $p['meta_keywords'] ?: '';
$ogImage = $p['image'];
$metaDesc = $p['meta_description'] ?: mb_substr(strip_tags($p['description']), 0, 155);
$schema = ['@context' => 'https://schema.org', '@type' => 'Product', 'name' => $p['name'], 'sku' => $p['sku'],
    'brand' => ['@type' => 'Brand', 'name' => $p['brand']], 'description' => $metaDesc,
    'offers' => ['@type' => 'Offer', 'priceCurrency' => 'PKR', 'price' => eff_price($p),
        'availability' => $p['stock'] > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock']];
$extraHead = '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES) . '</script>';
$related = rows("SELECT * FROM products WHERE tenant_id=? AND category_id<=>? AND id<>? AND is_active=1 LIMIT 4", [TID, $p['category_id'], $p['id']]);
include 'inc/header.php';
?>
<p class="crumbs"><a href="<?= url('index.php') ?>">Home</a> › <a href="<?= url('shop.php?cat=' . urlencode($p['cslug'] ?? '')) ?>"><?= e($p['cat']) ?></a> › <?= e($p['name']) ?></p>
<div class="pdp">
  <div class="card pimg big"><?= $p['image'] ? '<img src="' . e(url($p['image'])) . '" alt="' . e($p['name']) . '">' : '<div class="ph">☀</div>' ?></div>
  <div>
    <small><?= e($p['brand']) ?> · SKU <?= e($p['sku']) ?></small>
    <h1><?= e($p['name']) ?></h1>
    <?php $ep = eff_price($p); ?>
    <div class="price big"><?= money($ep) ?><?php if ($ep < $p['price']): ?> <del><?= money($p['price']) ?></del> <span class="pbadge sale static">Save <?= money($p['price'] - $ep) ?></span><?php endif; ?></div>
    <?php if ($p['price_installer']): ?><p class="muted">Installer / dealer price: <?= money($p['price_installer']) ?> — <a href="https://wa.me/<?= e(preg_replace('/\D/', '', setting('whatsapp'))) ?>">ask for a quote</a></p><?php endif; ?>
    <p><?= $p['stock'] > 0 ? '<span class="in">In stock (' . (int)$p['stock'] . ')</span>' : '<span class="out">Out of stock</span>' ?></p>
    <?php if ($p['is_upcoming']): ?>
      <div class="card soft"><b>Coming soon<?= $p['launch_date'] ? ' — launching ' . date('d M Y', strtotime($p['launch_date'])) : '' ?></b>
        <?php if ($p['launch_date']): ?><div class="countdown big" data-date="<?= e($p['launch_date']) ?>"></div><?php endif; ?>
        <a class="btn accent" href="https://wa.me/<?= e(preg_replace('/\D/', '', setting('whatsapp'))) ?>?text=<?= urlencode('Please notify me when ' . $p['name'] . ' is available') ?>">Notify me on WhatsApp</a></div>
    <?php else: ?>
    <form method="post" action="<?= url('cart.php') ?>" class="row"><?= csrf_field() ?>
      <input type="hidden" name="add" value="<?= $p['id'] ?>">
      <input type="number" name="qty" value="1" min="1" max="<?= max(1, (int)$p['stock']) ?>" style="width:80px">
      <button class="btn accent" <?= $p['stock'] > 0 ? '' : 'disabled' ?>>Add to cart</button>
    </form>
    <?php endif; ?>
    <table class="specs-table">
      <?php foreach (['Capacity' => $p['capacity'], 'Voltage' => $p['voltage'], 'Warranty' => $p['warranty_months'] ? $p['warranty_months'] . ' months' : '', 'Weight' => $p['weight_kg'] . ' kg'] as $k => $val)
        if ($val) echo '<tr><th>' . $k . '</th><td>' . e($val) . '</td></tr>'; ?>
    </table>
    <div class="desc"><?= nl2br(e($p['description'])) ?></div>
  </div>
</div>
<?php if ($related): ?><h2>Related products</h2><div class="grid4"><?php foreach ($related as $r) echo product_card($r); ?></div><?php endif; ?>
<?php include 'inc/footer.php';
