<?php
require 'inc/bootstrap.php';
header('Content-Type: text/plain');
$base = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . APP_PATH;
echo "User-agent: *\nDisallow: /admin/\nDisallow: /platform/\nDisallow: /cart.php\nDisallow: /checkout.php\nSitemap: $base/sitemap.xml\n";
