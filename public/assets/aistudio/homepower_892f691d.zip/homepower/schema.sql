-- Home Power Solutions — Multi-Tenant Solar Store (v3.0 MVP)
-- Import into MySQL 8: mysql -u root -p < schema.sql
CREATE DATABASE IF NOT EXISTS homepower CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE homepower;

-- ================= PLATFORM-LEVEL =================
CREATE TABLE plans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  price_monthly DECIMAL(12,2) NOT NULL,
  transaction_fee_pct DECIMAL(5,2) DEFAULT 0,
  max_products INT DEFAULT 100,
  max_staff INT DEFAULT 2,
  max_domains INT DEFAULT 1,
  features_json JSON NOT NULL,
  is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE tenants (
  id INT AUTO_INCREMENT PRIMARY KEY,
  uuid CHAR(36) NOT NULL UNIQUE,
  company_name VARCHAR(200) NOT NULL,
  slug VARCHAR(100) NOT NULL UNIQUE,
  plan_id INT NOT NULL,
  status ENUM('pending','active','suspended','archived') DEFAULT 'active',
  suspended_reason TEXT,
  trial_ends_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (plan_id) REFERENCES plans(id),
  INDEX idx_tenant_status (status)
) ENGINE=InnoDB;

CREATE TABLE tenant_domains (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  domain VARCHAR(255) NOT NULL UNIQUE,
  is_primary TINYINT(1) DEFAULT 0,
  verified_at DATETIME NULL,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE tenant_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  setting_key VARCHAR(100) NOT NULL,
  setting_value TEXT,
  UNIQUE KEY uniq_setting (tenant_id, setting_key),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE tenant_feature_overrides (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  feature_key VARCHAR(100) NOT NULL,
  enabled TINYINT(1) DEFAULT 1,
  UNIQUE KEY uniq_override (tenant_id, feature_key),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE platform_admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  email VARCHAR(150) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('owner','support','billing','readonly') DEFAULT 'owner',
  last_login_at DATETIME
) ENGINE=InnoDB;

CREATE TABLE platform_audit_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  platform_admin_id INT NOT NULL,
  action VARCHAR(255) NOT NULL,
  target_tenant_id INT NULL,
  ip_address VARCHAR(45),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ================= TENANT-SCOPED =================
CREATE TABLE admin_users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  username VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('owner','admin','inventory','auditor','support') DEFAULT 'owner',
  last_login_at DATETIME,
  UNIQUE KEY uniq_admin (tenant_id, username),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  admin_id INT NOT NULL,
  action VARCHAR(255) NOT NULL,
  target_table VARCHAR(100),
  target_id BIGINT,
  ip_address VARCHAR(45),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (tenant_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(120) NOT NULL,
  UNIQUE KEY uniq_cat (tenant_id, slug),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  category_id INT NULL,
  name VARCHAR(200) NOT NULL,
  slug VARCHAR(200) NOT NULL,
  sku VARCHAR(100) NOT NULL,
  brand VARCHAR(100),
  description TEXT,
  price DECIMAL(12,2) NOT NULL,
  price_installer DECIMAL(12,2) NULL,
  stock INT DEFAULT 0,
  min_threshold INT DEFAULT 5,
  capacity VARCHAR(50),
  voltage VARCHAR(20),
  warranty_months INT DEFAULT 12,
  weight_kg DECIMAL(8,2) DEFAULT 1,
  image VARCHAR(255),
  sale_price DECIMAL(12,2) NULL,
  is_featured TINYINT(1) DEFAULT 0,
  is_new TINYINT(1) DEFAULT 0,
  is_upcoming TINYINT(1) DEFAULT 0,
  launch_date DATE NULL,
  is_active TINYINT(1) DEFAULT 1,
  meta_title VARCHAR(200),
  meta_description TEXT,
  meta_keywords VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_sku (tenant_id, sku),
  UNIQUE KEY uniq_slug (tenant_id, slug),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE stock_movements (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  product_id INT NOT NULL,
  movement_type ENUM('in','out','adjustment') NOT NULL,
  quantity INT NOT NULL,
  reference_type VARCHAR(50),
  reference_id BIGINT,
  note TEXT,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (tenant_id, product_id)
) ENGINE=InnoDB;

CREATE TABLE coupons (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  code VARCHAR(50) NOT NULL,
  discount_type ENUM('percentage','fixed') NOT NULL,
  discount_value DECIMAL(10,2) NOT NULL,
  min_order_amount DECIMAL(10,2) DEFAULT 0,
  max_uses INT DEFAULT 0,
  used_count INT DEFAULT 0,
  expires_at DATETIME NULL,
  is_active TINYINT(1) DEFAULT 1,
  UNIQUE KEY uniq_coupon (tenant_id, code),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE shipping_rates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  zone_name VARCHAR(100) NOT NULL,
  base_cost DECIMAL(10,2) NOT NULL,
  per_kg DECIMAL(10,2) DEFAULT 0,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  order_number VARCHAR(30) NOT NULL,
  tracking_code VARCHAR(20) NOT NULL,
  customer_name VARCHAR(150) NOT NULL,
  phone VARCHAR(50) NOT NULL,
  email VARCHAR(150),
  city VARCHAR(100),
  address TEXT NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  discount DECIMAL(12,2) DEFAULT 0,
  shipping DECIMAL(12,2) DEFAULT 0,
  total DECIMAL(12,2) NOT NULL,
  coupon_code VARCHAR(50),
  status ENUM('pending','receipt_uploaded','verified','dispatched','completed','cancelled','on_hold','refunded') DEFAULT 'pending',
  courier VARCHAR(50),
  courier_tracking VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_order (tenant_id, order_number),
  INDEX (tenant_id, status),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE order_items (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  product_name VARCHAR(200) NOT NULL,
  unit_price DECIMAL(12,2) NOT NULL,
  quantity INT NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE payments (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  order_id INT NOT NULL,
  gateway ENUM('jazzcash','easypaisa','bank_transfer','raast','cod') NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  status ENUM('pending','receipt_uploaded','verified','rejected','refunded') DEFAULT 'pending',
  reference_number VARCHAR(150),
  receipt_path VARCHAR(255),
  receipt_hash CHAR(64),
  auditor_notes TEXT,
  verified_by INT NULL,
  verified_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (tenant_id, status),
  INDEX (tenant_id, receipt_hash),
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE warranties (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  serial_number VARCHAR(100) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status ENUM('active','claimed','expired') DEFAULT 'active',
  UNIQUE KEY uniq_serial (tenant_id, serial_number),
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE cms_pages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  slug VARCHAR(200) NOT NULL,
  title VARCHAR(200) NOT NULL,
  content MEDIUMTEXT,
  meta_description TEXT,
  status ENUM('draft','published') DEFAULT 'published',
  show_in_menu TINYINT(1) DEFAULT 1,
  UNIQUE KEY uniq_page (tenant_id, slug),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE homepage_blocks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  block_type VARCHAR(30) NOT NULL,
  title VARCHAR(150),
  subtitle VARCHAR(255),
  item_limit INT DEFAULT 8,
  sort_order INT DEFAULT 0,
  is_enabled TINYINT(1) DEFAULT 1,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE seo_redirects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  source_url VARCHAR(255) NOT NULL,
  target_url VARCHAR(255) NOT NULL,
  redirect_code INT DEFAULT 301,
  UNIQUE KEY (tenant_id, source_url)
) ENGINE=InnoDB;

CREATE TABLE sliders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  image VARCHAR(255),
  title VARCHAR(200),
  subtitle VARCHAR(255),
  btn_text VARCHAR(60),
  btn_link VARCHAR(255),
  text_align ENUM('left','center','right') DEFAULT 'left',
  text_color VARCHAR(20) DEFAULT '#0b1220',
  bg_color VARCHAR(20) DEFAULT '#eef6f4',
  sort_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE menu_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  parent_id INT NULL,
  label VARCHAR(100) NOT NULL,
  url VARCHAR(255) NOT NULL DEFAULT '#',
  open_new TINYINT(1) DEFAULT 0,
  sort_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  INDEX (tenant_id, parent_id),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE seo_meta (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  page_key VARCHAR(50) NOT NULL,
  meta_title VARCHAR(200),
  meta_description TEXT,
  meta_keywords VARCHAR(255),
  og_image VARCHAR(255),
  UNIQUE KEY (tenant_id, page_key),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ================= SEED DATA =================
INSERT INTO plans (name, price_monthly, transaction_fee_pct, max_products, max_staff, max_domains, features_json) VALUES
('Starter', 5000, 1.5, 100, 2, 0, '{"calculator":false,"coupons":false,"warranty":false,"custom_domain":false}'),
('Growth', 15000, 1.0, 1000, 5, 1, '{"calculator":true,"coupons":true,"warranty":false,"custom_domain":true}'),
('Business', 35000, 0.5, 10000, 20, 3, '{"calculator":true,"coupons":true,"warranty":true,"custom_domain":true}'),
('Enterprise', 0, 0, 999999, 999, 99, '{"calculator":true,"coupons":true,"warranty":true,"custom_domain":true}');

INSERT INTO tenants (uuid, company_name, slug, plan_id, status) VALUES
(UUID(), 'Home Power Solutions', 'homepower', 4, 'active');

INSERT INTO tenant_domains (tenant_id, domain, is_primary, verified_at) VALUES (1, 'localhost', 1, NOW());

INSERT INTO tenant_settings (tenant_id, setting_key, setting_value) VALUES
(1,'primary_color','#0f766e'),(1,'accent_color','#f59e0b'),
(1,'tagline','Pakistan''s trusted solar store — inverters, batteries & panels'),
(1,'phone','+92 300 0000000'),(1,'whatsapp','923000000000'),(1,'email','info@homepower.pk'),
(1,'address','Lahore, Punjab'),
(1,'bank_details','Bank: Meezan Bank | Title: Home Power Solutions | IBAN: PK00MEZN0000000000000000'),
(1,'jazzcash','0300-0000000 (Home Power)'),(1,'easypaisa','0345-0000000 (Home Power)'),
(1,'tariff_per_unit','60');

-- Platform owner + tenant admin, both password: admin123  (CHANGE AFTER INSTALL)
INSERT INTO platform_admins (username, email, password_hash, role) VALUES
('platform', 'owner@platform.pk', '$2y$10$A9MJcA7e5wSq7Si.WJNVk.OTpr876l7aTdiz48DM2YXIRVSY3qfh.', 'owner');
INSERT INTO admin_users (tenant_id, username, email, password_hash, role) VALUES
(1, 'admin', 'info@homepower.pk', '$2y$10$A9MJcA7e5wSq7Si.WJNVk.OTpr876l7aTdiz48DM2YXIRVSY3qfh.', 'owner');

INSERT INTO categories (tenant_id, name, slug) VALUES
(1,'Inverters','inverters'),(1,'Batteries','batteries'),(1,'Solar Panels','solar-panels'),(1,'Accessories','accessories');

INSERT INTO products (tenant_id, category_id, name, slug, sku, brand, description, price, price_installer, stock, capacity, voltage, warranty_months, weight_kg, is_featured) VALUES
(1,1,'Hybrid Inverter 6kW','hybrid-inverter-6kw','INV-6KW','Inverex','6kW hybrid solar inverter with built-in MPPT, Wi-Fi monitoring and grid-tie support.',285000,270000,12,'6 kW','48V',24,18,1),
(1,1,'Hybrid Inverter 3.6kW','hybrid-inverter-3-6kw','INV-36KW','Growatt','3.6kW off-grid/hybrid inverter ideal for homes with 1 inverter AC.',165000,155000,20,'3.6 kW','24V',24,12,1),
(1,2,'Lithium Battery 5kWh','lithium-battery-5kwh','BAT-LI5','Pylontech','LiFePO4 48V 100Ah battery, 6000+ cycles, 90% DoD.',325000,310000,8,'100 Ah','48V',60,45,1),
(1,2,'Tubular Battery 200Ah','tubular-battery-200ah','BAT-TB200','Phoenix','Deep-cycle tall tubular battery for backup systems.',62000,58000,30,'200 Ah','12V',18,60,0),
(1,3,'Mono PERC Panel 585W','mono-perc-585w','PV-585','Longi','Tier-1 bifacial mono PERC panel, 585W.',29000,27500,150,'585 W',NULL,144,28,1),
(1,4,'Panel Mounting Structure (per panel)','mounting-structure','ACC-MNT','Local','Galvanized iron L2 structure for one panel.',6500,6000,200,NULL,NULL,12,8,0);

INSERT INTO shipping_rates (tenant_id, zone_name, base_cost, per_kg) VALUES
(1,'Lahore (local)',500,0),(1,'Punjab',1500,20),(1,'Other Provinces',2500,35);

INSERT INTO coupons (tenant_id, code, discount_type, discount_value, min_order_amount) VALUES
(1,'SOLAR5','percentage',5,100000);

INSERT INTO cms_pages (tenant_id, slug, title, content) VALUES
(1,'about','About Us','<p>Home Power Solutions supplies genuine inverters, batteries and solar panels across Pakistan with installation support and warranty service.</p>'),
(1,'returns-policy','Returns & Warranty Policy','<p>Products may be returned within 7 days in original packaging. Warranty claims are handled via the warranty lookup page using your serial number.</p>');

INSERT INTO homepage_blocks (tenant_id, block_type, title, subtitle, item_limit, sort_order) VALUES
(1,'slider',NULL,NULL,0,1),(1,'categories','Shop by category','Everything you need for a complete solar system',0,2),
(1,'featured','Featured products','Our most trusted best sellers',8,3),(1,'sale','Hot deals','Limited-time prices on top brands',8,4),
(1,'new','New arrivals','Just landed in our store',8,5),(1,'upcoming','Coming soon','Launching shortly — get notified',4,6),
(1,'features','Why choose us',NULL,0,7),(1,'all_products','All products','Browse and filter our complete range',12,8),
(1,'calculator',NULL,NULL,0,9),(1,'testimonials','What customers say',NULL,0,10);

INSERT INTO sliders (tenant_id, title, subtitle, btn_text, btn_link, text_align, bg_color, sort_order) VALUES
(1,'Power your home with the sun','Hybrid inverters, lithium batteries and Tier-1 panels — delivered nationwide.','Shop now','shop.php','left','#e8f5f1',1),
(1,'Lithium batteries, built to last','6000+ cycles and up to 10-year warranty. Say goodbye to load-shedding.','View batteries','shop.php?cat=batteries','center','#fff4dd',2),
(1,'Find your perfect solar system','Use our free calculator to size inverter, battery and panels in seconds.','Open calculator','calculator.php','right','#e9f1fb',3);

INSERT INTO menu_items (id, tenant_id, parent_id, label, url, sort_order) VALUES
(1,1,NULL,'Home','index.php',1),(2,1,NULL,'Products','shop.php',2),
(3,1,2,'Inverters','shop.php?cat=inverters',1),(4,1,3,'Hybrid Inverters','shop.php?q=hybrid',1),(5,1,3,'Off-grid Inverters','shop.php?q=off-grid',2),
(6,1,2,'Batteries','shop.php?cat=batteries',2),(7,1,6,'Lithium Batteries','shop.php?q=lithium',1),(8,1,6,'Tubular Batteries','shop.php?q=tubular',2),
(9,1,2,'Solar Panels','shop.php?cat=solar-panels',3),(10,1,2,'Accessories','shop.php?cat=accessories',4),
(11,1,NULL,'Solar Calculator','calculator.php',3),(12,1,NULL,'About Us','page.php?slug=about',4),(13,1,NULL,'Track Order','track.php',5);

INSERT INTO seo_meta (tenant_id, page_key, meta_title, meta_description, meta_keywords) VALUES
(1,'home','Solar Inverters, Lithium Batteries & Panels in Pakistan | Home Power Solutions','Buy genuine hybrid solar inverters, lithium batteries and Tier-1 solar panels in Pakistan with warranty and nationwide delivery.','solar inverter pakistan, lithium battery, solar panels price');

INSERT INTO tenant_settings (tenant_id, setting_key, setting_value) VALUES
(1,'menu_style','classic'),(1,'menu_bg','#ffffff'),(1,'menu_text','#0b1220'),(1,'menu_hover','#0f766e'),
(1,'slider_height','500'),(1,'slider_autoplay','5'),(1,'slider_effect','fade');

-- Demo flags for homepage sections
UPDATE products SET sale_price=155000, is_new=1 WHERE tenant_id=1 AND sku='INV-36KW';
UPDATE products SET sale_price=27500 WHERE tenant_id=1 AND sku='PV-585';
UPDATE products SET is_new=1 WHERE tenant_id=1 AND sku='BAT-LI5';
INSERT INTO products (tenant_id, category_id, name, slug, sku, brand, description, price, stock, capacity, voltage, warranty_months, weight_kg, is_upcoming, launch_date) VALUES
(1,1,'Hybrid Inverter 10kW IP65','hybrid-inverter-10kw-ip65','INV-10KW','Inverex','Weather-proof IP65 10kW hybrid inverter with dual MPPT and parallel support.',465000,0,'10 kW','48V',36,26,1,CURDATE()+INTERVAL 30 DAY),
(1,2,'Wall-mount Lithium 10kWh','wall-lithium-10kwh','BAT-LI10','Pylontech','Slim wall-mounted 10kWh LiFePO4 battery with touch display.',590000,0,'200 Ah','48V',120,90,1,CURDATE()+INTERVAL 45 DAY);
