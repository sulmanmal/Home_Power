<?php
require 'inc/bootstrap.php';
$where = ['p.tenant_id=?', 'p.is_active=1']; $params = [TID];
if ($s = trim($_GET['q'] ?? '')) {
    // simple synonym support: "ups" ↔ "inverter"
    $syn = ['ups' => 'inverter', 'inverter' => 'ups'];
    $alt = $syn[strtolower($s)] ?? $s;
    $where[] = '(p.name LIKE ? OR p.brand LIKE ? OR p.description LIKE ? OR p.name LIKE ?)';
    array_push($params, "%$s%", "%$s%", "%$s%", "%$alt%");
}
if ($c = $_GET['cat'] ?? '') { $where[] = 'c.slug=?'; $params[] = $c; }
if ($b = $_GET['brand'] ?? '') { $where[] = 'p.brand=?'; $params[] = $b; }
if ($v = $_GET['voltage'] ?? '') { $where[] = 'p.voltage=?'; $params[] = $v; }
if (is_numeric($_GET['max'] ?? '')) { $where[] = 'p.price<=?'; $params[] = $_GET['max']; }
$order = ['price_asc' => 'p.price ASC', 'price_desc' => 'p.price DESC'][$_GET['sort'] ?? ''] ?? 'p.is_featured DESC, p.id DESC';

$products = rows("SELECT p.* FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE " . implode(' AND ', $where) . " ORDER BY $order", $params);
$cats = rows("SELECT * FROM categories WHERE tenant_id=?", [TID]);
$brands = rows("SELECT DISTINCT brand FROM products WHERE tenant_id=? AND brand<>'' ORDER BY brand", [TID]);
$volts = rows("SELECT DISTINCT voltage FROM products WHERE tenant_id=? AND voltage<>'' ORDER BY voltage", [TID]);
$pageTitle = 'Shop';
include 'inc/header.php';
?>
<h1>Shop</h1>
<div class="shop">
  <form class="card filters">
    <input type="hidden" name="q" value="<?= e($s) ?>">
    <label>Category<select name="cat"><option value="">All</option>
      <?php foreach ($cats as $x): ?><option value="<?= e($x['slug']) ?>" <?= $c === $x['slug'] ? 'selected' : '' ?>><?= e($x['name']) ?></option><?php endforeach; ?></select></label>
    <label>Brand<select name="brand"><option value="">All</option>
      <?php foreach ($brands as $x): ?><option <?= $b === $x['brand'] ? 'selected' : '' ?>><?= e($x['brand']) ?></option><?php endforeach; ?></select></label>
    <label>Voltage<select name="voltage"><option value="">Any</option>
      <?php foreach ($volts as $x): ?><option <?= $v === $x['voltage'] ? 'selected' : '' ?>><?= e($x['voltage']) ?></option><?php endforeach; ?></select></label>
    <label>Max price (Rs)<input type="number" name="max" value="<?= e($_GET['max'] ?? '') ?>"></label>
    <label>Sort<select name="sort"><option value="">Recommended</option>
      <option value="price_asc" <?= ($_GET['sort'] ?? '') === 'price_asc' ? 'selected' : '' ?>>Price: low to high</option>
      <option value="price_desc" <?= ($_GET['sort'] ?? '') === 'price_desc' ? 'selected' : '' ?>>Price: high to low</option></select></label>
    <button class="btn">Apply</button>
  </form>
  <div>
    <p class="muted"><?= count($products) ?> products<?= $s ? ' for “' . e($s) . '”' : '' ?> · <a href="<?= url('compare.php') ?>">Compare products</a></p>
    <div class="grid3"><?php foreach ($products as $p) echo product_card($p); ?></div>
  </div>
</div>
<?php include 'inc/footer.php';
