<?php
// Per-tenant XML sitemap — each domain gets its own. Map /sitemap.xml to this file in .htaccess.
require 'inc/bootstrap.php';
header('Content-Type: application/xml; charset=utf-8');
$base = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . APP_PATH . '/';
echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
foreach (['', 'shop.php', 'calculator.php'] as $u) echo '<url><loc>' . e($base . $u) . '</loc></url>';
foreach (rows("SELECT slug FROM products WHERE tenant_id=? AND is_active=1", [TID]) as $p) echo '<url><loc>' . e($base . 'product.php?slug=' . urlencode($p['slug'])) . '</loc></url>';
foreach (rows("SELECT slug FROM cms_pages WHERE tenant_id=? AND status='published'", [TID]) as $p) echo '<url><loc>' . e($base . 'page.php?slug=' . urlencode($p['slug'])) . '</loc></url>';
echo '</urlset>';
