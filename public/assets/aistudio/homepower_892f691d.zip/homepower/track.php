<?php
require 'inc/bootstrap.php';
$code = strtoupper(trim($_GET['code'] ?? $_POST['code'] ?? ''));
$order = $code ? row("SELECT * FROM orders WHERE tenant_id=? AND tracking_code=?", [TID, $code]) : null;

// Late receipt upload
if ($order && $_SERVER['REQUEST_METHOD'] === 'POST' && in_array($order['status'], ['pending', 'on_hold'])) {
    $r = save_upload('receipt');
    if (!$r) flash('Receipt must be a JPG, PNG, WEBP or PDF under 5 MB.', 'err');
    elseif (row("SELECT id FROM payments WHERE tenant_id=? AND receipt_hash=? AND order_id<>?", [TID, $r['hash'], $order['id']])) flash('This receipt was already used for another order.', 'err');
    else {
        q("UPDATE payments SET receipt_path=?, receipt_hash=?, reference_number=COALESCE(NULLIF(?,''),reference_number), status='receipt_uploaded' WHERE order_id=? AND tenant_id=?",
          [$r['path'], $r['hash'], $_POST['reference'] ?? '', $order['id'], TID]);
        q("UPDATE orders SET status='receipt_uploaded' WHERE id=? AND tenant_id=?", [$order['id'], TID]);
        flash('Receipt uploaded. We will verify it shortly.');
    }
    redirect('track.php?code=' . $code);
}

$items = $order ? rows("SELECT * FROM order_items WHERE order_id=? AND tenant_id=?", [$order['id'], TID]) : [];
$pay = $order ? row("SELECT * FROM payments WHERE order_id=? AND tenant_id=? ORDER BY id DESC", [$order['id'], TID]) : null;
$steps = ['pending' => 'Order placed', 'receipt_uploaded' => 'Receipt uploaded', 'verified' => 'Payment verified', 'dispatched' => 'Dispatched', 'completed' => 'Delivered'];
$pageTitle = 'Track order';
include 'inc/header.php';
?>
<h1>Track your order</h1>
<form class="card row"><input name="code" placeholder="Tracking code" value="<?= e($code) ?>" required><button class="btn">Track</button></form>

<?php if ($code && !$order): ?><div class="alert alert-err">No order found with that tracking code.</div><?php endif; ?>
<?php if ($order): ?>
  <?php if (!empty($_GET['new'])): ?><div class="alert alert-ok">Thank you! Your order <b><?= e($order['order_number']) ?></b> has been placed. Save your tracking code: <b><?= e($order['tracking_code']) ?></b></div><?php endif; ?>
  <div class="card">
    <h3>Order <?= e($order['order_number']) ?> · <span class="status s-<?= e($order['status']) ?>"><?= e(ucwords(str_replace('_', ' ', $order['status']))) ?></span></h3>
    <?php if (!in_array($order['status'], ['cancelled', 'refunded', 'on_hold'])): $reached = true; $keys = array_keys($steps); $cur = array_search($order['status'], $keys); ?>
    <ol class="timeline"><?php foreach ($keys as $i => $k): ?><li class="<?= $i <= $cur ? 'done' : '' ?>"><?= $steps[$k] ?></li><?php endforeach; ?></ol>
    <?php endif; ?>
    <?php if ($order['courier_tracking']): ?><p>Courier: <b><?= e($order['courier']) ?></b> · Tracking #: <b><?= e($order['courier_tracking']) ?></b></p><?php endif; ?>
    <table class="tbl"><?php foreach ($items as $it): ?><tr><td><?= e($it['product_name']) ?> × <?= $it['quantity'] ?></td><td><?= money($it['unit_price'] * $it['quantity']) ?></td></tr><?php endforeach; ?>
      <tr><td>Shipping</td><td><?= money($order['shipping']) ?></td></tr>
      <?php if ($order['discount'] > 0): ?><tr><td>Discount</td><td>− <?= money($order['discount']) ?></td></tr><?php endif; ?>
      <tr><th>Total</th><th><?= money($order['total']) ?></th></tr></table>
    <p class="muted">Payment: <?= e(ucwords(str_replace('_', ' ', $pay['gateway'] ?? ''))) ?> — <?= e(str_replace('_', ' ', $pay['status'] ?? '')) ?>
      <?= $pay && $pay['status'] === 'rejected' && $pay['auditor_notes'] ? '<br>Note: ' . e($pay['auditor_notes']) : '' ?></p>
    <a class="btn ghost-dark" href="<?= url('invoice.php?code=' . urlencode($code)) ?>" target="_blank">View / print invoice</a>
  </div>
  <?php if (in_array($order['status'], ['pending', 'on_hold']) && ($pay['gateway'] ?? '') !== 'cod'): ?>
  <form method="post" enctype="multipart/form-data" class="card"><?= csrf_field() ?><input type="hidden" name="code" value="<?= e($code) ?>">
    <h3>Upload payment receipt</h3>
    <label>Reference number<input name="reference"></label>
    <label>Receipt<input type="file" name="receipt" accept="image/*,application/pdf" required></label>
    <button class="btn accent">Upload</button>
  </form>
  <?php endif; ?>
<?php endif; ?>
<?php include 'inc/footer.php';
