-- Run this ONCE on an existing v1 database (skip if you imported the new schema.sql)
USE homepower;
ALTER TABLE products ADD sale_price DECIMAL(12,2) NULL AFTER weight_kg, ADD is_new TINYINT(1) DEFAULT 0, ADD is_upcoming TINYINT(1) DEFAULT 0,
  ADD launch_date DATE NULL, ADD meta_keywords VARCHAR(255);
ALTER TABLE homepage_blocks MODIFY block_type VARCHAR(30) NOT NULL, ADD title VARCHAR(150) AFTER block_type, ADD subtitle VARCHAR(255) AFTER title, ADD item_limit INT DEFAULT 8 AFTER subtitle;
UPDATE homepage_blocks SET block_type='slider' WHERE block_type='hero';
CREATE TABLE sliders (id INT AUTO_INCREMENT PRIMARY KEY, tenant_id INT NOT NULL, image VARCHAR(255), title VARCHAR(200), subtitle VARCHAR(255),
  btn_text VARCHAR(60), btn_link VARCHAR(255), text_align ENUM('left','center','right') DEFAULT 'left', text_color VARCHAR(20) DEFAULT '#0b1220',
  bg_color VARCHAR(20) DEFAULT '#eef6f4', sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE menu_items (id INT AUTO_INCREMENT PRIMARY KEY, tenant_id INT NOT NULL, parent_id INT NULL, label VARCHAR(100) NOT NULL,
  url VARCHAR(255) NOT NULL DEFAULT '#', open_new TINYINT(1) DEFAULT 0, sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1,
  INDEX (tenant_id, parent_id), FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE seo_meta (id INT AUTO_INCREMENT PRIMARY KEY, tenant_id INT NOT NULL, page_key VARCHAR(50) NOT NULL, meta_title VARCHAR(200),
  meta_description TEXT, meta_keywords VARCHAR(255), og_image VARCHAR(255), UNIQUE KEY (tenant_id, page_key),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE) ENGINE=InnoDB;
-- Missing homepage sections are created automatically when you open Admin → Homepage.
