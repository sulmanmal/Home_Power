<?php
require 'inc/bootstrap.php';
if (!feature('warranty')) redirect('index.php');
$serial = trim($_GET['serial'] ?? '');
$w = $serial ? row("SELECT w.*, p.name FROM warranties w JOIN products p ON p.id=w.product_id WHERE w.tenant_id=? AND w.serial_number=?", [TID, $serial]) : null;
$pageTitle = 'Warranty lookup';
include 'inc/header.php';
?>
<h1>Warranty lookup</h1>
<form class="card row"><input name="serial" placeholder="Enter product serial number" value="<?= e($serial) ?>" required><button class="btn">Check</button></form>
<?php if ($serial && !$w): ?><div class="alert alert-err">No warranty found for this serial number.</div><?php endif; ?>
<?php if ($w): $valid = strtotime($w['end_date']) >= strtotime('today'); ?>
<div class="card">
  <h3><?= e($w['name']) ?></h3>
  <p>Serial: <b><?= e($w['serial_number']) ?></b><br>Covered from <?= e($w['start_date']) ?> to <?= e($w['end_date']) ?></p>
  <p class="<?= $valid ? 'in' : 'out' ?>"><?= $valid ? '✔ Warranty is valid' : '✖ Warranty has expired' ?></p>
  <?php if ($valid): ?><a class="btn accent" href="https://wa.me/<?= e(preg_replace('/\D/', '', setting('whatsapp'))) ?>?text=<?= urlencode('Warranty claim for serial ' . $w['serial_number']) ?>">Start a claim on WhatsApp</a><?php endif; ?>
</div>
<?php endif; ?>
<?php include 'inc/footer.php';
